<?php
/**
 * Рендериране на новините за обикновените джаджи на WordPress.
 * Логиката е същата като в Elementor уиджетите (виж widgets/), но без зависимост от Elementor.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ENC_Render_Top {

	public static function defaults() {
		return [
			'post_type' => 'post',
			'categories' => [],
			'offset' => 0,
			'exclude_current' => 'yes',
			'show_fmt_icon' => 'yes',
			'fmt_icons' => ['gallery', 'video', 'audio'],
			'period' => 'week',
			'custom_days' => 3,
			'fallback' => 'yes',
			'posts_per_page' => 5,
			'show_numbers' => 'yes',
			'pad_numbers' => 'yes',
			'image_mode' => 'none',
			'image_count' => 1,
			'image_pos' => 'left',
			'image_size' => 'medium',
			'title_tag' => 'h3',
			'show_excerpt' => '',
			'excerpt_length' => 18,
			'show_share' => '',
			'fmt_icon_pos' => 'meta',
			'show_meta_icon' => '',
			'meta_icon' => [],
			'meta_label' => 'none',
			'meta_label_link' => 'yes',
			'show_time' => '',
			'time_format' => 'H:i',
			'show_date' => 'yes',
			'date_format' => 'j M. Y',
			'meta_sep' => '|',
			'show_views' => '',
			'views_key' => 'enc_views',
			'cat_colors' => [],
		];
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	/** Подрежда ID-тата: първо по прегледи за периода, после (по избор) допълва по общ брой прегледи. */
	private function ranked_ids( $s, $post_type, $views_key ) {
		$count  = max( 1, (int) $s['posts_per_page'] );
		$offset = max( 0, (int) $s['offset'] );
		$need   = $count + $offset;

		switch ( $s['period'] ) {
			case 'day':
				$hours = 24;
				break;
			case 'week':
				$hours = 168;
				break;
			case 'month':
				$hours = 720;
				break;
			case 'custom':
				$hours = max( 1, (int) $s['custom_days'] ) * 24;
				break;
			default:
				$hours = 0;
		}

		$base = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'fields'              => 'ids',
		];
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$base['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		$exclude = ( 'yes' === $s['exclude_current'] && is_singular() ) ? [ get_the_ID() ] : [];

		$ids = [];

		// 1) Прегледи през избрания период (от почасовата таблица)
		if ( $hours > 0 ) {
			$cand = enc_period_top_ids( $hours );
			if ( $cand ) {
				$args = array_merge( $base, [ 'post__in' => $cand, 'orderby' => 'post__in', 'posts_per_page' => $need ] );
				if ( $exclude ) {
					$args['post__not_in'] = $exclude;
				}
				$q   = new WP_Query( $args );
				$ids = array_map( 'intval', $q->posts );
			}
		}

		// 2) Допълване по общ брой прегледи
		if ( count( $ids ) < $need && ( 0 === $hours || 'yes' === $s['fallback'] ) ) {
			$by_total = [
				'meta_query' => [
					'relation' => 'OR',
					'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
					[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
				],
				'orderby'    => [ 'enc_v' => 'DESC', 'date' => 'DESC' ],
			];

			if ( $hours > 0 ) {
				$q = new WP_Query( array_merge( $base, $by_total, [
					'post__not_in'   => array_merge( $exclude, $ids ),
					'posts_per_page' => $need - count( $ids ),
					'date_query'     => [ [ 'after' => $hours . ' hours ago' ] ],
				] ) );
				$ids = array_merge( $ids, array_map( 'intval', $q->posts ) );
			}
			if ( count( $ids ) < $need ) {
				$q = new WP_Query( array_merge( $base, $by_total, [
					'post__not_in'   => array_merge( $exclude, $ids ),
					'posts_per_page' => $need - count( $ids ),
				] ) );
				$ids = array_merge( $ids, array_map( 'intval', $q->posts ) );
			}
		}

		return array_slice( $ids, $offset, $count );
	}

	private function item_html( $s, $rank, $index, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();
		$tag   = $c['tag'];

		$has_image = 'none' !== $s['image_mode']
			&& ( 'all' === $s['image_mode'] || $index < max( 1, (int) $s['image_count'] ) )
			&& has_post_thumbnail();
		$fmt = enc_format_icons( $id, $s, $has_image );

		$label = $label_url = $label_style = '';
		if ( 'category' === $s['meta_label'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$label = $t->name;
				if ( 'yes' === $s['meta_label_link'] ) {
					$u         = get_term_link( $t );
					$label_url = is_wp_error( $u ) ? '' : $u;
				}
				if ( isset( $c['colors'][ $t->term_id ] ) ) {
					$label_style = ' style="color:' . esc_attr( $c['colors'][ $t->term_id ] ) . '"';
				}
			}
		} elseif ( 'day' === $s['meta_label'] ) {
			$pd = get_the_date( 'Y-m-d', $id );
			if ( $pd === $c['today'] ) {
				$label = 'Днес';
			} elseif ( $pd === $c['yester'] ) {
				$label = 'Вчера';
			}
		}

		$parts = [];
		if ( 'yes' === $s['show_time'] ) {
			$parts[] = get_the_time( $s['time_format'] ?: 'H:i', $id );
		}
		if ( 'yes' === $s['show_date'] ) {
			$parts[] = get_the_date( $s['date_format'] ?: 'j M. Y', $id );
		}
		$sep       = trim( (string) $s['meta_sep'] );
		$time_str  = implode( $sep ? ' ' . $sep . ' ' : ' ', $parts );
		$views     = ( 'yes' === $s['show_views'] ) ? (int) get_post_meta( $id, $c['views_key'], true ) : null;
		$has_icon  = 'yes' === $s['show_meta_icon'];
		$has_share = 'yes' === $s['show_share'];
		$has_meta  = $has_icon || $label || $time_str || null !== $views || $has_share || $fmt['inline'];

		$num = ( 'yes' === $s['pad_numbers'] ) ? str_pad( (string) $rank, 2, '0', STR_PAD_LEFT ) : (string) $rank;
		$cls = 'enc-top-item';
		if ( 'yes' !== $s['show_numbers'] ) {
			$cls .= ' enc-top-item--nonum';
		}
		if ( $has_image ) {
			$cls .= ( 'right' === $s['image_pos'] ) ? ' enc-top-item--img-r' : ' enc-top-item--img-l';
		}

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( 'yes' === $s['show_numbers'] ) : ?><span class="enc-top-num"><?php echo esc_html( $num ); ?></span><?php endif; ?>

			<?php if ( $has_image ) : ?>
				<a class="enc-top-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>

			<div class="enc-top-item__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-top-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>

				<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
					<p class="enc-top-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
				<?php endif; ?>

				<?php if ( $has_meta ) : ?>
					<div class="enc-top-meta">
						<?php echo $fmt['inline']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( $has_icon ) : ?>
							<span class="enc-top-meta__icon"><?php
								if ( ! empty( $s['meta_icon']['value'] ) ) {
									\Elementor\Icons_Manager::render_icon( $s['meta_icon'], [ 'aria-hidden' => 'true' ] );
								} else {
									echo $c['icon_news']; // phpcs:ignore WordPress.Security.EscapeOutput
								}
							?></span>
						<?php endif; ?>

						<?php if ( $label ) :
							if ( $label_url ) : ?><a class="enc-top-meta__label" href="<?php echo esc_url( $label_url ); ?>"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></a><?php
							else : ?><strong class="enc-top-meta__label"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></strong><?php
							endif;
						endif; ?>

						<?php if ( $time_str ) : ?><time class="enc-top-meta__time" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $time_str ); ?></time><?php endif; ?>

						<?php if ( null !== $views ) : ?>
							<span class="enc-top-meta__views"><?php echo $c['icon_eye']; // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $views ); ?></span></span>
						<?php endif; ?>

						<?php if ( $has_share ) : ?>
							<button type="button" class="enc-share enc-top-share" aria-label="Сподели"
								data-url="<?php echo esc_url( $link ); ?>" data-title="<?php echo esc_attr( $title ); ?>" data-copied="Линкът е копиран">
								<?php echo $c['icon_share']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</button>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	public function render( $s ) {
		$s = wp_parse_args( $s, self::defaults() );
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';

		$ids = $this->ranked_ids( $s, $post_type, $views_key );
		if ( ! $ids ) {
			echo '<div class="enc-top-empty">Все още няма данни за най-четените новини.</div>';
			return;
		}

		$q = new WP_Query( [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'post__in'            => $ids,
			'orderby'             => 'post__in',
			'posts_per_page'      => count( $ids ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		] );

		$colors = enc_all_term_colors();
		if ( ! empty( $s['cat_colors'] ) ) {
			foreach ( $s['cat_colors'] as $row ) {
				if ( ! empty( $row['term'] ) && ! empty( $row['color'] ) ) {
					$colors[ (int) $row['term'] ] = $row['color'];
				}
			}
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'colors'     => $colors,
			'tag'        => in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $s['title_tag'] : 'h3',
			'today'      => wp_date( 'Y-m-d' ),
			'yester'     => wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ),
			'icon_news'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h13a1 1 0 0 1 1 1v12a2 2 0 0 0 2 2H6a2 2 0 0 1-2-2V5Z"/><path d="M18 9h2a1 1 0 0 1 1 1v8a2 2 0 0 1-2 2"/><path d="M8 9h6M8 13h6M8 17h4"/></svg>',
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
			'icon_share' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="currentColor"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></g><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
		];

		$start = max( 0, (int) $s['offset'] );
		$items = [];
		$i     = 0;
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = $this->item_html( $s, $start + $i + 1, $i, $ctx );
			$i++;
		}
		wp_reset_postdata();

		echo '<div class="enc-top"><div class="enc-top-panel"><div class="enc-top-items">' . implode( '', $items ) . '</div></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}


class ENC_Render_List {

	public static function defaults() {
		return [
			'post_type' => 'post',
			'categories' => [],
			'offset' => 0,
			'exclude_current' => 'yes',
			'show_fmt_icon' => 'yes',
			'fmt_icons' => ['gallery', 'video', 'audio'],
			'posts_per_page' => 5,
			'orderby' => 'date',
			'order' => 'DESC',
			'days' => 0,
			'image_mode' => 'first',
			'image_count' => 1,
			'image_pos' => 'left',
			'image_size' => 'medium_large',
			'split_first' => 'yes',
			'title_tag' => 'h3',
			'show_excerpt' => '',
			'excerpt_length' => 18,
			'show_share' => 'yes',
			'zoom' => 'yes',
			'fmt_icon_pos' => 'meta',
			'show_meta_icon' => '',
			'meta_icon' => [],
			'meta_label' => 'category',
			'meta_label_link' => 'yes',
			'show_time' => 'yes',
			'time_format' => 'H:i',
			'show_date' => 'yes',
			'date_format' => 'd.m.y',
			'meta_sep' => '|',
			'show_views' => 'yes',
			'views_key' => 'enc_views',
			'cat_colors' => [],
		];
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	/** HTML на една новина. $c е общият контекст за целия списък. */
	private function item_html( $s, $index, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();

		$has_image = 'none' !== $s['image_mode']
			&& ( 'all' === $s['image_mode'] || $index < max( 1, (int) $s['image_count'] ) )
			&& has_post_thumbnail();
		$fmt = enc_format_icons( $id, $s, $has_image );

		// Етикет (категория или Днес/Вчера)
		$label = $label_url = $label_style = '';
		if ( 'category' === $s['meta_label'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$label = $t->name;
				if ( 'yes' === $s['meta_label_link'] ) {
					$u         = get_term_link( $t );
					$label_url = is_wp_error( $u ) ? '' : $u;
				}
				if ( isset( $c['colors'][ $t->term_id ] ) ) {
					$label_style = ' style="color:' . esc_attr( $c['colors'][ $t->term_id ] ) . '"';
				}
			}
		} elseif ( 'day' === $s['meta_label'] ) {
			$pd = get_the_date( 'Y-m-d', $id );
			if ( $pd === $c['today'] ) {
				$label = 'Днес';
			} elseif ( $pd === $c['yester'] ) {
				$label = 'Вчера';
			}
		}

		// Час и дата
		$parts = [];
		if ( 'yes' === $s['show_time'] ) {
			$parts[] = get_the_time( $s['time_format'] ?: 'H:i', $id );
		}
		if ( 'yes' === $s['show_date'] ) {
			$parts[] = get_the_date( $s['date_format'] ?: 'd.m.y', $id );
		}
		$sep      = trim( (string) $s['meta_sep'] );
		$time_str = implode( $sep ? ' ' . $sep . ' ' : ' ', $parts );
		$views    = ( 'yes' === $s['show_views'] ) ? (int) get_post_meta( $id, $c['views_key'], true ) : null;
		$has_icon = 'yes' === $s['show_meta_icon'];
		$has_share = 'yes' === $s['show_share'];
		$has_meta = $has_icon || $label || $time_str || null !== $views || $has_share || $fmt['inline'];

		$tag = $c['tag'];
		$cls = 'enc-list-item' . ( $has_image ? ' has-image' : '' ) . ( $has_image && 'right' === $s['image_pos'] ? ' enc-list-item--img-right' : '' );

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( $has_image ) : ?>
				<a class="enc-list-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>

			<div class="enc-list-item__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-list-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>

				<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
					<p class="enc-list-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
				<?php endif; ?>

				<?php if ( $has_meta ) : ?>
					<div class="enc-list-meta">
						<?php echo $fmt['inline']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( $has_icon ) : ?>
							<span class="enc-list-meta__icon"><?php
								if ( ! empty( $s['meta_icon']['value'] ) ) {
									\Elementor\Icons_Manager::render_icon( $s['meta_icon'], [ 'aria-hidden' => 'true' ] );
								} else {
									echo $c['icon_news']; // phpcs:ignore WordPress.Security.EscapeOutput
								}
							?></span>
						<?php endif; ?>

						<?php if ( $label ) :
							if ( $label_url ) : ?><a class="enc-list-meta__label" href="<?php echo esc_url( $label_url ); ?>"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></a><?php
							else : ?><strong class="enc-list-meta__label"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></strong><?php
							endif;
						endif; ?>

						<?php if ( $time_str ) : ?><time class="enc-list-meta__time" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $time_str ); ?></time><?php endif; ?>

						<?php if ( null !== $views ) : ?>
							<span class="enc-list-meta__views"><?php echo $c['icon_eye']; // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $views ); ?></span></span>
						<?php endif; ?>

						<?php if ( $has_share ) : ?>
							<button type="button" class="enc-share enc-list-share" aria-label="Сподели"
								data-url="<?php echo esc_url( $link ); ?>" data-title="<?php echo esc_attr( $title ); ?>" data-copied="Линкът е копиран">
								<?php echo $c['icon_share']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</button>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	public function render( $s ) {
		$s = wp_parse_args( $s, self::defaults() );
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $s['posts_per_page'] ),
			'offset'              => (int) $s['offset'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
		];
		if ( 'views' === $s['orderby'] ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
				[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
			];
			$args['orderby'] = [ 'enc_v' => $s['order'], 'date' => 'DESC' ];
		} else {
			$args['orderby'] = $s['orderby'];
		}
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( (int) $s['days'] > 0 ) {
			$args['date_query'] = [ [ 'after' => (int) $s['days'] . ' days ago' ] ];
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$q = new WP_Query( $args );
		if ( ! $q->have_posts() ) {
			echo '<div class="enc-list-empty">Няма намерени новини.</div>';
			return;
		}

		$colors = enc_all_term_colors();
		if ( ! empty( $s['cat_colors'] ) ) {
			foreach ( $s['cat_colors'] as $row ) {
				if ( ! empty( $row['term'] ) && ! empty( $row['color'] ) ) {
					$colors[ (int) $row['term'] ] = $row['color'];
				}
			}
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'colors'     => $colors,
			'tag'        => in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $s['title_tag'] : 'h3',
			'today'      => wp_date( 'Y-m-d' ),
			'yester'     => wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ),
			'icon_news'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h13a1 1 0 0 1 1 1v12a2 2 0 0 0 2 2H6a2 2 0 0 1-2-2V5Z"/><path d="M18 9h2a1 1 0 0 1 1 1v8a2 2 0 0 1-2 2"/><path d="M8 9h6M8 13h6M8 17h4"/></svg>',
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
			'icon_share' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="currentColor"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></g><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
		];

		$items = [];
		$i     = 0;
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = $this->item_html( $s, $i, $ctx );
			$i++;
		}
		wp_reset_postdata();

		$groups = ( 'yes' === $s['split_first'] && count( $items ) > 1 )
			? [ [ $items[0] ], array_slice( $items, 1 ) ]
			: [ $items ];

		$classes = 'enc-list' . ( 'yes' === $s['zoom'] ? ' enc-list--zoom' : '' );
		echo '<div class="' . esc_attr( $classes ) . '">';
		foreach ( $groups as $g ) {
			echo '<div class="enc-list-panel"><div class="enc-list-items">' . implode( '', $g ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
	}
}


class ENC_Render_Latest {

	public static function defaults() {
		return [
			'post_type' => 'post',
			'categories' => [],
			'offset' => 0,
			'exclude_current' => 'yes',
			'show_fmt_icon' => 'yes',
			'fmt_icons' => ['gallery', 'video', 'audio'],
			'posts_per_page' => 5,
			'orderby' => 'date',
			'order' => 'DESC',
			'days' => 0,
			'layout' => 'vertical',
			'slider' => '',
			'slide_by' => 'one',
			'nav_pos' => 'bl',
			'autoplay' => '',
			'autoplay_delay' => 4,
			'title_tag' => 'h3',
			'image_mode' => 'none',
			'image_pos' => 'left',
			'image_size' => 'medium',
			'time_style' => 'ago',
			'max_days' => 7,
			'time_format' => 'H:i',
			'date_format' => 'd.m.y',
			'show_time_icon' => 'yes',
			'time_icon' => [],
			'uppercase' => 'yes',
			'show_category' => '',
			'category_link' => 'yes',
			'show_views' => '',
			'views_key' => 'enc_views',
			'fmt_icon_pos' => 'meta',
		];
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	private function item_html( $s, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();
		$tag   = $c['tag'];

		$has_image = 'all' === $s['image_mode'] && has_post_thumbnail();
		$fmt       = enc_format_icons( $id, $s, $has_image );

		// Време
		$when = '';
		if ( 'none' !== $s['time_style'] ) {
			$ts       = (int) get_post_time( 'U', true, $id );
			$date_str = get_the_date( $s['date_format'] ?: 'd.m.y', $id );
			$attrs    = '';
			switch ( $s['time_style'] ) {
				case 'ago':
					$max  = max( 1, (int) $s['max_days'] );
					$txt  = enc_time_ago( $ts, $max );
					$attrs = ' data-enc-ago="' . $ts . '" data-max="' . $max . '" data-date="' . esc_attr( $date_str ) . '"';
					if ( '' === $txt ) {
						$txt = $date_str;
					}
					break;
				case 'time':
					$txt = get_the_time( $s['time_format'] ?: 'H:i', $id );
					break;
				case 'datetime':
					$txt = get_the_time( $s['time_format'] ?: 'H:i', $id ) . ' | ' . $date_str;
					break;
				default:
					$txt = $date_str;
			}
			$icon = '';
			if ( 'yes' === $s['show_time_icon'] ) {
				ob_start();
				if ( ! empty( $s['time_icon']['value'] ) ) {
					\Elementor\Icons_Manager::render_icon( $s['time_icon'], [ 'aria-hidden' => 'true' ] );
				} else {
					echo $c['icon_clock']; // phpcs:ignore WordPress.Security.EscapeOutput
				}
				$icon = '<span class="enc-lt-when__icon">' . ob_get_clean() . '</span>';
			}
			$when = '<span class="enc-lt-when">' . $icon . '<time class="enc-lt-time" datetime="' . esc_attr( get_the_date( 'c', $id ) ) . '"' . $attrs . '>' . esc_html( $txt ) . '</time></span>';
		}

		// Категория
		$label = '';
		if ( 'yes' === $s['show_category'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$u = ( 'yes' === $s['category_link'] ) ? get_term_link( $t ) : '';
				if ( $u && ! is_wp_error( $u ) ) {
					$label = '<a class="enc-lt-label" href="' . esc_url( $u ) . '">' . esc_html( $t->name ) . '</a>';
				} else {
					$label = '<span class="enc-lt-label">' . esc_html( $t->name ) . '</span>';
				}
			}
		}

		$views = '';
		if ( 'yes' === $s['show_views'] ) {
			$views = '<span class="enc-lt-views">' . $c['icon_eye'] . '<span>' . (int) get_post_meta( $id, $c['views_key'], true ) . '</span></span>';
		}

		$meta = $fmt['inline'] . $when . $label . $views;

		$cls = 'enc-lt-item';
		if ( $has_image && 'left' === $s['image_pos'] ) {
			$cls .= ' enc-lt-item--img-left';
		} elseif ( $has_image && 'right' === $s['image_pos'] ) {
			$cls .= ' enc-lt-item--img-right';
		}

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( $has_image ) : ?>
				<a class="enc-lt-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>
			<div class="enc-lt-item__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-lt-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>
				<?php if ( $meta ) : ?>
					<div class="enc-lt-meta"><?php echo $meta; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
				<?php endif; ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	public function render( $s ) {
		$s = wp_parse_args( $s, self::defaults() );
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $s['posts_per_page'] ),
			'offset'              => (int) $s['offset'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		];
		if ( 'views' === $s['orderby'] ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
				[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
			];
			$args['orderby'] = [ 'enc_v' => $s['order'], 'date' => 'DESC' ];
		} else {
			$args['orderby'] = $s['orderby'];
		}
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( (int) $s['days'] > 0 ) {
			$args['date_query'] = [ [ 'after' => (int) $s['days'] . ' days ago' ] ];
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$q = new WP_Query( $args );
		if ( ! $q->have_posts() ) {
			echo '<div class="enc-lt-empty">Няма намерени новини.</div>';
			return;
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'tag'        => in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $s['title_tag'] : 'h3',
			'icon_clock' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
		];

		$items = [];
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = $this->item_html( $s, $ctx );
		}
		wp_reset_postdata();

		$vertical = 'vertical' === $s['layout'];
		$slider   = ! $vertical && 'yes' === $s['slider'];
		$nav_pos  = in_array( $s['nav_pos'], [ 'bl', 'br', 'tr', 'sides' ], true ) ? $s['nav_pos'] : 'bl';

		$classes = 'enc-lt ' . ( $vertical ? 'enc-lt--v' : 'enc-lt--h' );
		if ( 'yes' === $s['uppercase'] ) {
			$classes .= ' enc-lt--upper';
		}
		$attrs = '';
		if ( $slider ) {
			$classes .= ' enc-lt--slider enc-lt--nav-' . $nav_pos;
			$attrs    = ' data-by="' . esc_attr( 'page' === $s['slide_by'] ? 'page' : 'one' ) . '"'
				. ' data-autoplay="' . ( 'yes' === $s['autoplay'] ? '1' : '0' ) . '"'
				. ' data-delay="' . (int) $s['autoplay_delay'] . '"';
		}

		echo '<div class="' . esc_attr( $classes ) . '"' . $attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="enc-lt-viewport"><div class="enc-lt-track">' . implode( '', $items ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $slider ) {
			echo '<div class="enc-lt-nav">'
				. '<button type="button" class="enc-lt-btn enc-lt-btn--prev" aria-label="Предишни"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 5-7 7 7 7"/></svg></button>'
				. '<button type="button" class="enc-lt-btn enc-lt-btn--next" aria-label="Следващи"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button>'
				. '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
	}
}


class ENC_Render_Lead {

	public static function defaults() {
		return [
			'post_type' => 'post',
			'categories' => [],
			'offset' => 0,
			'exclude_current' => 'yes',
			'show_fmt_icon' => 'yes',
			'fmt_icons' => ['gallery', 'video', 'audio'],
			'list_count' => 2,
			'orderby' => 'date',
			'order' => 'DESC',
			'days' => 0,
			'image_size' => 'large',
			'title_tag' => 'h2',
			'show_category' => '',
			'show_excerpt' => '',
			'excerpt_length' => 18,
			'show_share' => 'yes',
			'zoom' => 'yes',
			'list_images' => 'none',
			'list_image_pos' => 'left',
			'list_image_size' => 'medium',
			'show_meta_icon' => '',
			'meta_icon' => [],
			'meta_label' => 'none',
			'meta_label_link' => 'yes',
			'show_time' => 'yes',
			'time_format' => 'H:i',
			'show_date' => 'yes',
			'date_format' => 'd.m.y',
			'meta_sep' => '|',
			'show_views' => 'yes',
			'views_key' => 'enc_views',
			'cat_colors' => [],
			'fmt_icon_pos' => 'tr',
		];
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	/** Редът с категория, час/дата, прегледи и бутон „Сподели“. */
	private function meta_html( $s, $c, $hero, $fmt_in = '' ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();

		$label = $label_url = $label_style = '';
		if ( 'category' === $s['meta_label'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$label = $t->name;
				if ( 'yes' === $s['meta_label_link'] ) {
					$u         = get_term_link( $t );
					$label_url = is_wp_error( $u ) ? '' : $u;
				}
				if ( ! $hero && isset( $c['colors'][ $t->term_id ] ) ) {
					$label_style = ' style="color:' . esc_attr( $c['colors'][ $t->term_id ] ) . '"';
				}
			}
		} elseif ( 'day' === $s['meta_label'] ) {
			$pd = get_the_date( 'Y-m-d', $id );
			if ( $pd === $c['today'] ) {
				$label = 'Днес';
			} elseif ( $pd === $c['yester'] ) {
				$label = 'Вчера';
			}
		}

		$parts = [];
		if ( 'yes' === $s['show_time'] ) {
			$parts[] = get_the_time( $s['time_format'] ?: 'H:i', $id );
		}
		if ( 'yes' === $s['show_date'] ) {
			$parts[] = get_the_date( $s['date_format'] ?: 'd.m.y', $id );
		}
		$sep       = trim( (string) $s['meta_sep'] );
		$time_str  = implode( $sep ? ' ' . $sep . ' ' : ' ', $parts );
		$views     = ( 'yes' === $s['show_views'] ) ? (int) get_post_meta( $id, $c['views_key'], true ) : null;
		$has_icon  = 'yes' === $s['show_meta_icon'];
		$has_share = 'yes' === $s['show_share'];

		if ( ! ( $has_icon || $label || $time_str || null !== $views || $has_share || $fmt_in ) ) {
			return '';
		}

		ob_start();
		?>
		<div class="enc-lead-meta">
			<?php echo $fmt_in; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php if ( $has_icon ) : ?>
				<span class="enc-lead-meta__icon"><?php
					if ( ! empty( $s['meta_icon']['value'] ) ) {
						\Elementor\Icons_Manager::render_icon( $s['meta_icon'], [ 'aria-hidden' => 'true' ] );
					} else {
						echo $c['icon_news']; // phpcs:ignore WordPress.Security.EscapeOutput
					}
				?></span>
			<?php endif; ?>

			<?php if ( $label ) :
				if ( $label_url ) : ?><a class="enc-lead-meta__label" href="<?php echo esc_url( $label_url ); ?>"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></a><?php
				else : ?><strong class="enc-lead-meta__label"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></strong><?php
				endif;
			endif; ?>

			<?php if ( $time_str ) : ?><time class="enc-lead-meta__time" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $time_str ); ?></time><?php endif; ?>

			<?php if ( null !== $views ) : ?>
				<span class="enc-lead-meta__views"><?php echo $c['icon_eye']; // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $views ); ?></span></span>
			<?php endif; ?>

			<?php if ( $has_share ) : ?>
				<button type="button" class="enc-share enc-lead-share" aria-label="Сподели"
					data-url="<?php echo esc_url( $link ); ?>" data-title="<?php echo esc_attr( $title ); ?>" data-copied="Линкът е копиран">
					<?php echo $c['icon_share']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</button>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	private function hero_html( $s, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();
		$tag   = in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'div' ], true ) ? $s['title_tag'] : 'h2';

		$cat = null;
		if ( 'yes' === $s['show_category'] ) {
			$cat = $this->get_primary_term( $id, $c['post_type'] );
		}

		$fmt = enc_format_icons( $id, $s, true );

		ob_start();
		?>
		<article class="enc-lead-hero">
			<div class="enc-lead-hero__media">
				<?php if ( has_post_thumbnail() ) {
					echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => esc_attr( $title ) ] );
				} ?>
			</div>
			<span class="enc-lead-hero__overlay"></span>
			<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<a class="enc-lead-hero__cover" href="<?php echo esc_url( $link ); ?>" aria-hidden="true" tabindex="-1"></a>
			<?php if ( $cat ) : ?><span class="enc-lead-badge"><?php echo esc_html( $cat->name ); ?></span><?php endif; ?>

			<div class="enc-lead-hero__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-lead-hero__title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>
				<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
					<p class="enc-lead-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
				<?php endif; ?>
				<?php echo $this->meta_html( $s, $c, true, $fmt['inline'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	private function row_html( $s, $c ) {
		$id        = get_the_ID();
		$link      = get_permalink();
		$title     = get_the_title();
		$has_image = 'all' === $s['list_images'] && has_post_thumbnail();
		$fmt       = enc_format_icons( $id, $s, $has_image );
		$cls       = 'enc-lead-item' . ( $has_image && 'right' === $s['list_image_pos'] ? ' enc-lead-item--img-right' : '' );

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( $has_image ) : ?>
				<a class="enc-lead-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['list_image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>
			<div class="enc-lead-item__body">
				<h3 class="enc-lead-item__title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></h3>
				<?php echo $this->meta_html( $s, $c, false, $fmt['inline'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	public function render( $s ) {
		$s = wp_parse_args( $s, self::defaults() );
		$post_type  = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key  = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';
		$list_count = max( 0, (int) $s['list_count'] );

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => 1 + $list_count,
			'offset'              => (int) $s['offset'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
		];
		if ( 'views' === $s['orderby'] ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
				[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
			];
			$args['orderby'] = [ 'enc_v' => $s['order'], 'date' => 'DESC' ];
		} else {
			$args['orderby'] = $s['orderby'];
		}
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( (int) $s['days'] > 0 ) {
			$args['date_query'] = [ [ 'after' => (int) $s['days'] . ' days ago' ] ];
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$q = new WP_Query( $args );
		if ( ! $q->have_posts() ) {
			echo '<div class="enc-lead-empty">Няма намерени новини.</div>';
			return;
		}

		$colors = enc_all_term_colors();
		if ( ! empty( $s['cat_colors'] ) ) {
			foreach ( $s['cat_colors'] as $row ) {
				if ( ! empty( $row['term'] ) && ! empty( $row['color'] ) ) {
					$colors[ (int) $row['term'] ] = $row['color'];
				}
			}
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'colors'     => $colors,
			'today'      => wp_date( 'Y-m-d' ),
			'yester'     => wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ),
			'icon_news'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h13a1 1 0 0 1 1 1v12a2 2 0 0 0 2 2H6a2 2 0 0 1-2-2V5Z"/><path d="M18 9h2a1 1 0 0 1 1 1v8a2 2 0 0 1-2 2"/><path d="M8 9h6M8 13h6M8 17h4"/></svg>',
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
			'icon_share' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="currentColor"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></g><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
		];

		$hero = '';
		$rows = [];
		$i    = 0;
		while ( $q->have_posts() ) {
			$q->the_post();
			if ( 0 === $i ) {
				$hero = $this->hero_html( $s, $ctx );
			} else {
				$rows[] = $this->row_html( $s, $ctx );
			}
			$i++;
		}
		wp_reset_postdata();

		echo '<div class="enc-lead' . ( 'yes' === $s['zoom'] ? ' enc-lead--zoom' : '' ) . '"><div class="enc-lead-panel">';
		echo $hero; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $rows ) {
			echo '<div class="enc-lead-items">' . implode( '', $rows ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></div>';
	}
}

