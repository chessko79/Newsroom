<?php
/**
 * Обикновени джаджи на WordPress (Външен вид → Джаджи / Customizer) – без Elementor.
 * Рисуват същия HTML и ползват същите CSS файлове като Elementor уиджетите.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class ENC_WP_Widget extends WP_Widget {

	/** key => [ label, type (number|text|select|checkbox|cats), default, options|min|max ] */
	protected $fields   = [];
	protected $fixed    = [];
	protected $renderer = '';
	protected $styles   = [];
	protected $scripts  = [];

	protected function merge( $instance ) {
		$out = [ 'title' => isset( $instance['title'] ) ? (string) $instance['title'] : '' ];
		foreach ( $this->fields as $key => $f ) {
			$out[ $key ] = isset( $instance[ $key ] ) ? $instance[ $key ] : $f['default'];
		}
		return $out;
	}

	public function form( $instance ) {
		$i = $this->merge( $instance );
		printf(
			'<p><label for="%1$s">Заглавие</label><input class="widefat" id="%1$s" name="%2$s" type="text" value="%3$s"></p>',
			esc_attr( $this->get_field_id( 'title' ) ),
			esc_attr( $this->get_field_name( 'title' ) ),
			esc_attr( $i['title'] )
		);

		foreach ( $this->fields as $key => $f ) {
			$id   = $this->get_field_id( $key );
			$name = $this->get_field_name( $key );
			$val  = $i[ $key ];

			switch ( $f['type'] ) {
				case 'checkbox':
					printf(
						'<p><input type="checkbox" id="%1$s" name="%2$s" value="1" %3$s> <label for="%1$s">%4$s</label></p>',
						esc_attr( $id ), esc_attr( $name ), checked( ! empty( $val ), true, false ), esc_html( $f['label'] )
					);
					break;

				case 'number':
					printf(
						'<p><label for="%1$s">%4$s</label><br><input class="small-text" id="%1$s" name="%2$s" type="number" min="%5$d" max="%6$d" value="%3$d"></p>',
						esc_attr( $id ), esc_attr( $name ), (int) $val, esc_html( $f['label'] ), (int) $f['min'], (int) $f['max']
					);
					break;

				case 'select':
					echo '<p><label for="' . esc_attr( $id ) . '">' . esc_html( $f['label'] ) . '</label><br>';
					echo '<select class="widefat" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
					foreach ( $f['options'] as $ov => $ol ) {
						echo '<option value="' . esc_attr( $ov ) . '"' . selected( (string) $val, (string) $ov, false ) . '>' . esc_html( $ol ) . '</option>';
					}
					echo '</select></p>';
					break;

				case 'cats':
					$sel  = array_map( 'intval', (array) $val );
					$cats = get_categories( [ 'hide_empty' => false ] );
					echo '<p><label for="' . esc_attr( $id ) . '">' . esc_html( $f['label'] ) . '</label><br>';
					echo '<select class="widefat" multiple size="5" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '[]">';
					foreach ( $cats as $c ) {
						echo '<option value="' . (int) $c->term_id . '"' . selected( in_array( (int) $c->term_id, $sel, true ), true, false ) . '>' . esc_html( $c->name ) . '</option>';
					}
					echo '</select><br><small>Без избор = всички категории. Ctrl/Cmd + клик за няколко.</small></p>';
					break;

				default: // text
					printf(
						'<p><label for="%1$s">%4$s</label><input class="widefat" id="%1$s" name="%2$s" type="text" value="%3$s"></p>',
						esc_attr( $id ), esc_attr( $name ), esc_attr( $val ), esc_html( $f['label'] )
					);
			}
		}
	}

	public function update( $new, $old ) {
		$out = [ 'title' => isset( $new['title'] ) ? sanitize_text_field( $new['title'] ) : '' ];
		foreach ( $this->fields as $key => $f ) {
			$v = isset( $new[ $key ] ) ? $new[ $key ] : null;
			switch ( $f['type'] ) {
				case 'checkbox':
					$out[ $key ] = empty( $v ) ? 0 : 1;
					break;
				case 'number':
					$out[ $key ] = min( (int) $f['max'], max( (int) $f['min'], (int) $v ) );
					break;
				case 'select':
					$out[ $key ] = ( null !== $v && isset( $f['options'][ $v ] ) ) ? $v : $f['default'];
					break;
				case 'cats':
					$out[ $key ] = array_values( array_filter( array_map( 'absint', (array) $v ) ) );
					break;
				default:
					$out[ $key ] = null === $v ? $f['default'] : sanitize_text_field( $v );
			}
		}
		return $out;
	}

	protected function to_settings( $i ) {
		$s = $this->fixed;
		foreach ( $this->fields as $key => $f ) {
			$v = $i[ $key ];
			switch ( $f['type'] ) {
				case 'checkbox':
					$s[ $key ] = $v ? 'yes' : '';
					break;
				case 'cats':
					$s[ $key ] = array_map( 'intval', (array) $v );
					break;
				case 'number':
					$s[ $key ] = (int) $v;
					break;
				default:
					$s[ $key ] = (string) $v;
			}
		}
		return $s;
	}

	public function widget( $args, $instance ) {
		$i = $this->merge( $instance );

		foreach ( $this->styles as $h ) {
			wp_enqueue_style( $h );
		}
		foreach ( $this->scripts as $h ) {
			wp_enqueue_script( $h );
		}

		$cls = $this->renderer;
		$r   = new $cls();
		ob_start();
		$r->render( $this->to_settings( $i ) );
		$html = ob_get_clean();
		if ( '' === trim( $html ) ) {
			return;
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( '' !== $i['title'] ) {
			echo $args['before_title'] . esc_html( $i['title'] ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput
		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/* Общи списъци с опции */
	protected static function orderby_opts() {
		return [
			'date' => 'Дата (най-новите)', 'views' => 'Прегледи (най-четени)', 'comment_count' => 'Коментари',
			'modified' => 'Последна промяна', 'title' => 'Заглавие', 'rand' => 'Случайно',
		];
	}

	protected static function label_opts() {
		return [ 'none' => 'Без етикет', 'category' => 'Категория', 'day' => '„Днес“ / „Вчера“' ];
	}
}

/* ================= Най-четени ================= */
class ENC_WP_Widget_Top extends ENC_WP_Widget {
	public function __construct() {
		parent::__construct( 'enc_wp_top', 'Newsroom: Най-четени', [ 'description' => 'Номериран списък с най-четените новини за избран период.' ] );
		$this->renderer = 'ENC_Render_Top';
		$this->styles   = [ 'enc-news-top' ];
		$this->scripts  = [ 'enc-single' ];
		$this->fields   = [
			'period'          => [ 'label' => 'Най-четени за', 'type' => 'select', 'default' => 'week', 'options' => [
				'day' => 'Последния ден (24 часа)', 'week' => 'Последните 7 дни', 'month' => 'Последните 30 дни', 'custom' => 'Друг брой дни', 'all' => 'За всички времена',
			] ],
			'custom_days'     => [ 'label' => 'Брой дни (при „Друг брой дни“)', 'type' => 'number', 'default' => 3, 'min' => 1, 'max' => 30 ],
			'fallback'        => [ 'label' => 'Допълни, ако няма достатъчно данни за периода', 'type' => 'checkbox', 'default' => 1 ],
			'categories'      => [ 'label' => 'Категории', 'type' => 'cats', 'default' => [] ],
			'posts_per_page'  => [ 'label' => 'Брой новини', 'type' => 'number', 'default' => 5, 'min' => 1, 'max' => 30 ],
			'offset'          => [ 'label' => 'Пропусни първите (номерацията продължава)', 'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 30 ],
			'exclude_current' => [ 'label' => 'Без текущата статия', 'type' => 'checkbox', 'default' => 1 ],
			'show_numbers'    => [ 'label' => 'Номера (01, 02, 03…)', 'type' => 'checkbox', 'default' => 1 ],
			'pad_numbers'     => [ 'label' => 'Водеща нула (01 вместо 1)', 'type' => 'checkbox', 'default' => 1 ],
			'image_mode'      => [ 'label' => 'Снимки', 'type' => 'select', 'default' => 'none', 'options' => [ 'none' => 'Без снимки', 'all' => 'При всички', 'first' => 'Само при първите N' ] ],
			'image_count'     => [ 'label' => 'При колко от първите (за „Само при първите N“)', 'type' => 'number', 'default' => 1, 'min' => 1, 'max' => 10 ],
			'meta_label'      => [ 'label' => 'Етикет под заглавието', 'type' => 'select', 'default' => 'none', 'options' => self::label_opts() ],
			'show_date'       => [ 'label' => 'Дата', 'type' => 'checkbox', 'default' => 1 ],
			'date_format'     => [ 'label' => 'Формат на датата', 'type' => 'text', 'default' => 'j M. Y' ],
			'show_time'       => [ 'label' => 'Час', 'type' => 'checkbox', 'default' => 0 ],
			'show_views'      => [ 'label' => 'Брой прегледи', 'type' => 'checkbox', 'default' => 0 ],
			'show_excerpt'    => [ 'label' => 'Откъс', 'type' => 'checkbox', 'default' => 0 ],
			'show_share'      => [ 'label' => 'Бутон „Сподели“', 'type' => 'checkbox', 'default' => 0 ],
			'show_fmt_icon'   => [ 'label' => 'Икона според формата (видео, галерия, аудио)', 'type' => 'checkbox', 'default' => 1 ],
		];
	}
}

/* ================= Последни новини (вертикално) ================= */
class ENC_WP_Widget_Latest extends ENC_WP_Widget {
	public function __construct() {
		parent::__construct( 'enc_wp_latest', 'Newsroom: Последни новини', [ 'description' => 'Вертикален списък с последните новини и време „преди 6 минути“.' ] );
		$this->renderer = 'ENC_Render_Latest';
		$this->styles   = [ 'enc-latest' ];
		$this->scripts  = [ 'enc-latest' ];
		$this->fixed    = [ 'layout' => 'vertical', 'slider' => '' ];
		$this->fields   = [
			'categories'      => [ 'label' => 'Категории', 'type' => 'cats', 'default' => [] ],
			'posts_per_page'  => [ 'label' => 'Брой новини', 'type' => 'number', 'default' => 5, 'min' => 1, 'max' => 40 ],
			'orderby'         => [ 'label' => 'Подредба по', 'type' => 'select', 'default' => 'date', 'options' => self::orderby_opts() ],
			'days'            => [ 'label' => 'Само от последните N дни (0 = всички)', 'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 365 ],
			'exclude_current' => [ 'label' => 'Без текущата статия', 'type' => 'checkbox', 'default' => 1 ],
			'image_mode'      => [ 'label' => 'Снимки', 'type' => 'select', 'default' => 'none', 'options' => [ 'none' => 'Без снимки', 'all' => 'Със снимки' ] ],
			'image_pos'       => [ 'label' => 'Позиция на снимката', 'type' => 'select', 'default' => 'left', 'options' => [ 'left' => 'Отляво', 'right' => 'Отдясно', 'top' => 'Отгоре' ] ],
			'time_style'      => [ 'label' => 'Време', 'type' => 'select', 'default' => 'ago', 'options' => [
				'ago' => '„преди 6 минути“', 'time' => 'Час (14:14)', 'datetime' => 'Час и дата', 'date' => 'Само дата', 'none' => 'Без време',
			] ],
			'max_days'        => [ 'label' => 'Показвай датата след (дни)', 'type' => 'number', 'default' => 7, 'min' => 1, 'max' => 60 ],
			'date_format'     => [ 'label' => 'Формат на датата', 'type' => 'text', 'default' => 'd.m.y' ],
			'show_time_icon'  => [ 'label' => 'Икона на часовник', 'type' => 'checkbox', 'default' => 1 ],
			'uppercase'       => [ 'label' => 'Времето с ГЛАВНИ БУКВИ', 'type' => 'checkbox', 'default' => 1 ],
			'show_category'   => [ 'label' => 'Категория', 'type' => 'checkbox', 'default' => 0 ],
			'show_views'      => [ 'label' => 'Брой прегледи', 'type' => 'checkbox', 'default' => 0 ],
			'show_fmt_icon'   => [ 'label' => 'Икона според формата', 'type' => 'checkbox', 'default' => 1 ],
		];
	}
}

/* ================= Водеща и списък ================= */
class ENC_WP_Widget_Lead extends ENC_WP_Widget {
	public function __construct() {
		parent::__construct( 'enc_wp_lead', 'Newsroom: Водеща и списък', [ 'description' => 'Голяма водеща новина със заглавие върху снимката и списък под нея.' ] );
		$this->renderer = 'ENC_Render_Lead';
		$this->styles   = [ 'enc-news-lead' ];
		$this->scripts  = [ 'enc-single' ];
		$this->fields   = [
			'categories'      => [ 'label' => 'Категории', 'type' => 'cats', 'default' => [] ],
			'list_count'      => [ 'label' => 'Колко новини под водещата', 'type' => 'number', 'default' => 2, 'min' => 0, 'max' => 20 ],
			'orderby'         => [ 'label' => 'Подредба по', 'type' => 'select', 'default' => 'date', 'options' => self::orderby_opts() ],
			'days'            => [ 'label' => 'Само от последните N дни (0 = всички)', 'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 365 ],
			'exclude_current' => [ 'label' => 'Без текущата статия', 'type' => 'checkbox', 'default' => 1 ],
			'list_images'     => [ 'label' => 'Снимки в списъка', 'type' => 'select', 'default' => 'none', 'options' => [ 'none' => 'Без снимки', 'all' => 'Със снимки' ] ],
			'meta_label'      => [ 'label' => 'Етикет в реда под заглавието', 'type' => 'select', 'default' => 'none', 'options' => self::label_opts() ],
			'show_time'       => [ 'label' => 'Час', 'type' => 'checkbox', 'default' => 1 ],
			'show_date'       => [ 'label' => 'Дата', 'type' => 'checkbox', 'default' => 1 ],
			'date_format'     => [ 'label' => 'Формат на датата', 'type' => 'text', 'default' => 'd.m.y' ],
			'show_views'      => [ 'label' => 'Брой прегледи', 'type' => 'checkbox', 'default' => 1 ],
			'show_share'      => [ 'label' => 'Бутон „Сподели“', 'type' => 'checkbox', 'default' => 1 ],
			'show_category'   => [ 'label' => 'Етикет на категорията върху водещата снимка', 'type' => 'checkbox', 'default' => 0 ],
			'show_excerpt'    => [ 'label' => 'Откъс при водещата', 'type' => 'checkbox', 'default' => 0 ],
			'show_fmt_icon'   => [ 'label' => 'Икона според формата', 'type' => 'checkbox', 'default' => 1 ],
		];
	}
}

/* ================= Новини – списък ================= */
class ENC_WP_Widget_List extends ENC_WP_Widget {
	public function __construct() {
		parent::__construct( 'enc_wp_list', 'Newsroom: Новини – списък', [ 'description' => 'Списък с новини, по желание със снимка при първите.' ] );
		$this->renderer = 'ENC_Render_List';
		$this->styles   = [ 'enc-news-list' ];
		$this->scripts  = [ 'enc-single' ];
		$this->fields   = [
			'categories'      => [ 'label' => 'Категории', 'type' => 'cats', 'default' => [] ],
			'posts_per_page'  => [ 'label' => 'Брой новини', 'type' => 'number', 'default' => 5, 'min' => 1, 'max' => 30 ],
			'offset'          => [ 'label' => 'Пропусни първите', 'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 30 ],
			'orderby'         => [ 'label' => 'Подредба по', 'type' => 'select', 'default' => 'date', 'options' => self::orderby_opts() ],
			'days'            => [ 'label' => 'Само от последните N дни (0 = всички)', 'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 365 ],
			'exclude_current' => [ 'label' => 'Без текущата статия', 'type' => 'checkbox', 'default' => 1 ],
			'image_mode'      => [ 'label' => 'Снимки', 'type' => 'select', 'default' => 'first', 'options' => [ 'all' => 'При всички новини', 'first' => 'Само при първите N', 'none' => 'Без снимки' ] ],
			'image_count'     => [ 'label' => 'При колко от първите (за „Само при първите N“)', 'type' => 'number', 'default' => 1, 'min' => 1, 'max' => 10 ],
			'image_pos'       => [ 'label' => 'Позиция на снимката', 'type' => 'select', 'default' => 'left', 'options' => [ 'left' => 'Отляво', 'right' => 'Отдясно' ] ],
			'split_first'     => [ 'label' => 'Първата новина в отделна карта', 'type' => 'checkbox', 'default' => 1 ],
			'meta_label'      => [ 'label' => 'Етикет в реда под заглавието', 'type' => 'select', 'default' => 'category', 'options' => self::label_opts() ],
			'show_time'       => [ 'label' => 'Час', 'type' => 'checkbox', 'default' => 1 ],
			'show_date'       => [ 'label' => 'Дата', 'type' => 'checkbox', 'default' => 1 ],
			'date_format'     => [ 'label' => 'Формат на датата', 'type' => 'text', 'default' => 'd.m.y' ],
			'show_views'      => [ 'label' => 'Брой прегледи', 'type' => 'checkbox', 'default' => 1 ],
			'show_share'      => [ 'label' => 'Бутон „Сподели“', 'type' => 'checkbox', 'default' => 1 ],
			'show_excerpt'    => [ 'label' => 'Откъс', 'type' => 'checkbox', 'default' => 0 ],
			'show_fmt_icon'   => [ 'label' => 'Икона според формата', 'type' => 'checkbox', 'default' => 1 ],
		];
	}
}

add_action( 'widgets_init', function () {
	register_widget( 'ENC_WP_Widget_Top' );
	register_widget( 'ENC_WP_Widget_Latest' );
	register_widget( 'ENC_WP_Widget_Lead' );
	register_widget( 'ENC_WP_Widget_List' );
} );

/* CSS и JS се зареждат в <head> само ако джаджата е активна в някоя област */
add_action( 'wp_enqueue_scripts', function () {
	$map = [
		'enc_wp_top'    => [ [ 'enc-news-top' ], [ 'enc-single' ] ],
		'enc_wp_latest' => [ [ 'enc-latest' ], [ 'enc-latest' ] ],
		'enc_wp_lead'   => [ [ 'enc-news-lead' ], [ 'enc-single' ] ],
		'enc_wp_list'   => [ [ 'enc-news-list' ], [ 'enc-single' ] ],
	];
	foreach ( $map as $base => $assets ) {
		if ( is_active_widget( false, false, $base, true ) ) {
			foreach ( $assets[0] as $h ) {
				wp_enqueue_style( $h );
			}
			foreach ( $assets[1] as $h ) {
				wp_enqueue_script( $h );
			}
		}
	}
}, 30 );
