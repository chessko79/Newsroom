<?php
/**
 * Свързани новини под статията: настройки (таб „Свързани новини“) и рендериране на картите.
 * Всички настройки са в един запис (enc_related); стиловете се подават като CSS променливи на секцията.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- Схема на настройките ---------- */
function enc_rel_schema() {
	$sizes = [];
	foreach ( get_intermediate_image_sizes() as $sz ) {
		$sizes[ $sz ] = $sz;
	}
	$sizes['full'] = 'full';

	$weights = [ '400' => 'Нормално (400)', '500' => 'Средно (500)', '600' => 'Полужирно (600)', '700' => 'Удебелено (700)', '800' => 'Силно удебелено (800)' ];
	$tags    = [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'div' => 'div' ];

	return [
		/* — Свързване — */
		'mode'         => [ 'g' => 'Свързване', 'label' => 'Свързвай новините', 'type' => 'select', 'default' => 'category',
			'options' => [ 'category' => 'По категория', 'tag' => 'По таг', 'off' => 'Изключени (не показвай секцията)' ] ],
		'count'        => [ 'g' => 'Свързване', 'label' => 'Брой новини', 'type' => 'number', 'default' => 3, 'min' => 1, 'max' => 12 ],
		'orderby'      => [ 'g' => 'Свързване', 'label' => 'Подредба по', 'type' => 'select', 'default' => 'date', 'options' => [
			'date' => 'Дата (най-новите)', 'views' => 'Прегледи (най-четени)', 'comment_count' => 'Коментари',
			'modified' => 'Последна промяна', 'title' => 'Заглавие', 'rand' => 'Случайно',
		] ],

		/* — Подредба — */
		'cols'         => [ 'g' => 'Подредба', 'label' => 'Колони (компютър)', 'type' => 'select', 'default' => '3', 'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ] ],
		'cols_t'       => [ 'g' => 'Подредба', 'label' => 'Колони (таблет)', 'type' => 'select', 'default' => '3', 'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ] ],
		'cols_m'       => [ 'g' => 'Подредба', 'label' => 'Колони (телефон)', 'type' => 'select', 'default' => '1', 'options' => [ '1' => '1', '2' => '2', '3' => '3' ] ],
		'gap'          => [ 'g' => 'Подредба', 'label' => 'Разстояние между картите (px)', 'type' => 'number', 'default' => 20, 'min' => 0, 'max' => 60 ],

		/* — Заглавие на секцията — */
		'heading_show'   => [ 'g' => 'Заглавие на секцията', 'label' => 'Показвай заглавие', 'type' => 'checkbox', 'default' => 1 ],
		'heading_text'   => [ 'g' => 'Заглавие на секцията', 'label' => 'Текст', 'type' => 'text', 'default' => 'Свързани новини' ],
		'heading_tag'    => [ 'g' => 'Заглавие на секцията', 'label' => 'HTML таг', 'type' => 'select', 'default' => 'h2', 'options' => $tags ],
		'heading_color'  => [ 'g' => 'Заглавие на секцията', 'label' => 'Цвят', 'type' => 'color', 'default' => '' ],
		'heading_size'   => [ 'g' => 'Заглавие на секцията', 'label' => 'Размер на шрифта (px)', 'type' => 'number', 'default' => 22, 'min' => 12, 'max' => 48 ],
		'heading_weight' => [ 'g' => 'Заглавие на секцията', 'label' => 'Дебелина на шрифта', 'type' => 'select', 'default' => '800', 'options' => $weights ],

		/* — Елементи на картата — */
		'show_image'    => [ 'g' => 'Елементи на картата', 'label' => 'Показвай снимка', 'type' => 'checkbox', 'default' => 1 ],
		'image_size'    => [ 'g' => 'Елементи на картата', 'label' => 'Размер на снимката', 'type' => 'select', 'default' => 'medium_large', 'options' => $sizes ],
		'ratio'         => [ 'g' => 'Елементи на картата', 'label' => 'Пропорция на снимката', 'type' => 'select', 'default' => '16 / 10', 'options' => [
			'16 / 9' => '16:9', '16 / 10' => '16:10', '3 / 2' => '3:2', '4 / 3' => '4:3', '1 / 1' => '1:1',
		] ],
		'zoom'          => [ 'g' => 'Елементи на картата', 'label' => 'Увеличаване на снимката при посочване', 'type' => 'checkbox', 'default' => 1 ],
		'fmt_icon'      => [ 'g' => 'Елементи на картата', 'label' => 'Икона според формата (видео, галерия, аудио)', 'type' => 'checkbox', 'default' => 1 ],
		'show_category' => [ 'g' => 'Елементи на картата', 'label' => 'Етикет на категорията', 'type' => 'checkbox', 'default' => 1 ],
		'badge_color'   => [ 'g' => 'Елементи на картата', 'label' => 'Фон на етикета (празно = автоматично по категория)', 'type' => 'color', 'default' => '' ],
		'badge_text'    => [ 'g' => 'Елементи на картата', 'label' => 'Цвят на текста на етикета', 'type' => 'color', 'default' => '' ],
		'show_date'     => [ 'g' => 'Елементи на картата', 'label' => 'Дата', 'type' => 'checkbox', 'default' => 1 ],
		'date_format'   => [ 'g' => 'Елементи на картата', 'label' => 'Формат на датата', 'type' => 'text', 'default' => 'j M. Y' ],
		'show_views'    => [ 'g' => 'Елементи на картата', 'label' => 'Брой прегледи', 'type' => 'checkbox', 'default' => 1 ],
		'show_excerpt'  => [ 'g' => 'Елементи на картата', 'label' => 'Откъс', 'type' => 'checkbox', 'default' => 0 ],
		'excerpt_len'   => [ 'g' => 'Елементи на картата', 'label' => 'Думи в откъса', 'type' => 'number', 'default' => 18, 'min' => 5, 'max' => 60 ],
		'show_more'     => [ 'g' => 'Елементи на картата', 'label' => 'Линк „Прочети повече“', 'type' => 'checkbox', 'default' => 0 ],
		'more_text'     => [ 'g' => 'Елементи на картата', 'label' => 'Текст на линка', 'type' => 'text', 'default' => 'Прочети повече' ],

		/* — Стил на картата — */
		'card_bg'           => [ 'g' => 'Стил на картата', 'label' => 'Фон на картата', 'type' => 'color', 'default' => '' ],
		'card_radius'       => [ 'g' => 'Стил на картата', 'label' => 'Радиус на ъглите (px)', 'type' => 'number', 'default' => 12, 'min' => 0, 'max' => 40 ],
		'card_shadow'       => [ 'g' => 'Стил на картата', 'label' => 'Сянка', 'type' => 'select', 'default' => 'soft', 'options' => [ 'none' => 'Без сянка', 'soft' => 'Лека', 'strong' => 'Силна' ] ],
		'card_border_w'     => [ 'g' => 'Стил на картата', 'label' => 'Дебелина на контура (px)', 'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 6 ],
		'card_border_color' => [ 'g' => 'Стил на картата', 'label' => 'Цвят на контура', 'type' => 'color', 'default' => '' ],
		'body_pad'          => [ 'g' => 'Стил на картата', 'label' => 'Вътрешен отстъп на текста (px)', 'type' => 'number', 'default' => 16, 'min' => 0, 'max' => 40 ],

		/* — Заглавие на новината — */
		'title_tag'    => [ 'g' => 'Заглавие на новината', 'label' => 'HTML таг', 'type' => 'select', 'default' => 'h3', 'options' => $tags ],
		'title_color'  => [ 'g' => 'Заглавие на новината', 'label' => 'Цвят', 'type' => 'color', 'default' => '' ],
		'title_hover'  => [ 'g' => 'Заглавие на новината', 'label' => 'Цвят при посочване', 'type' => 'color', 'default' => '' ],
		'title_size'   => [ 'g' => 'Заглавие на новината', 'label' => 'Размер на шрифта (px)', 'type' => 'number', 'default' => 16, 'min' => 10, 'max' => 32 ],
		'title_weight' => [ 'g' => 'Заглавие на новината', 'label' => 'Дебелина на шрифта', 'type' => 'select', 'default' => '700', 'options' => $weights ],
		'title_lines'  => [ 'g' => 'Заглавие на новината', 'label' => 'Максимум редове', 'type' => 'number', 'default' => 3, 'min' => 1, 'max' => 6 ],

		/* — Дата, категория и прегледи — */
		'meta_color' => [ 'g' => 'Дата и прегледи', 'label' => 'Цвят на текста', 'type' => 'color', 'default' => '' ],
		'meta_size'  => [ 'g' => 'Дата и прегледи', 'label' => 'Размер на шрифта (px)', 'type' => 'number', 'default' => 13, 'min' => 10, 'max' => 20 ],
	];
}

/* Текущите настройки (с преместване на старата настройка „enc_related_news“) */
function enc_rel_opts() {
	$out = [];
	foreach ( enc_rel_schema() as $k => $f ) {
		$out[ $k ] = $f['default'];
	}
	$saved = get_option( 'enc_related', [] );
	$saved = is_array( $saved ) ? $saved : [];
	if ( ! isset( $saved['mode'] ) ) {
		$old = get_option( 'enc_related_news' );
		if ( in_array( $old, [ 'tag', 'category', 'off' ], true ) ) {
			$saved['mode'] = $old;
		}
	}
	return array_merge( $out, $saved );
}

function enc_rel_sanitize( $in ) {
	$in  = is_array( $in ) ? $in : [];
	$out = [];
	foreach ( enc_rel_schema() as $k => $f ) {
		$v = isset( $in[ $k ] ) ? $in[ $k ] : null;
		switch ( $f['type'] ) {
			case 'checkbox':
				$out[ $k ] = empty( $v ) ? 0 : 1;
				break;
			case 'number':
				$out[ $k ] = min( (int) $f['max'], max( (int) $f['min'], (int) $v ) );
				break;
			case 'select':
				$out[ $k ] = ( null !== $v && isset( $f['options'][ $v ] ) ) ? (string) $v : (string) $f['default'];
				break;
			case 'color':
				$c         = sanitize_hex_color( (string) $v );
				$out[ $k ] = $c ? $c : '';
				break;
			default:
				$out[ $k ] = null === $v ? $f['default'] : sanitize_text_field( $v );
		}
	}
	return $out;
}

add_action( 'admin_init', function () {
	register_setting( 'enc_settings_related', 'enc_related', [ 'type' => 'array', 'sanitize_callback' => 'enc_rel_sanitize' ] );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'settings_page_enc-settings' !== $hook || ! isset( $_GET['tab'] ) || ! in_array( sanitize_key( wp_unslash( $_GET['tab'] ) ), [ 'related', 'archive' ], true ) ) {
		return;
	}
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".enc-color-field").wpColorPicker();});' );
} );

/* ---------- Табове на страницата с настройки ---------- */
function enc_settings_tabs( $current ) {
	$base = admin_url( 'options-general.php?page=enc-settings' );
	echo '<h2 class="nav-tab-wrapper" style="margin-bottom:16px">';
	echo '<a href="' . esc_url( $base ) . '" class="nav-tab' . ( 'general' === $current ? ' nav-tab-active' : '' ) . '">Общи</a>';
	echo '<a href="' . esc_url( $base . '&tab=related' ) . '" class="nav-tab' . ( 'related' === $current ? ' nav-tab-active' : '' ) . '">Свързани новини</a>';
	echo '<a href="' . esc_url( $base . '&tab=archive' ) . '" class="nav-tab' . ( 'archive' === $current ? ' nav-tab-active' : '' ) . '">Архиви</a>';
	echo '</h2>';
}

/* ---------- Таб „Свързани новини“ ---------- */
function enc_settings_related_tab() {
	$o      = enc_rel_opts();
	$groups = [];
	foreach ( enc_rel_schema() as $k => $f ) {
		$groups[ $f['g'] ][ $k ] = $f;
	}
	?>
	<form method="post" action="options.php">
		<?php settings_fields( 'enc_settings_related' ); ?>
		<p class="description">Под текста на статията се показват свързани новини като карти. Празните цветове ползват стандартните цветове на шаблона.</p>
		<?php foreach ( $groups as $title => $fields ) : ?>
			<h2 class="title"><?php echo esc_html( $title ); ?></h2>
			<table class="form-table" role="presentation">
				<?php foreach ( $fields as $key => $f ) :
					$id   = 'enc_rel_' . $key;
					$name = 'enc_related[' . $key . ']';
					$val  = $o[ $key ];
					?>
					<tr>
						<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $f['label'] ); ?></label></th>
						<td>
							<?php
							switch ( $f['type'] ) {
								case 'checkbox':
									printf( '<input type="checkbox" id="%s" name="%s" value="1" %s>', esc_attr( $id ), esc_attr( $name ), checked( ! empty( $val ), true, false ) );
									break;
								case 'number':
									printf( '<input type="number" class="small-text" id="%s" name="%s" min="%d" max="%d" value="%d">', esc_attr( $id ), esc_attr( $name ), (int) $f['min'], (int) $f['max'], (int) $val );
									break;
								case 'select':
									echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
									foreach ( $f['options'] as $ov => $ol ) {
										echo '<option value="' . esc_attr( $ov ) . '"' . selected( (string) $val, (string) $ov, false ) . '>' . esc_html( $ol ) . '</option>';
									}
									echo '</select>';
									break;
								case 'color':
									printf( '<input type="text" class="enc-color-field" id="%s" name="%s" value="%s">', esc_attr( $id ), esc_attr( $name ), esc_attr( $val ) );
									break;
								default:
									printf( '<input type="text" class="regular-text" id="%s" name="%s" value="%s">', esc_attr( $id ), esc_attr( $name ), esc_attr( $val ) );
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		<?php endforeach; ?>
		<?php submit_button(); ?>
	</form>
	<?php
}

/* ---------- Рендериране под статията ---------- */
function enc_render_related_news( $post_id ) {
	$o = enc_rel_opts();
	if ( ! in_array( $o['mode'], [ 'tag', 'category' ], true ) ) {
		return;
	}
	$post_id = (int) $post_id;

	if ( 'tag' === $o['mode'] ) {
		$ids = wp_get_post_tags( $post_id, [ 'fields' => 'ids' ] );
	} else {
		// Категорията по подразбиране („Без категория“) не свързва нищо смислено
		$ids = array_diff( array_map( 'intval', (array) wp_get_post_categories( $post_id ) ), [ (int) get_option( 'default_category' ) ] );
	}
	$ids = is_wp_error( $ids ) ? [] : array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
	if ( ! $ids ) {
		return;
	}

	$args = [
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => (int) $o['count'],
		'post__not_in'        => [ $post_id ],
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		( 'tag' === $o['mode'] ? 'tag__in' : 'category__in' ) => $ids,
	];
	if ( 'views' === $o['orderby'] ) {
		$args['meta_query'] = [
			'relation' => 'OR',
			'enc_v'    => [ 'key' => 'enc_views', 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
			[ 'key' => 'enc_views', 'compare' => 'NOT EXISTS' ],
		];
		$args['orderby'] = [ 'enc_v' => 'DESC', 'date' => 'DESC' ];
	} else {
		$args['orderby'] = $o['orderby'];
		$args['order']   = 'title' === $o['orderby'] ? 'ASC' : 'DESC';
	}

	$q = new WP_Query( $args );
	if ( ! $q->have_posts() ) {
		return;
	}

	/* CSS променливи на секцията */
	$shadows = [ 'none' => 'none', 'soft' => '0 1px 4px rgba(16,40,90,.12)', 'strong' => '0 8px 24px rgba(16,40,90,.18)' ];
	$vars    = [
		'--rel-cols'         => (int) $o['cols'],
		'--rel-cols-t'       => (int) $o['cols_t'],
		'--rel-cols-m'       => (int) $o['cols_m'],
		'--rel-gap'          => (int) $o['gap'] . 'px',
		'--rel-radius'       => (int) $o['card_radius'] . 'px',
		'--rel-pad'          => (int) $o['body_pad'] . 'px',
		'--rel-ratio'        => $o['ratio'],
		'--rel-shadow'       => $shadows[ $o['card_shadow'] ],
		'--rel-title-size'   => (int) $o['title_size'] . 'px',
		'--rel-title-weight' => (int) $o['title_weight'],
		'--rel-title-lines'  => (int) $o['title_lines'],
		'--rel-meta-size'    => (int) $o['meta_size'] . 'px',
		'--rel-h-size'       => (int) $o['heading_size'] . 'px',
		'--rel-h-weight'     => (int) $o['heading_weight'],
	];
	$colors = [
		'--rel-bg' => 'card_bg', '--rel-title-color' => 'title_color', '--rel-title-hover' => 'title_hover',
		'--rel-meta-color' => 'meta_color', '--rel-h-color' => 'heading_color', '--rel-badge-color' => 'badge_text',
	];
	foreach ( $colors as $var => $key ) {
		if ( '' !== $o[ $key ] ) {
			$vars[ $var ] = $o[ $key ];
		}
	}
	if ( (int) $o['card_border_w'] > 0 ) {
		$vars['--rel-border'] = (int) $o['card_border_w'] . 'px solid ' . ( '' !== $o['card_border_color'] ? $o['card_border_color'] : '#e3e7ee' );
	}
	$style = '';
	foreach ( $vars as $k => $v ) {
		$style .= $k . ':' . $v . ';';
	}

	$palette = [ '#1e6fd9', '#12945a', '#f5a30a', '#d6455d', '#7a4fd1', '#0e8f9c' ];
	$eye     = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
	$h_tag   = in_array( $o['heading_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $o['heading_tag'] : 'h2';
	$t_tag   = in_array( $o['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $o['title_tag'] : 'h3';

	echo '<section class="enc-article enc-article--rel' . ( $o['zoom'] ? ' enc-relnews--zoom' : '' ) . '" style="' . esc_attr( $style ) . '" aria-label="' . esc_attr( $o['heading_text'] ) . '">';
	if ( $o['heading_show'] && '' !== $o['heading_text'] ) {
		echo '<' . $h_tag . ' class="enc-relnews__heading">' . esc_html( $o['heading_text'] ) . '</' . $h_tag . '>';
	}
	echo '<div class="enc-relnews__grid">';

	while ( $q->have_posts() ) {
		$q->the_post();
		$id      = get_the_ID();
		$link    = get_permalink();
		$title   = get_the_title();
		$has_img = $o['show_image'] && has_post_thumbnail();
		$fmt     = $o['fmt_icon']
			? enc_format_icons( $id, [ 'show_fmt_icon' => 'yes', 'fmt_icons' => [ 'gallery', 'video', 'audio' ], 'fmt_icon_pos' => 'tr' ], $has_img )
			: [ 'overlay' => '', 'inline' => '' ];

		$meta = $fmt['inline'];
		if ( $o['show_category'] ) {
			$cats = get_the_category( $id );
			if ( $cats ) {
				$c     = $cats[0];
				$bg    = '' !== $o['badge_color'] ? $o['badge_color'] : enc_cat_color( $c->term_id );
				$meta .= '<a class="enc-relnews__badge" style="background-color:' . esc_attr( $bg ) . '" href="' . esc_url( get_category_link( $c ) ) . '">' . esc_html( $c->name ) . '</a>';
			}
		}
		if ( $o['show_date'] ) {
			$meta .= '<time datetime="' . esc_attr( get_the_date( 'c' ) ) . '">' . esc_html( get_the_date( $o['date_format'] ? $o['date_format'] : 'j M. Y' ) ) . '</time>';
		}
		if ( $o['show_views'] ) {
			$meta .= '<span class="enc-relnews__views">' . $eye . '<span>' . (int) get_post_meta( $id, 'enc_views', true ) . '</span></span>';
		}

		echo '<article class="enc-relnews__card">';
		if ( $o['show_image'] ) {
			echo '<a class="enc-relnews__media" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">';
			if ( has_post_thumbnail() ) {
				echo get_the_post_thumbnail( $id, $o['image_size'], [ 'loading' => 'lazy', 'alt' => '' ] ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</a>';
		}
		echo '<div class="enc-relnews__body">';
		echo '<' . $t_tag . ' class="enc-relnews__title"><a href="' . esc_url( $link ) . '">' . esc_html( $title ) . '</a></' . $t_tag . '>';
		if ( $o['show_excerpt'] ) {
			echo '<p class="enc-relnews__excerpt">' . esc_html( wp_trim_words( get_the_excerpt(), (int) $o['excerpt_len'] ) ) . '</p>';
		}
		if ( $meta ) {
			echo '<div class="enc-relnews__meta">' . $meta . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( $o['show_more'] ) {
			echo '<a class="enc-relnews__more" href="' . esc_url( $link ) . '">' . esc_html( $o['more_text'] ) . ' →</a>';
		}
		echo '</div></article>';
	}
	wp_reset_postdata();

	echo '</div></section>';
}
