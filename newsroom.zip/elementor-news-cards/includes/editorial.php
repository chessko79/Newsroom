<?php
/**
 * Редакторски функции: цветове на категориите, закачени новини, „Обновена“ + бележка за корекция, „На живо“.
 * Леко: няма зареждане на CSS/JS на страници, където функциите не се ползват.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =====================================================================
 * 1) Цветове на категориите (редакция на категория → „Цвят на категорията“)
 * ===================================================================== */
function enc_all_term_colors() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$cache = [];
	$ids   = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false, 'fields' => 'ids' ] );
	if ( is_wp_error( $ids ) || ! $ids ) {
		return $cache;
	}
	update_termmeta_cache( $ids );
	foreach ( $ids as $tid ) {
		$c = get_term_meta( $tid, 'enc_color', true );
		if ( $c ) {
			$cache[ (int) $tid ] = $c;
		}
	}
	return $cache;
}

/* Цвят на категорията: зададения или автоматичен от палитра */
function enc_cat_color( $term_id ) {
	$all = enc_all_term_colors();
	if ( isset( $all[ (int) $term_id ] ) ) {
		return $all[ (int) $term_id ];
	}
	$pal = [ '#1e6fd9', '#12945a', '#f5a30a', '#d6455d', '#7a4fd1', '#0e8f9c' ];
	return $pal[ (int) $term_id % count( $pal ) ];
}

add_action( 'category_add_form_fields', function () {
	?>
	<div class="form-field">
		<label for="enc_color">Цвят на категорията</label>
		<input type="text" name="enc_color" id="enc_color" class="enc-term-color" value="">
		<p>Ползва се за етикетите на категорията в картите и в статията. Празно = автоматичен цвят.</p>
	</div>
	<?php
} );

add_action( 'category_edit_form_fields', function ( $term ) {
	$c = get_term_meta( $term->term_id, 'enc_color', true );
	?>
	<tr class="form-field">
		<th scope="row"><label for="enc_color">Цвят на категорията</label></th>
		<td>
			<input type="text" name="enc_color" id="enc_color" class="enc-term-color" value="<?php echo esc_attr( $c ); ?>">
			<p class="description">Ползва се за етикетите на категорията в картите и в статията. Празно = автоматичен цвят.</p>
		</td>
	</tr>
	<?php
} );

function enc_save_term_color( $term_id ) {
	if ( ! isset( $_POST['enc_color'] ) || ! current_user_can( 'manage_categories' ) ) {
		return;
	}
	$c = sanitize_hex_color( wp_unslash( $_POST['enc_color'] ) );
	if ( $c ) {
		update_term_meta( $term_id, 'enc_color', $c );
	} else {
		delete_term_meta( $term_id, 'enc_color' );
	}
}
add_action( 'created_category', 'enc_save_term_color' );
add_action( 'edited_category', 'enc_save_term_color' );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, [ 'edit-tags.php', 'term.php' ], true ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! $screen || 'category' !== $screen->taxonomy ) {
		return;
	}
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	wp_add_inline_script( 'wp-color-picker', 'jQuery(function($){$(".enc-term-color").wpColorPicker();});' );
} );

/* =====================================================================
 * 2) Закачени (водещи) новини – ползват се от филтъра „Само закачените“ в уиджета „Новини – заглавие върху снимка“
 * ===================================================================== */
add_filter( 'display_post_states', function ( $states, $post ) {
	if ( get_post_meta( $post->ID, 'enc_pinned', true ) ) {
		$states['enc_pinned'] = 'Закачена';
	}
	if ( '1' === (string) get_post_meta( $post->ID, 'enc_live_on', true ) ) {
		$states['enc_live'] = 'На живо';
	}
	return $states;
}, 10, 2 );

/* =====================================================================
 * 3) Мета кутии в редактора
 * ===================================================================== */
function enc_note_labels() {
	return [ 'correction' => 'Корекция', 'clarification' => 'Уточнение', 'addition' => 'Допълнение', 'note' => 'Бележка' ];
}

function enc_can_save( $post_id, $nonce_field, $action ) {
	if ( ! isset( $_POST[ $nonce_field ] ) || ! wp_verify_nonce( wp_unslash( $_POST[ $nonce_field ] ), $action ) ) {
		return false;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
		return false;
	}
	return current_user_can( 'edit_post', $post_id );
}

add_action( 'add_meta_boxes', function () {
	foreach ( enc_view_post_types() as $pt ) {
		add_meta_box( 'enc_editorial', ENC_NAME, 'enc_editorial_box_html', $pt, 'side', 'high' );
		add_meta_box( 'enc_live_box', 'На живо', 'enc_live_box_html', $pt, 'normal', 'high' );
	}
} );

function enc_editorial_box_html( $post ) {
	wp_nonce_field( 'enc_editorial', 'enc_editorial_nonce' );
	$pinned = (int) get_post_meta( $post->ID, 'enc_pinned', true );
	$note   = (string) get_post_meta( $post->ID, 'enc_note', true );
	$ntype  = (string) get_post_meta( $post->ID, 'enc_note_type', true );
	$upd    = (int) get_post_meta( $post->ID, 'enc_updated', true );
	?>
	<p>
		<label><input type="checkbox" name="enc_pinned" value="1" <?php checked( $pinned > 0 ); ?>> <strong>Закачена (водеща) новина</strong></label><br>
		<span class="description">Показва се в уиджета „Новини – заглавие върху снимка“, когато в него е включен филтърът „Само закачените“.</span>
	</p>
	<hr>
	<p><strong>Бележка под заглавието</strong></p>
	<p>
		<select name="enc_note_type" style="width:100%">
			<?php foreach ( enc_note_labels() as $k => $l ) : ?>
				<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $ntype ? $ntype : 'correction', $k ); ?>><?php echo esc_html( $l ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<p><textarea name="enc_note" rows="3" style="width:100%" placeholder="Напр.: В първоначалния вариант името беше изписано грешно."><?php echo esc_textarea( $note ); ?></textarea></p>
	<p class="description">Оставете празно, за да не се показва бележка.</p>
	<hr>
	<p><strong>Обновена</strong></p>
	<?php if ( $upd ) : ?>
		<p>Отбелязана: <?php echo esc_html( wp_date( 'j M. Y, H:i', $upd ) ); ?></p>
		<p><label><input type="checkbox" name="enc_clear_updated" value="1"> Премахни отбелязването</label></p>
	<?php endif; ?>
	<p><label><input type="checkbox" name="enc_mark_updated" value="1"> Отбележи като обновена сега</label></p>
	<?php
}

add_action( 'save_post', function ( $post_id ) {
	if ( ! enc_can_save( $post_id, 'enc_editorial_nonce', 'enc_editorial' ) ) {
		return;
	}

	// Закачена
	if ( ! empty( $_POST['enc_pinned'] ) ) {
		if ( ! get_post_meta( $post_id, 'enc_pinned', true ) ) {
			update_post_meta( $post_id, 'enc_pinned', time() );
		}
	} else {
		delete_post_meta( $post_id, 'enc_pinned' );
	}

	// Бележка
	$note  = isset( $_POST['enc_note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['enc_note'] ) ) : '';
	$ntype = isset( $_POST['enc_note_type'] ) ? sanitize_key( wp_unslash( $_POST['enc_note_type'] ) ) : 'correction';
	if ( '' !== $note ) {
		update_post_meta( $post_id, 'enc_note', $note );
		update_post_meta( $post_id, 'enc_note_type', isset( enc_note_labels()[ $ntype ] ) ? $ntype : 'correction' );
	} else {
		delete_post_meta( $post_id, 'enc_note' );
		delete_post_meta( $post_id, 'enc_note_type' );
	}

	// Обновена
	if ( ! empty( $_POST['enc_clear_updated'] ) ) {
		delete_post_meta( $post_id, 'enc_updated' );
	} elseif ( ! empty( $_POST['enc_mark_updated'] ) ) {
		update_post_meta( $post_id, 'enc_updated', time() );
	}
} );

/* =====================================================================
 * 4) „На живо“ – хронологични обновления в една статия
 * ===================================================================== */
function enc_is_live( $id ) {
	return '1' === (string) get_post_meta( $id, 'enc_live_on', true );
}

function enc_live_entries( $id ) {
	$e = get_post_meta( $id, 'enc_live', true );
	if ( ! is_array( $e ) ) {
		return [];
	}
	$e = array_values( array_filter( $e, function ( $x ) {
		return is_array( $x ) && isset( $x['id'], $x['ts'], $x['text'] );
	} ) );
	usort( $e, function ( $a, $b ) {
		return (int) $b['ts'] - (int) $a['ts'];
	} );
	return $e;
}

function enc_live_time_label( $ts ) {
	return wp_date( 'Y-m-d', $ts ) === wp_date( 'Y-m-d' ) ? wp_date( 'H:i', $ts ) : wp_date( 'j M. H:i', $ts );
}

function enc_live_entry_html( $e, $is_new = false ) {
	$ts    = (int) $e['ts'];
	$title = isset( $e['title'] ) ? trim( (string) $e['title'] ) : '';
	$html  = '<li class="enc-live__item' . ( $is_new ? ' is-new' : '' ) . '" id="live-' . esc_attr( $e['id'] ) . '" data-ts="' . $ts . '">';
	$html .= '<div class="enc-live__time"><time datetime="' . esc_attr( gmdate( 'c', $ts ) ) . '">' . esc_html( enc_live_time_label( $ts ) ) . '</time></div>';
	$html .= '<div class="enc-live__body">';
	if ( '' !== $title ) {
		$html .= '<h3 class="enc-live__title">' . esc_html( $title ) . '</h3>';
	}
	$html .= '<div class="enc-live__text">' . wpautop( wp_kses_post( $e['text'] ) ) . '</div>';
	$html .= '</div></li>';
	return $html;
}

function enc_live_upd_text( $id ) {
	$entries = enc_live_entries( $id );
	return $entries ? 'Последно обновление: ' . enc_live_time_label( (int) $entries[0]['ts'] ) : '';
}

/* Секцията „На живо“ (под текста на статията; може и с кратък код [enc_live]) */
function enc_render_live( $id ) {
	$id      = (int) $id;
	$on      = enc_is_live( $id );
	$entries = enc_live_entries( $id );
	if ( ! $on && ! $entries ) {
		return;
	}
	if ( $on ) {
		wp_enqueue_script( 'enc-live' );
	}
	$last = $entries ? (int) $entries[0]['ts'] : 0;

	echo '<section class="enc-live' . ( $on ? ' is-live' : '' ) . '" data-live="' . ( $on ? '1' : '0' ) . '" data-id="' . $id . '" data-last="' . $last . '" data-url="' . esc_url( rest_url( 'enc/v1/live' ) ) . '" aria-label="Хронология на събитието">';
	echo '<div class="enc-live__head">';
	if ( $on ) {
		echo '<span class="enc-live-badge">На живо</span>';
	}
	echo '<span class="enc-live__upd">' . esc_html( enc_live_upd_text( $id ) ) . '</span></div>';
	echo '<ol class="enc-live__list">';
	foreach ( $entries as $e ) {
		echo enc_live_entry_html( $e ); // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</ol>';
	if ( $on && ! $entries ) {
		echo '<p class="enc-live__empty">Очаквайте първите обновления…</p>';
	}
	echo '</section>';
}

add_shortcode( 'enc_live', function () {
	ob_start();
	enc_render_live( get_the_ID() );
	return ob_get_clean();
} );

add_action( 'wp_enqueue_scripts', function () {
	wp_register_script( 'enc-live', ENC_URL . 'assets/live.js', [], ENC_VERSION, true );
}, 5 );

/* REST: нови обновления (за автоматичното опресняване) */
add_action( 'rest_api_init', function () {
	register_rest_route( 'enc/v1', '/live', [
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'args'                => [
			'id'    => [ 'required' => true, 'sanitize_callback' => 'absint' ],
			'after' => [ 'default' => 0, 'sanitize_callback' => 'absint' ],
		],
		'callback'            => function ( WP_REST_Request $req ) {
			$id = (int) $req->get_param( 'id' );
			if ( 'publish' !== get_post_status( $id ) ) {
				return new WP_Error( 'enc_not_found', 'Не е намерено.', [ 'status' => 404 ] );
			}
			$after = (int) $req->get_param( 'after' );
			$items = [];
			$max   = $after;
			foreach ( enc_live_entries( $id ) as $e ) {
				if ( (int) $e['ts'] > $after ) {
					$items[] = enc_live_entry_html( $e, true );
				}
				$max = max( $max, (int) $e['ts'] );
			}
			$res = rest_ensure_response( [ 'items' => $items, 'ts' => $max, 'live' => enc_is_live( $id ), 'upd' => enc_live_upd_text( $id ) ] );
			$res->header( 'Cache-Control', 'no-cache, must-revalidate, max-age=0' );
			return $res;
		},
	] );
} );

/* Мета кутия „На живо“ */
function enc_live_box_html( $post ) {
	wp_nonce_field( 'enc_live', 'enc_live_nonce' );
	$on      = enc_is_live( $post->ID );
	$entries = enc_live_entries( $post->ID );
	?>
	<p>
		<label><input type="checkbox" name="enc_live_on" value="1" <?php checked( $on ); ?>> <strong>Статията е „На живо“</strong></label><br>
		<span class="description">Показва червен знак „На живо“ и опреснява новите обновления при читателите автоматично на всеки 30 секунди. Махнете отметката, когато събитието приключи.</span>
	</p>
	<hr>
	<p><strong>Ново обновление</strong></p>
	<p><input type="text" name="enc_live_new_title" class="widefat" placeholder="Заглавие (по желание)"></p>
	<p><textarea name="enc_live_new_text" rows="4" class="widefat" placeholder="Текст на обновлението (може с HTML, например снимка или линк)"></textarea></p>
	<p class="description">Записва се при „Обнови“ / „Публикувай“ на статията. Времето се слага автоматично.</p>
	<?php if ( $entries ) : ?>
		<hr>
		<p><strong>Досегашни обновления (<?php echo (int) count( $entries ); ?>)</strong></p>
		<?php foreach ( $entries as $e ) : ?>
			<div style="margin:0 0 12px;padding:10px;border:1px solid #dcdcde;border-radius:4px;background:#fafafa">
				<p style="margin:0 0 6px;display:flex;justify-content:space-between">
					<strong><?php echo esc_html( enc_live_time_label( (int) $e['ts'] ) ); ?></strong>
					<label><input type="checkbox" name="enc_live_del[]" value="<?php echo esc_attr( $e['id'] ); ?>"> Изтрий</label>
				</p>
				<p style="margin:0 0 6px"><input type="text" class="widefat" name="enc_live_edit_title[<?php echo esc_attr( $e['id'] ); ?>]" value="<?php echo esc_attr( isset( $e['title'] ) ? $e['title'] : '' ); ?>" placeholder="Заглавие (по желание)"></p>
				<p style="margin:0"><textarea class="widefat" rows="3" name="enc_live_edit_text[<?php echo esc_attr( $e['id'] ); ?>]"><?php echo esc_textarea( $e['text'] ); ?></textarea></p>
			</div>
		<?php endforeach; ?>
	<?php endif;
}

add_action( 'save_post', function ( $post_id ) {
	if ( ! enc_can_save( $post_id, 'enc_live_nonce', 'enc_live' ) ) {
		return;
	}

	$old = get_post_meta( $post_id, 'enc_live', true );
	$old = is_array( $old ) ? $old : [];
	$del = isset( $_POST['enc_live_del'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['enc_live_del'] ) ) : [];
	$et  = isset( $_POST['enc_live_edit_title'] ) ? (array) wp_unslash( $_POST['enc_live_edit_title'] ) : [];
	$ex  = isset( $_POST['enc_live_edit_text'] ) ? (array) wp_unslash( $_POST['enc_live_edit_text'] ) : [];

	$out = [];
	foreach ( $old as $e ) {
		if ( ! is_array( $e ) || ! isset( $e['id'] ) || in_array( $e['id'], $del, true ) ) {
			continue;
		}
		if ( isset( $ex[ $e['id'] ] ) ) {
			$e['text'] = wp_kses_post( $ex[ $e['id'] ] );
		}
		if ( isset( $et[ $e['id'] ] ) ) {
			$e['title'] = sanitize_text_field( $et[ $e['id'] ] );
		}
		$out[] = $e;
	}

	$new_text = isset( $_POST['enc_live_new_text'] ) ? trim( wp_unslash( $_POST['enc_live_new_text'] ) ) : '';
	if ( '' !== $new_text ) {
		$out[] = [
			'id'    => substr( md5( uniqid( '', true ) ), 0, 8 ),
			'ts'    => time(),
			'title' => isset( $_POST['enc_live_new_title'] ) ? sanitize_text_field( wp_unslash( $_POST['enc_live_new_title'] ) ) : '',
			'text'  => wp_kses_post( $new_text ),
		];
	}

	if ( $out ) {
		update_post_meta( $post_id, 'enc_live', $out );
	} else {
		delete_post_meta( $post_id, 'enc_live' );
	}
	update_post_meta( $post_id, 'enc_live_on', ! empty( $_POST['enc_live_on'] ) ? '1' : '0' );
} );
