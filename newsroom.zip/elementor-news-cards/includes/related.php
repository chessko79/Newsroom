<?php
/**
 * „Свързана новина“ – карта със снимка вляво, вмъкната в текста на статия.
 * Три начина: кратък код [enc_related id="123"], блок за Gutenberg и бутон в класическия редактор.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- HTML на картата ---------- */
function enc_related_html( $id, $args = [] ) {
	$args = wp_parse_args( $args, [ 'label' => 'Прочетете още', 'image' => true, 'meta' => true ] );
	$id   = (int) $id;
	$post = $id ? get_post( $id ) : null;
	$edit = is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST );

	if ( ! $post || 'publish' !== $post->post_status ) {
		return $edit ? '<div class="enc-rel-missing">Избраната новина не е намерена или не е публикувана.</div>' : '';
	}
	if ( ! $edit && (int) get_the_ID() === $id ) {
		return ''; // не сочи към самата себе си
	}

	wp_enqueue_style( 'enc-related' );

	$link    = get_permalink( $post );
	$title   = get_the_title( $post );
	$has_img = $args['image'] && has_post_thumbnail( $post );
	$fmt     = enc_format_icons( $id, [ 'show_fmt_icon' => 'yes', 'fmt_icons' => [ 'gallery', 'video', 'audio' ], 'fmt_icon_pos' => 'br' ], $has_img );

	$meta = [];
	if ( $args['meta'] ) {
		$tax = 'post' === $post->post_type ? 'category' : '';
		if ( $tax ) {
			$terms = get_the_terms( $id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				$meta[] = '<span class="enc-rel__cat">' . esc_html( reset( $terms )->name ) . '</span>';
			}
		}
		$meta[] = '<time datetime="' . esc_attr( get_the_date( 'c', $post ) ) . '">' . esc_html( get_the_date( 'j M. Y', $post ) ) . '</time>';
	}

	$out  = '<aside class="enc-rel' . ( $has_img ? '' : ' enc-rel--noimg' ) . '">';
	$out .= '<a class="enc-rel__link" href="' . esc_url( $link ) . '">';
	if ( $has_img ) {
		$out .= '<span class="enc-rel__media">' . get_the_post_thumbnail( $post, 'medium', [ 'loading' => 'lazy', 'alt' => '' ] ) . $fmt['overlay'] . '</span>';
	}
	$out .= '<span class="enc-rel__body">';
	if ( '' !== trim( (string) $args['label'] ) ) {
		$out .= '<span class="enc-rel__kicker">' . esc_html( $args['label'] ) . '</span>';
	}
	$out .= '<strong class="enc-rel__title">' . esc_html( $title ) . '</strong>';
	if ( $meta ) {
		$out .= '<span class="enc-rel__meta">' . implode( '<span class="enc-rel__dot"> · </span>', $meta ) . '</span>';
	}
	$out .= '</span></a></aside>';

	return $out;
}

/* ---------- Кратък код: [enc_related id="123" label="Прочетете още" image="1" meta="1"] ---------- */
add_shortcode( 'enc_related', function ( $atts ) {
	$a  = shortcode_atts( [ 'id' => 0, 'url' => '', 'label' => 'Прочетете още', 'image' => '1', 'meta' => '1' ], $atts, 'enc_related' );
	$id = (int) $a['id'];
	if ( ! $id && $a['url'] ) {
		$id = (int) url_to_postid( esc_url_raw( $a['url'] ) );
	}
	return enc_related_html( $id, [
		'label' => $a['label'],
		'image' => '0' !== (string) $a['image'],
		'meta'  => '0' !== (string) $a['meta'],
	] );
} );

/* ---------- Ресурси и блок за Gutenberg ---------- */
add_action( 'init', function () {
	wp_register_style( 'enc-related', ENC_URL . 'assets/related.css', [], ENC_VERSION );

	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}
	wp_register_script(
		'enc-related-block',
		ENC_URL . 'assets/related-block.js',
		[ 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-api-fetch', 'wp-server-side-render', 'wp-html-entities' ],
		ENC_VERSION,
		true
	);
	register_block_type( 'newsroom/related', [
		'api_version'     => 2,
		'editor_script'   => 'enc-related-block',
		'style'           => 'enc-related',
		'render_callback' => function ( $atts ) {
			return enc_related_html( isset( $atts['postId'] ) ? $atts['postId'] : 0, [
				'label' => isset( $atts['label'] ) ? $atts['label'] : 'Прочетете още',
				'image' => ! isset( $atts['showImage'] ) || $atts['showImage'],
				'meta'  => ! isset( $atts['showMeta'] ) || $atts['showMeta'],
			] );
		},
		'attributes'      => [
			'postId'    => [ 'type' => 'number', 'default' => 0 ],
			'label'     => [ 'type' => 'string', 'default' => 'Прочетете още' ],
			'showImage' => [ 'type' => 'boolean', 'default' => true ],
			'showMeta'  => [ 'type' => 'boolean', 'default' => true ],
		],
	] );
} );

/* ---------- Помощен REST маршрут: линк или номер -> новина (само за редактори) ---------- */
add_action( 'rest_api_init', function () {
	register_rest_route( 'enc/v1', '/resolve', [
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'edit_posts' );
		},
		'args'                => [
			'url' => [ 'required' => false, 'sanitize_callback' => 'esc_url_raw' ],
			'id'  => [ 'required' => false, 'sanitize_callback' => 'absint' ],
		],
		'callback'            => function ( WP_REST_Request $req ) {
			$id = (int) $req->get_param( 'id' );
			if ( ! $id && $req->get_param( 'url' ) ) {
				$id = (int) url_to_postid( $req->get_param( 'url' ) );
			}
			if ( ! $id || 'publish' !== get_post_status( $id ) ) {
				return [ 'id' => 0 ];
			}
			return [ 'id' => $id, 'title' => get_the_title( $id ) ];
		},
	] );
} );

/* ---------- Бутон „Свързана новина“ в класическия редактор ---------- */
add_action( 'media_buttons', function () {
	echo '<button type="button" class="button enc-rel-btn"><span class="dashicons dashicons-admin-links" aria-hidden="true"></span> Свързана новина</button>';
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ], true ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( $screen && method_exists( $screen, 'is_block_editor' ) && $screen->is_block_editor() ) {
		return; // в Gutenberg се ползва блокът
	}
	wp_enqueue_style( 'enc-related-admin', ENC_URL . 'assets/related-admin.css', [], ENC_VERSION );
	wp_enqueue_script( 'enc-related-classic', ENC_URL . 'assets/related-classic.js', [ 'wp-api-fetch' ], ENC_VERSION, true );
} );
