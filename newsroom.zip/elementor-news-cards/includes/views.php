<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Типове съдържание, които броят прегледи */
function enc_view_post_types() {
	$types = get_post_types( [ 'public' => true ] );
	unset( $types['page'], $types['attachment'] );
	return array_values( $types );
}

/* ---------- Почасова таблица за периодите „последен ден / 7 / 30 дни“ ---------- */
function enc_views_table() {
	global $wpdb;
	return $wpdb->prefix . 'enc_views';
}

add_action( 'init', 'enc_maybe_create_table' );
function enc_maybe_create_table() {
	if ( '1' === get_option( 'enc_db_version' ) ) {
		return;
	}
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$table = enc_views_table();
	dbDelta( "CREATE TABLE {$table} (
  post_id bigint(20) unsigned NOT NULL,
  bucket datetime NOT NULL,
  views int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (post_id,bucket),
  KEY bucket (bucket)
) " . $wpdb->get_charset_collate() . ';' );
	update_option( 'enc_db_version', '1' );
}

/* Записва $n прегледа в текущия час (UTC) */
function enc_record_view( $post_id, $n = 1 ) {
	global $wpdb;
	$table = enc_views_table();
	$wpdb->suppress_errors( true );
	$wpdb->query( $wpdb->prepare(
		"INSERT INTO {$table} (post_id, bucket, views) VALUES (%d, %s, %d) ON DUPLICATE KEY UPDATE views = views + VALUES(views)",
		(int) $post_id,
		gmdate( 'Y-m-d H:00:00' ),
		max( 1, (int) $n )
	) );
	// От време на време трием данни, по-стари от 35 дни
	if ( 1 === wp_rand( 1, 300 ) ) {
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE bucket < %s", gmdate( 'Y-m-d H:00:00', time() - 35 * DAY_IN_SECONDS ) ) );
	}
	$wpdb->suppress_errors( false );
}

/* ID-та на най-четените за последните $hours часа (кеш 5 минути) */
function enc_period_top_ids( $hours, $limit = 300 ) {
	$hours = max( 1, (int) $hours );
	$key   = 'enc_top_' . $hours;
	$ids   = get_transient( $key );
	if ( false !== $ids ) {
		return $ids;
	}
	global $wpdb;
	$table = enc_views_table();
	$wpdb->suppress_errors( true );
	$ids = $wpdb->get_col( $wpdb->prepare(
		"SELECT post_id FROM {$table} WHERE bucket >= %s GROUP BY post_id ORDER BY SUM(views) DESC, MAX(bucket) DESC LIMIT %d",
		gmdate( 'Y-m-d H:00:00', time() - $hours * HOUR_IN_SECONDS ),
		(int) $limit
	) );
	$wpdb->suppress_errors( false );
	$ids = array_map( 'intval', (array) $ids );
	set_transient( $key, $ids, 300 );
	return $ids;
}

function enc_flush_top_cache() {
	global $wpdb;
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_enc\\_top\\_%' OR option_name LIKE '\\_transient\\_timeout\\_enc\\_top\\_%'" );
}

/* Атомарно увеличаване на общите прегледи (и записване в часовата кофа); връща новата стойност */
function enc_inc_views( $post_id, $n = 1 ) {
	global $wpdb;
	$post_id = (int) $post_id;
	$n       = max( 1, (int) $n );
	$updated = $wpdb->query( $wpdb->prepare(
		"UPDATE {$wpdb->postmeta} SET meta_value = meta_value + %d WHERE post_id = %d AND meta_key = 'enc_views'",
		$n,
		$post_id
	) );
	if ( ! $updated ) {
		add_post_meta( $post_id, 'enc_views', $n, true );
	}
	wp_cache_delete( $post_id, 'post_meta' );
	enc_record_view( $post_id, $n );
	return (int) get_post_meta( $post_id, 'enc_views', true );
}

/* ---------- Брояч: JS праща заявка към REST (работи и зад кеширане) ---------- */
add_action( 'rest_api_init', function () {
	register_rest_route( 'enc/v1', '/view', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'args'                => [ 'id' => [ 'required' => true, 'sanitize_callback' => 'absint' ] ],
		'callback'            => 'enc_count_view',
	] );
} );

function enc_count_view( WP_REST_Request $req ) {
	$id = (int) $req->get_param( 'id' );
	if ( '1' !== get_option( 'enc_count_views', '1' ) || ! $id || 'publish' !== get_post_status( $id )
		|| ! in_array( get_post_type( $id ), enc_view_post_types(), true ) ) {
		return rest_ensure_response( [ 'counted' => false ] );
	}

	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
	if ( '' === $ua || preg_match( '/bot|crawl|spider|slurp|facebookexternalhit|preview|headless|lighthouse/i', $ua ) ) {
		return rest_ensure_response( [ 'counted' => false ] );
	}

	return rest_ensure_response( [ 'counted' => true, 'views' => enc_inc_views( $id ) ] );
}

add_action( 'wp_enqueue_scripts', function () {
	if ( '1' !== get_option( 'enc_count_views', '1' ) || ! is_singular( enc_view_post_types() ) ) {
		return;
	}
	wp_register_script( 'enc-views', ENC_URL . 'assets/views.js', [], ENC_VERSION, true );
	wp_add_inline_script(
		'enc-views',
		'window.encViews=' . wp_json_encode( [
			'id'   => get_queried_object_id(),
			'url'  => esc_url_raw( rest_url( 'enc/v1/view' ) ),
			'mode' => 'session' === get_option( 'enc_count_mode', 'every' ) ? 'session' : 'every',
			'skip' => ( '1' === get_option( 'enc_count_skip_editors', '1' ) && is_user_logged_in() && current_user_can( 'edit_posts' ) ),
		] ) . ';',
		'before'
	);
	wp_enqueue_script( 'enc-views' );
}, 20 );

/* ---------- Мета кутия в редактора: добавяне / задаване на прегледи ---------- */
add_action( 'add_meta_boxes', function () {
	foreach ( enc_view_post_types() as $pt ) {
		add_meta_box( 'enc_views_box', 'Прегледи', 'enc_views_box_html', $pt, 'side', 'default' );
	}
} );

function enc_views_box_html( $post ) {
	wp_nonce_field( 'enc_views_box', 'enc_views_nonce' );
	$v = (int) get_post_meta( $post->ID, 'enc_views', true );
	?>
	<p>Общо прегледи: <strong><?php echo esc_html( $v ); ?></strong></p>
	<p><label>Добави прегледи<br><input type="number" name="enc_views_add" value="" min="0" step="1" style="width:100%"></label></p>
	<p><label>Или задай точно общо число<br><input type="number" name="enc_views_set" value="" min="0" step="1" style="width:100%"></label></p>
	<p class="description">Празните полета не променят нищо. Добавените прегледи се отчитат и в „Най-четени“ за днешния ден.</p>
	<?php
}

add_action( 'save_post', function ( $post_id ) {
	if ( ! isset( $_POST['enc_views_nonce'] ) || ! wp_verify_nonce( wp_unslash( $_POST['enc_views_nonce'] ), 'enc_views_box' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$set = isset( $_POST['enc_views_set'] ) ? trim( wp_unslash( $_POST['enc_views_set'] ) ) : '';
	$add = isset( $_POST['enc_views_add'] ) ? trim( wp_unslash( $_POST['enc_views_add'] ) ) : '';
	$changed = false;

	if ( '' !== $set && is_numeric( $set ) ) {
		$old = (int) get_post_meta( $post_id, 'enc_views', true );
		$new = max( 0, (int) $set );
		update_post_meta( $post_id, 'enc_views', $new );
		if ( $new > $old ) {
			enc_record_view( $post_id, $new - $old );
		}
		$changed = true;
	}
	if ( '' !== $add && is_numeric( $add ) && (int) $add > 0 ) {
		enc_inc_views( $post_id, (int) $add );
		$changed = true;
	}
	if ( $changed ) {
		enc_flush_top_cache();
	}
} );

/* ---------- Колона „Прегледи“ в списъка със статии (може да се сортира) ---------- */
add_action( 'admin_init', function () {
	foreach ( enc_view_post_types() as $pt ) {
		add_filter( "manage_{$pt}_posts_columns", function ( $cols ) {
			$cols['enc_views'] = 'Прегледи';
			return $cols;
		} );
		add_action( "manage_{$pt}_posts_custom_column", function ( $col, $id ) {
			if ( 'enc_views' === $col ) {
				echo (int) get_post_meta( $id, 'enc_views', true );
			}
		}, 10, 2 );
		add_filter( "manage_edit-{$pt}_sortable_columns", function ( $cols ) {
			$cols['enc_views'] = 'enc_views';
			return $cols;
		} );
	}
} );

add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() || ! $q->is_main_query() || 'enc_views' !== $q->get( 'orderby' ) ) {
		return;
	}
	$order = 'ASC' === strtoupper( (string) $q->get( 'order' ) ) ? 'ASC' : 'DESC';
	$q->set( 'meta_query', [
		'relation' => 'OR',
		'enc_v'    => [ 'key' => 'enc_views', 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
		[ 'key' => 'enc_views', 'compare' => 'NOT EXISTS' ],
	] );
	$q->set( 'orderby', [ 'enc_v' => $order, 'date' => 'DESC' ] );
} );

/* ---------- Масово задаване на начални (фалшиви) прегледи – само общия брой ---------- */
add_action( 'admin_post_enc_seed_views', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Нямате права за това действие.' );
	}
	check_admin_referer( 'enc_seed_views' );

	$min   = isset( $_POST['min'] ) ? max( 0, (int) $_POST['min'] ) : 0;
	$max   = isset( $_POST['max'] ) ? max( $min, (int) $_POST['max'] ) : $min;
	$scope = ( isset( $_POST['scope'] ) && 'all' === $_POST['scope'] ) ? 'all' : 'empty';

	$ids = get_posts( [
		'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => -1,
		'fields' => 'ids', 'no_found_rows' => true,
	] );
	$n = 0;
	foreach ( $ids as $id ) {
		if ( 'empty' === $scope && (int) get_post_meta( $id, 'enc_views', true ) > 0 ) {
			continue;
		}
		update_post_meta( $id, 'enc_views', wp_rand( $min, $max ) );
		$n++;
	}
	wp_safe_redirect( add_query_arg( [ 'page' => 'enc-settings', 'enc_seeded' => $n ], admin_url( 'options-general.php' ) ) );
	exit;
} );
