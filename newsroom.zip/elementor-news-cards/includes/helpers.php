<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- Регистрация на ресурси ---------- */
function enc_register_assets() {
	wp_register_style( 'enc-news-cards', ENC_URL . 'assets/news-cards.css', [], ENC_VERSION );
	wp_register_style( 'enc-single', ENC_URL . 'assets/single-post.css', [], ENC_VERSION );
	wp_register_style( 'enc-news-hero', ENC_URL . 'assets/news-hero.css', [], ENC_VERSION );
	wp_register_style( 'enc-news-list', ENC_URL . 'assets/news-list.css', [], ENC_VERSION );
	wp_register_style( 'enc-news-lead', ENC_URL . 'assets/news-lead.css', [], ENC_VERSION );
	wp_register_style( 'enc-news-top', ENC_URL . 'assets/news-top.css', [], ENC_VERSION );
	wp_register_style( 'enc-latest', ENC_URL . 'assets/latest.css', [], ENC_VERSION );
	wp_register_style( 'enc-small-list', ENC_URL . 'assets/small-list.css', [], ENC_VERSION );
	wp_register_style( 'enc-archive', ENC_URL . 'assets/archive.css', [], ENC_VERSION );
	wp_register_script( 'enc-latest', ENC_URL . 'assets/latest.js', [], ENC_VERSION, true );
	wp_register_script( 'enc-single', ENC_URL . 'assets/single-post.js', [], ENC_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'enc_register_assets', 5 );
add_action( 'elementor/frontend/after_register_styles', 'enc_register_assets' );
add_action( 'elementor/frontend/after_register_scripts', 'enc_register_assets' );

/* ---------- Време за четене (200 думи/мин.) ---------- */
function enc_reading_time( $post_id = null ) {
	$post = get_post( $post_id );
	if ( ! $post ) {
		return 1;
	}
	$text  = wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
	$words = preg_match_all( '/[\p{L}\p{N}]+/u', $text );
	return max( 1, (int) ceil( $words / 200 ) );
}

/* ---------- Формати на публикациите (Vafpress Post Formats UI) ----------
 * Чете мета ключовете на плъгина: _format_gallery_images, _format_video_embed,
 * _format_audio_embed, _format_link_url, _format_quote_source_name/_url.
 * Без плъгина няма данни и се показва обикновената основна снимка. */
function enc_post_format( $id ) {
	$f = get_post_format( $id );
	return $f ? $f : 'standard';
}

function enc_kses_embed( $html ) {
	$allowed           = wp_kses_allowed_html( 'post' );
	$allowed['iframe'] = [
		'src' => true, 'width' => true, 'height' => true, 'frameborder' => true, 'allow' => true, 'allowfullscreen' => true,
		'title' => true, 'loading' => true, 'referrerpolicy' => true, 'scrolling' => true, 'class' => true, 'name' => true,
	];
	$allowed['video']  = [ 'src' => true, 'controls' => true, 'poster' => true, 'preload' => true, 'width' => true, 'height' => true, 'class' => true, 'playsinline' => true, 'loop' => true, 'muted' => true ];
	$allowed['audio']  = [ 'src' => true, 'controls' => true, 'preload' => true, 'class' => true, 'loop' => true ];
	$allowed['source'] = [ 'src' => true, 'type' => true ];
	return wp_kses( $html, $allowed );
}

/* Линк (oEmbed, кеширан от WordPress), файл (native player), shortcode или готов embed код */
function enc_render_embed( $raw, $type = 'video' ) {
	$raw = trim( (string) $raw );
	if ( '' === $raw ) {
		return '';
	}

	if ( preg_match( '#^https?://\S+$#i', $raw ) ) {
		$url = esc_url_raw( $raw );
		if ( 'audio' === $type && preg_match( '#\.(mp3|m4a|ogg|oga|wav|aac)(\?.*)?$#i', $url ) ) {
			return '<audio class="enc-audio" controls preload="none" src="' . esc_url( $url ) . '"></audio>';
		}
		if ( 'video' === $type && preg_match( '#\.(mp4|m4v|webm|ogv)(\?.*)?$#i', $url ) ) {
			return '<video class="enc-video-file" controls preload="metadata" playsinline src="' . esc_url( $url ) . '"></video>';
		}
		global $wp_embed;
		$html = $wp_embed ? $wp_embed->shortcode( [], $url ) : '';
		if ( ! $html ) {
			return '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $url ) . '</a>';
		}
	} elseif ( preg_match( '/\[[a-z]/i', $raw ) ) {
		$html = do_shortcode( enc_kses_embed( $raw ) );
	} else {
		$html = enc_kses_embed( $raw );
	}

	if ( false !== strpos( $html, '<iframe' ) && false === strpos( $html, 'loading=' ) ) {
		$html = str_replace( '<iframe', '<iframe loading="lazy"', $html );
	}
	return $html;
}

function enc_render_featured_figure( $id, $o ) {
	if ( ! has_post_thumbnail( $id ) ) {
		return;
	}
	$caption = wp_get_attachment_caption( get_post_thumbnail_id( $id ) );
	?>
	<figure class="enc-post-figure">
		<?php echo get_the_post_thumbnail( $id, $o['image_size'], [ 'class' => 'enc-post-img', 'loading' => 'eager', 'fetchpriority' => 'high' ] ); ?>
		<?php if ( $o['show_caption'] && $caption ) : ?>
			<figcaption><?php echo wp_kses_post( $caption ); ?></figcaption>
		<?php endif; ?>
	</figure>
	<?php
}

function enc_render_gallery( $id, $o ) {
	$ids = get_post_meta( $id, '_format_gallery_images', true );
	if ( ! is_array( $ids ) ) {
		$ids = explode( ',', (string) $ids );
	}
	$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
	if ( ! $ids ) {
		return false;
	}

	$slides = '';
	foreach ( $ids as $i => $aid ) {
		$img = wp_get_attachment_image( $aid, $o['image_size'] ?: 'large', false, [ 'class' => 'enc-post-img', 'loading' => 0 === $i ? 'eager' : 'lazy' ] );
		if ( ! $img ) {
			continue;
		}
		$cap     = wp_get_attachment_caption( $aid );
		$slides .= '<div class="enc-gal__slide">' . $img . ( $cap ? '<div class="enc-gal__cap">' . wp_kses_post( $cap ) . '</div>' : '' ) . '</div>';
		$count   = isset( $count ) ? $count + 1 : 1;
	}
	if ( ! $slides ) {
		return false;
	}

	echo '<figure class="enc-post-figure enc-gal"><div class="enc-gal__track" tabindex="0">' . $slides . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	if ( $count > 1 ) {
		echo '<button type="button" class="enc-gal__btn enc-gal__prev" aria-label="Предишна снимка"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 5-7 7 7 7"/></svg></button>';
		echo '<button type="button" class="enc-gal__btn enc-gal__next" aria-label="Следваща снимка"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button>';
		echo '<span class="enc-gal__count">1 / ' . (int) $count . '</span>';
	}
	echo '</figure>';
	return true;
}

function enc_render_link_card( $id ) {
	$url = esc_url( trim( (string) get_post_meta( $id, '_format_link_url', true ) ) );
	if ( ! $url ) {
		return;
	}
	$host = preg_replace( '/^www\./', '', (string) wp_parse_url( $url, PHP_URL_HOST ) );
	?>
	<a class="enc-linkcard" href="<?php echo $url; ?>" target="_blank" rel="noopener nofollow">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>
		<span class="enc-linkcard__text"><small>Връзка към източника</small><strong><?php echo esc_html( $host ? $host : $url ); ?></strong></span>
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17 17 7M8 7h9v9"/></svg>
	</a>
	<?php
}

function enc_render_quote_source( $id ) {
	$name = trim( (string) get_post_meta( $id, '_format_quote_source_name', true ) );
	$url  = trim( (string) get_post_meta( $id, '_format_quote_source_url', true ) );
	if ( '' === $name && '' === $url ) {
		return;
	}
	if ( '' === $name ) {
		$name = preg_replace( '/^www\./', '', (string) wp_parse_url( $url, PHP_URL_HOST ) );
	}
	echo '<p class="enc-quote-source">— ';
	if ( $url ) {
		echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener nofollow">' . esc_html( $name ) . '</a>';
	} else {
		echo esc_html( $name );
	}
	echo '</p>';
}

/* Основен медиен блок според формата на публикацията */
function enc_render_post_media( $id, $o ) {
	$fmt = ( '1' === get_option( 'enc_post_formats', '1' ) ) ? enc_post_format( $id ) : 'standard';

	if ( 'gallery' === $fmt && enc_render_gallery( $id, $o ) ) {
		return;
	}
	if ( 'video' === $fmt ) {
		$html = enc_render_embed( get_post_meta( $id, '_format_video_embed', true ), 'video' );
		if ( $html ) {
			echo '<div class="enc-media enc-media--video">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			return;
		}
	}
	if ( 'audio' === $fmt ) {
		enc_render_featured_figure( $id, $o );
		$html = enc_render_embed( get_post_meta( $id, '_format_audio_embed', true ), 'audio' );
		if ( $html ) {
			echo '<div class="enc-media enc-media--audio">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		return;
	}
	if ( 'link' === $fmt ) {
		enc_render_featured_figure( $id, $o );
		enc_render_link_card( $id );
		return;
	}
	enc_render_featured_figure( $id, $o );
}

/* ---------- „преди X минути“ (същата логика е и в assets/latest.js) ---------- */
function enc_time_ago( $ts, $max_days = 7 ) {
	$d = max( 0, time() - (int) $ts );
	if ( $d < 60 ) {
		return 'току-що';
	}
	$m = (int) floor( $d / 60 );
	if ( $m < 60 ) {
		return 'преди ' . $m . ' ' . ( 1 === $m ? 'минута' : 'минути' );
	}
	$h = (int) floor( $m / 60 );
	if ( $h < 24 ) {
		return 'преди ' . $h . ' ' . ( 1 === $h ? 'час' : 'часа' );
	}
	$days = (int) floor( $h / 24 );
	if ( $days < max( 1, (int) $max_days ) ) {
		return 'преди ' . $days . ' ' . ( 1 === $days ? 'ден' : 'дни' );
	}
	return ''; // по-старо от прага – извикващият показва датата
}

/* ---------- Икони според формата (за уиджетите) ---------- */
function enc_format_labels() {
	return [
		'gallery' => 'Галерия', 'video' => 'Видео', 'audio' => 'Аудио', 'link' => 'Връзка',
		'quote' => 'Цитат', 'image' => 'Изображение', 'status' => 'Статус', 'aside' => 'Бележка',
	];
}

function enc_format_svg( $fmt ) {
	$paths = [
		'gallery' => '<rect x="3" y="6" width="14" height="14" rx="2"/><path d="M7 6V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-2"/><path d="m3 17 4-4 4 4 3-3 3 3"/>',
		'video'   => '<path d="M8 5v14l11-7z" fill="currentColor"/>',
		'audio'   => '<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="7" rx="1.5"/><rect x="17" y="14" width="4" height="7" rx="1.5"/>',
		'link'    => '<path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
		'quote'   => '<path d="M5 17h4l2-4V7H5v6h3zm9 0h4l2-4V7h-6v6h3z" fill="currentColor" stroke="none"/>',
		'image'   => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="m21 16-5-5-8 8"/>',
		'status'  => '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/>',
		'aside'   => '<path d="M5 4h14v16H5z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
	];
	if ( ! isset( $paths[ $fmt ] ) ) {
		return '';
	}
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $paths[ $fmt ] . '</svg>';
}

/* Връща [ 'overlay' => върху снимката, 'inline' => в реда с датата ] според настройките на уиджета */
function enc_format_icons( $id, $s, $has_image ) {
	$out = [ 'overlay' => '', 'inline' => '' ];

	// Новина „На живо“: пулсираща червена точка (върху снимката, а без снимка – малък етикет в мета реда)
	if ( function_exists( 'enc_is_live' ) && enc_is_live( $id ) ) {
		if ( $has_image ) {
			$out['overlay'] .= '<span class="enc-livedot" role="img" aria-label="На живо" title="На живо"></span>';
		} else {
			$out['inline'] .= '<span class="enc-livedot-label"><i class="enc-livedot" aria-hidden="true"></i>На живо</span>';
		}
	}

	if ( empty( $s['show_fmt_icon'] ) || 'yes' !== $s['show_fmt_icon'] ) {
		return $out;
	}
	$fmt     = enc_post_format( $id );
	$allowed = isset( $s['fmt_icons'] ) ? (array) $s['fmt_icons'] : [];
	$labels  = enc_format_labels();
	if ( ! in_array( $fmt, $allowed, true ) || ! isset( $labels[ $fmt ] ) ) {
		return $out;
	}
	$svg = enc_format_svg( $fmt );
	if ( ! $svg ) {
		return $out;
	}
	$attrs = ' role="img" aria-label="' . esc_attr( $labels[ $fmt ] ) . '" title="' . esc_attr( $labels[ $fmt ] ) . '"';
	$pos   = isset( $s['fmt_icon_pos'] ) ? $s['fmt_icon_pos'] : 'tr';

	if ( 'meta' !== $pos && $has_image ) {
		if ( ! in_array( $pos, [ 'tl', 'tr', 'bl', 'br', 'center' ], true ) ) {
			$pos = 'tr';
		}
		$out['overlay'] .= '<span class="enc-fmt enc-fmt--ov enc-fmt--' . $pos . ' enc-fmt--' . $fmt . '"' . $attrs . '>' . $svg . '</span>';
	} else {
		$out['inline'] .= '<span class="enc-fmt enc-fmt--inline enc-fmt--' . $fmt . '"' . $attrs . '>' . $svg . '</span>';
	}
	return $out;
}

/* ---------- Меню „Сподели“ (копиране на линка, Facebook, X, имейл) ---------- */
function enc_share_networks() {
	$allowed = [ 'copy', 'facebook', 'x', 'email' ];
	$saved   = get_option( 'enc_share', $allowed );
	if ( ! is_array( $saved ) ) {
		$saved = $allowed;
	}
	return array_values( array_intersect( $allowed, $saved ) );
}

function enc_render_share_popover( $id ) {
	$nets = enc_share_networks();
	if ( ! $nets ) {
		return;
	}
	$url   = get_permalink( $id );
	$title = wp_strip_all_tags( get_the_title( $id ) );
	$eu    = rawurlencode( $url );
	$et    = rawurlencode( $title );
	$svg   = '<svg viewBox="0 0 24 24" aria-hidden="true">';

	$items = '';
	if ( in_array( 'copy', $nets, true ) ) {
		$items .= '<button type="button" class="enc-sharepop__item enc-sharepop__item--copy" data-act="copy" data-url="' . esc_url( $url ) . '" data-copied="Линкът е копиран" aria-label="Копирай линка" title="Копирай линка">'
			. '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg></button>';
	}
	if ( in_array( 'facebook', $nets, true ) ) {
		$items .= '<a class="enc-sharepop__item" href="' . esc_url( 'https://www.facebook.com/sharer/sharer.php?u=' . $eu ) . '" target="_blank" rel="noopener noreferrer" aria-label="Сподели във Facebook" title="Facebook">'
			. $svg . '<path fill="currentColor" d="M13.5 21v-8h2.7l.5-3.2h-3.2V7.9c0-.9.4-1.6 1.7-1.6h1.6V3.4c-.3 0-1.3-.1-2.4-.1-2.4 0-4 1.5-4 4.1v2.4H7.7V13h2.7v8h3.1z"/></svg></a>';
	}
	if ( in_array( 'x', $nets, true ) ) {
		$items .= '<a class="enc-sharepop__item" href="' . esc_url( 'https://twitter.com/intent/tweet?url=' . $eu . '&text=' . $et ) . '" target="_blank" rel="noopener noreferrer" aria-label="Сподели в X" title="X">'
			. $svg . '<path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a>';
	}
	if ( in_array( 'email', $nets, true ) ) {
		$items .= '<a class="enc-sharepop__item" href="' . esc_url( 'mailto:?subject=' . $et . '&body=' . $eu ) . '" aria-label="Изпрати по имейл" title="Имейл">'
			. $svg . '<path fill="currentColor" d="M3 6.5A1.5 1.5 0 0 1 4.5 5h15A1.5 1.5 0 0 1 21 6.5v.4l-9 5.6-9-5.6v-.4zM3 9.3v8.2A1.5 1.5 0 0 0 4.5 19h15a1.5 1.5 0 0 0 1.5-1.5V9.3l-9 5.6-9-5.6z"/></svg></a>';
	}

	echo '<div class="enc-share-wrap">';
	echo '<button type="button" class="enc-iconbtn enc-sharebtn" aria-label="Сподели" aria-haspopup="true" aria-expanded="false">'
		. '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 18v-1a8 8 0 0 1 8-8h8"/><path d="m16 5 4 4-4 4"/></svg></button>';
	echo '<div class="enc-sharepop" role="group" aria-label="Сподели" hidden>' . $items . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	echo '</div>';
}

/* ---------- Заглавна част на статията: заглавие, мета, бутони, снимка ---------- */
function enc_render_post_header( $o = [] ) {
	$o = wp_parse_args( $o, [
		'show_author'   => true,
		'show_category' => true,
		'show_updated'  => true,
		'show_note'     => true,
		'show_avatar'   => false,
		'show_date'     => true,
		'date_format'   => 'l, j F Y',
		'show_time'     => true,
		'time_format'   => 'H:i',
		'show_reading'  => true,
		'read_suffix'   => 'мин. четене',
		'show_views'    => '1' === get_option( 'enc_single_show_views', '1' ),
		'views_key'     => 'enc_views',
		'views_suffix'  => '',
		'show_share'    => true,
		'show_comments' => true,
		'show_image'    => true,
		'image_size'    => 'large',
		'show_caption'  => true,
	] );

	$id = get_the_ID();
	if ( ! $id ) {
		return;
	}

	$author_id   = (int) get_post_field( 'post_author', $id );
	$author_name = get_the_author_meta( 'display_name', $author_id );
	$comments    = (int) get_comments_number( $id );
	$views_key   = sanitize_key( $o['views_key'] ) ?: 'enc_views';
	$views      = (int) get_post_meta( $id, $views_key, true );

	$upd_ts   = (int) get_post_meta( $id, 'enc_updated', true );
	$upd_str  = '';
	if ( $o['show_updated'] && $upd_ts ) {
		$upd_str = wp_date( $o['date_format'] ?: 'l, j F Y', $upd_ts );
		if ( $o['show_time'] ) {
			$upd_str .= ' в ' . wp_date( $o['time_format'] ?: 'H:i', $upd_ts );
		}
	}
	$note_txt = '';
	if ( $o['show_note'] ) {
		$note_txt   = trim( (string) get_post_meta( $id, 'enc_note', true ) );
		$note_types = enc_note_labels();
		$note_key   = (string) get_post_meta( $id, 'enc_note_type', true );
		$note_label = isset( $note_types[ $note_key ] ) ? $note_types[ $note_key ] : $note_types['correction'];
	}

	$date_str = '';
	if ( $o['show_date'] ) {
		$date_str = get_the_date( $o['date_format'] ?: 'l, j F Y', $id );
		if ( $o['show_time'] ) {
			$date_str .= ' в ' . get_the_time( $o['time_format'] ?: 'H:i', $id );
		}
	}
	?>
	<header class="enc-post-head">
		<?php
		$enc_kick = '';
		if ( $o['show_category'] && 'post' === get_post_type( $id ) ) {
			$enc_cats = array_filter( (array) get_the_category( $id ), function ( $c ) {
				return (int) $c->term_id !== (int) get_option( 'default_category' );
			} );
			if ( $enc_cats ) {
				$enc_c     = reset( $enc_cats );
				$enc_kick .= sprintf(
					'<a class="enc-post-cat" style="--enc-cat:%s" href="%s">%s</a>',
					esc_attr( enc_cat_color( $enc_c->term_id ) ),
					esc_url( get_category_link( $enc_c ) ),
					esc_html( $enc_c->name )
				);
			}
		}
		if ( enc_is_live( $id ) ) {
			$enc_kick .= '<span class="enc-live-badge">На живо</span>';
		}
		if ( $enc_kick ) {
			echo '<div class="enc-post-kicker">' . $enc_kick . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		$enc_title = get_the_title( $id );
		if ( '' !== $enc_title ) :
			$enc_fmt = ( '1' === get_option( 'enc_post_formats', '1' ) ) ? enc_post_format( $id ) : 'standard';
			?>
			<h1 class="enc-post-title<?php echo 'status' === $enc_fmt ? ' enc-sr-only' : ''; ?>"><?php echo esc_html( $enc_title ); ?></h1>
		<?php endif; ?>

		<div class="enc-post-meta">
			<div class="enc-post-meta__info">
				<?php if ( $o['show_author'] && $author_name ) : ?>
					<span class="enc-post-author">
						<?php if ( $o['show_avatar'] ) {
							echo get_avatar( $author_id, 28 );
						} ?>
						<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>"><?php echo esc_html( $author_name ); ?></a>
					</span>
				<?php endif; ?>

				<?php if ( $date_str ) : ?>
					<time class="enc-post-date" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $date_str ); ?></time>
				<?php endif; ?>

				<?php if ( $upd_str ) : ?>
					<time class="enc-post-updated" datetime="<?php echo esc_attr( gmdate( 'c', $upd_ts ) ); ?>">Обновена: <?php echo esc_html( $upd_str ); ?></time>
				<?php endif; ?>

				<?php if ( $o['show_reading'] || $o['show_views'] ) : ?>
					<div class="enc-post-stats">
						<?php if ( $o['show_reading'] ) : ?>
							<span class="enc-post-read"><?php echo esc_html( enc_reading_time( $id ) . ' ' . $o['read_suffix'] ); ?></span>
						<?php endif; ?>
						<?php if ( $o['show_views'] ) : ?>
							<span class="enc-post-views">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>
								<span class="enc-views-num" data-enc-views="<?php echo (int) $id; ?>"><?php echo esc_html( $views ); ?></span><?php if ( $o['views_suffix'] ) { echo ' ' . esc_html( $o['views_suffix'] ); } ?>
							</span>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( $o['show_share'] || ( $o['show_comments'] && ( comments_open( $id ) || $comments ) ) ) : ?>
				<div class="enc-post-actions">
					<?php if ( $o['show_share'] ) : ?>
						<?php enc_render_share_popover( $id ); ?>
					<?php endif; ?>

					<?php if ( $o['show_comments'] && ( comments_open( $id ) || $comments ) ) : ?>
						<a class="enc-iconbtn enc-commentbtn" href="#comments" aria-label="Коментари">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/></svg>
							<?php if ( $comments > 0 ) : ?><span class="enc-count"><?php echo esc_html( $comments ); ?></span><?php endif; ?>
						</a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $note_txt ) : ?>
			<div class="enc-post-note" role="note"><strong><?php echo esc_html( $note_label ); ?>:</strong> <?php echo esc_html( $note_txt ); ?></div>
		<?php endif; ?>
	</header>

	<?php if ( $o['show_image'] ) {
		enc_render_post_media( $id, $o );
	}
}

/* ---------- Откриване на The7 ---------- */
function enc_is_the7() {
	return defined( 'PRESSCORE_VERSION' ) || function_exists( 'presscore_config' ) || 'dt-the7' === get_template();
}

/* ---------- Откриване на Astra ---------- */
function enc_is_astra() {
	return defined( 'ASTRA_THEME_VERSION' ) || function_exists( 'astra_page_layout' ) || 'astra' === get_template();
}

/* ---------- Статия + коментари (общо за всички режими) ---------- */
function enc_render_article() {
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'enc-article' ); ?>>
		<?php enc_render_post_header(); ?>

		<?php $enc_fmt = ( '1' === get_option( 'enc_post_formats', '1' ) ) ? enc_post_format( get_the_ID() ) : 'standard'; ?>
		<div class="enc-article__content entry-content<?php echo 'quote' === $enc_fmt ? ' enc-fmt-quote' : ''; ?>">
			<?php the_content(); ?>
		</div>
		<?php if ( 'quote' === $enc_fmt ) {
			enc_render_quote_source( get_the_ID() );
		} ?>

		<?php enc_render_live( get_the_ID() ); ?>

		<?php $tags = get_the_tags(); if ( $tags ) : ?>
			<div class="enc-post-tags">
				<?php foreach ( $tags as $tag ) : ?>
					<a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>"><?php echo esc_html( $tag->name ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</article>

	<?php enc_render_related_news( get_the_ID() ); ?>

	<?php if ( comments_open() || get_comments_number() ) : ?>
		<div class="enc-article enc-article--comments">
			<?php comments_template(); ?>
		</div>
	<?php endif;
}

/* ---------- Sidebar ---------- */
function enc_get_sidebar_id() {
	$opt = get_option( 'enc_sidebar', 'auto' );
	if ( 'none' === $opt ) {
		return '';
	}
	if ( 'theme' === $opt ) {
		return 'theme';
	}
	if ( 'auto' !== $opt ) {
		return is_active_sidebar( $opt ) ? $opt : '';
	}

	// Автоматично: sidebar-1, после първия активен регистриран sidebar (без футър/хедър области)
	if ( is_active_sidebar( 'sidebar-1' ) ) {
		return 'sidebar-1';
	}
	global $wp_registered_sidebars;
	foreach ( (array) $wp_registered_sidebars as $id => $sb ) {
		$hay = strtolower( $id . ' ' . $sb['name'] );
		if ( false !== strpos( $hay, 'footer' ) || false !== strpos( $hay, 'header' ) || false !== strpos( $hay, 'canvas' ) ) {
			continue;
		}
		if ( false !== strpos( $hay, 'sidebar' ) && is_active_sidebar( $id ) ) {
			return $id;
		}
	}
	return '';
}

function enc_render_sidebar( $id ) {
	if ( ! $id ) {
		return;
	}
	if ( 'theme' === $id ) {
		echo '<div class="enc-sidebar enc-sidebar--theme">';
		get_sidebar();
		echo '</div>';
		return;
	}
	echo '<aside class="enc-sidebar widget-area" role="complementary">';
	dynamic_sidebar( $id );
	echo '</aside>';
}

/* ---------- Настройки: Настройки → Новини – карти ---------- */
add_action( 'admin_menu', function () {
	add_options_page( ENC_NAME . ' – настройки', ENC_NAME, 'manage_options', 'enc-settings', 'enc_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'enc_settings', 'enc_single_enabled', [
		'type' => 'string', 'default' => '1',
		'sanitize_callback' => function ( $v ) { return $v ? '1' : '0'; },
	] );
	register_setting( 'enc_settings', 'enc_count_views', [
		'type' => 'string', 'default' => '1',
		'sanitize_callback' => function ( $v ) { return $v ? '1' : '0'; },
	] );
	register_setting( 'enc_settings', 'enc_count_mode', [
		'type' => 'string', 'default' => 'every',
		'sanitize_callback' => function ( $v ) { return 'session' === $v ? 'session' : 'every'; },
	] );
	register_setting( 'enc_settings', 'enc_count_skip_editors', [
		'type' => 'string', 'default' => '1',
		'sanitize_callback' => function ( $v ) { return $v ? '1' : '0'; },
	] );
	register_setting( 'enc_settings', 'enc_single_show_views', [
		'type' => 'string', 'default' => '1',
		'sanitize_callback' => function ( $v ) { return $v ? '1' : '0'; },
	] );
	register_setting( 'enc_settings', 'enc_post_formats', [
		'type' => 'string', 'default' => '1',
		'sanitize_callback' => function ( $v ) { return $v ? '1' : '0'; },
	] );
	register_setting( 'enc_settings', 'enc_share', [
		'type' => 'array', 'default' => [ 'copy', 'facebook', 'x', 'email' ],
		'sanitize_callback' => function ( $v ) { return array_values( array_intersect( [ 'copy', 'facebook', 'x', 'email' ], is_array( $v ) ? $v : [] ) ); },
	] );
	register_setting( 'enc_settings', 'enc_sidebar', [
		'type' => 'string', 'default' => 'auto', 'sanitize_callback' => 'sanitize_text_field',
	] );
	register_setting( 'enc_settings', 'enc_sidebar_pos', [
		'type' => 'string', 'default' => 'right',
		'sanitize_callback' => function ( $v ) { return 'left' === $v ? 'left' : 'right'; },
	] );
} );

function enc_settings_page() {
	global $wp_registered_sidebars;
	$cur = get_option( 'enc_sidebar', 'auto' );
	$pos = get_option( 'enc_sidebar_pos', 'right' );
	?>
	<div class="wrap">
		<h1><?php echo esc_html( ENC_NAME ); ?> – настройки</h1>
		<?php
		$enc_tab = 'general';
		if ( isset( $_GET['tab'] ) && in_array( sanitize_key( wp_unslash( $_GET['tab'] ) ), [ 'related', 'archive' ], true ) ) {
			$enc_tab = sanitize_key( wp_unslash( $_GET['tab'] ) );
		}
		enc_settings_tabs( $enc_tab );
		if ( 'related' === $enc_tab ) {
			enc_settings_related_tab();
			echo '</div>';
			return;
		}
		if ( 'archive' === $enc_tab ) {
			enc_settings_archive_tab();
			echo '</div>';
			return;
		}
		?>
		<?php if ( isset( $_GET['enc_seeded'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>Зададени са начални прегледи на <?php echo (int) $_GET['enc_seeded']; ?> статии.</p></div>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'enc_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">Единични статии</th>
					<td>
						<label>
							<input type="checkbox" name="enc_single_enabled" value="1" <?php checked( get_option( 'enc_single_enabled', '1' ), '1' ); ?>>
							Използвай вграденото оформление
						</label>
						<p class="description">Изключете, ако правите шаблон в Elementor Theme Builder (Pro) с уиджета „Статия – заглавна част“.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="enc_sidebar">Sidebar</label></th>
					<td>
						<select name="enc_sidebar" id="enc_sidebar">
							<option value="auto" <?php selected( $cur, 'auto' ); ?>>Автоматично</option>
							<option value="theme" <?php selected( $cur, 'theme' ); ?>>Този на темата (sidebar.php)</option>
							<option value="none" <?php selected( $cur, 'none' ); ?>>Без sidebar</option>
							<?php foreach ( (array) $wp_registered_sidebars as $id => $sb ) : ?>
								<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $cur, $id ); ?>><?php echo esc_html( $sb['name'] . ' (' . $id . ')' ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">Ако „Автоматично“ не показва правилния sidebar, изберете го ръчно от списъка.</p>
						<?php if ( enc_is_astra() ) : ?>
							<p class="description"><strong>Открита е темата Astra:</strong> sidebar-ът и колоните се управляват от нея (Customizer и настройките на самата статия), затова настройките по-горе не се ползват.</p>
						<?php endif; ?>
						<?php if ( enc_is_the7() ) : ?>
							<p class="description"><strong>Открита е темата The7:</strong> sidebar-ът и колоните се управляват от нея (Theme Options → Sidebar), затова настройките по-горе не се ползват.</p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="enc_sidebar_pos">Позиция</label></th>
					<td>
						<select name="enc_sidebar_pos" id="enc_sidebar_pos">
							<option value="right" <?php selected( $pos, 'right' ); ?>>Отдясно</option>
							<option value="left" <?php selected( $pos, 'left' ); ?>>Отляво</option>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">Прегледи</th>
					<td>
						<label>
							<input type="checkbox" name="enc_count_views" value="1" <?php checked( get_option( 'enc_count_views', '1' ), '1' ); ?>>
							Броене на прегледите на статиите (мета ключ <code>enc_views</code>)
						</label>
						<p class="description">Показват се в уиджета „Новини – заглавие върху снимка“. Изключете, ако вече ползвате друг плъгин за прегледи, и въведете неговия мета ключ в уиджета.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="enc_count_mode">Как се брои</label></th>
					<td>
						<select name="enc_count_mode" id="enc_count_mode">
							<option value="every" <?php selected( get_option( 'enc_count_mode', 'every' ), 'every' ); ?>>Всяко отваряне на статията</option>
							<option value="session" <?php selected( get_option( 'enc_count_mode', 'every' ), 'session' ); ?>>Веднъж на статия за сесия</option>
						</select>
						<p>
							<label>
								<input type="checkbox" name="enc_count_skip_editors" value="1" <?php checked( get_option( 'enc_count_skip_editors', '1' ), '1' ); ?>>
								Не брой прегледите на влезли редактори и администратори
							</label>
						</p>
						<p class="description">Ако тествате брояча, докато сте влезли в сайта, изключете последното или отворете статията в прозорец без вход (incognito).</p>
					</td>
				</tr>
				<tr>
					<th scope="row">В самата статия</th>
					<td>
						<label>
							<input type="checkbox" name="enc_single_show_views" value="1" <?php checked( get_option( 'enc_single_show_views', '1' ), '1' ); ?>>
							Показвай броя прегледи под заглавието
						</label>
					</td>
				</tr>
				<tr>
					<th scope="row">Формати на публикациите</th>
					<td>
						<label>
							<input type="checkbox" name="enc_post_formats" value="1" <?php checked( get_option( 'enc_post_formats', '1' ), '1' ); ?>>
							Специално оформление за Галерия, Видео, Аудио, Връзка, Цитат, Статус и Бележка
						</label>
						<p class="description">Чете данните от плъгина Vafpress Post Formats UI. Изображение и Standard ползват основната снимка на статията.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Бутон „Сподели“ в статията</th>
					<td>
						<?php
						$enc_share_labels = [ 'copy' => 'Копиране на линка', 'facebook' => 'Facebook', 'x' => 'X', 'email' => 'Имейл' ];
						$enc_share_on     = enc_share_networks();
						foreach ( $enc_share_labels as $enc_k => $enc_l ) : ?>
							<label style="margin-right:16px">
								<input type="checkbox" name="enc_share[]" value="<?php echo esc_attr( $enc_k ); ?>" <?php checked( in_array( $enc_k, $enc_share_on, true ) ); ?>>
								<?php echo esc_html( $enc_l ); ?>
							</label>
						<?php endforeach; ?>
						<p class="description">Показват се в менюто, което се отваря от бутона „Сподели“. Ако не е избрано нищо, бутонът се скрива.</p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<hr>
		<h2>Начални (фалшиви) прегледи</h2>
		<p class="description">Задава случайно число прегледи на публикуваните статии, за да не започват от нула. За отделна статия ползвайте полето „Прегледи“ в редактора.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Сигурни ли сте?');">
			<input type="hidden" name="action" value="enc_seed_views">
			<?php wp_nonce_field( 'enc_seed_views' ); ?>
			От <input type="number" name="min" value="100" min="0" style="width:90px">
			до <input type="number" name="max" value="500" min="0" style="width:90px">
			<select name="scope">
				<option value="empty">Само статии без прегледи</option>
				<option value="all">Всички статии (презаписва текущите!)</option>
			</select>
			<?php submit_button( 'Приложи', 'secondary', 'submit', false ); ?>
		</form>
	</div>
	<?php
}
