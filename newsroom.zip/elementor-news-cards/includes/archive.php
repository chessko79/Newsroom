<?php
/**
 * Архивни страници (категории, тагове, автори, дати, търсене) със същите карти.
 * Настройки: Настройки → Newsroom → таб „Архиви“.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- Схема на настройките ---------- */
function enc_arc_schema() {
	$sizes = [];
	foreach ( get_intermediate_image_sizes() as $sz ) {
		$sizes[ $sz ] = $sz;
	}
	$sizes['full'] = 'full';
	$weights = [ '400' => 'Нормално (400)', '500' => 'Средно (500)', '600' => 'Полужирно (600)', '700' => 'Удебелено (700)', '800' => 'Силно удебелено (800)' ];
	$tags    = [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'div' => 'div' ];
	$cols    = [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ];

	$G1 = 'Архиви';
	$G2 = 'Подредба';
	$G3 = 'Заглавие на страницата';
	$G4 = 'Елементи на картата';
	$G5 = 'Стил на картата';
	$G6 = 'Заглавие на новината';
	$G7 = 'Дата и прегледи';

	return [
		'enabled'    => [ 'g' => $G1, 'label' => 'Ползвай картите за архивите (категории, тагове, автори, дати, търсене)', 'type' => 'checkbox', 'default' => 1 ],
		'per_page'   => [ 'g' => $G1, 'label' => 'Новини на страница', 'type' => 'number', 'default' => 12, 'min' => 3, 'max' => 60 ],
		'show_head'  => [ 'g' => $G1, 'label' => 'Показвай заглавие на архива', 'type' => 'checkbox', 'default' => 1 ],
		'show_desc'  => [ 'g' => $G1, 'label' => 'Показвай описанието (на категорията, тага, автора)', 'type' => 'checkbox', 'default' => 1 ],
		'show_count' => [ 'g' => $G1, 'label' => 'Показвай броя на новините', 'type' => 'checkbox', 'default' => 1 ],
		'accent'     => [ 'g' => $G1, 'label' => 'Акцентен цвят (страници, при посочване)', 'type' => 'color', 'default' => '' ],

		'layout'       => [ 'g' => $G2, 'label' => 'Показване', 'type' => 'select', 'default' => 'grid', 'options' => [ 'grid' => 'Мрежа (карти в колони)', 'list' => 'Списък (снимка отстрани)' ] ],
		'list_img_pos' => [ 'g' => $G2, 'label' => 'Позиция на снимката (при списък)', 'type' => 'select', 'default' => 'left', 'options' => [ 'left' => 'Отляво', 'right' => 'Отдясно' ] ],
		'list_img_w'   => [ 'g' => $G2, 'label' => 'Ширина на снимката при списък (px)', 'type' => 'number', 'default' => 280, 'min' => 100, 'max' => 480 ],
		'cols'   => [ 'g' => $G2, 'label' => 'Колони (компютър) – при мрежа', 'type' => 'select', 'default' => '3', 'options' => $cols ],
		'cols_t' => [ 'g' => $G2, 'label' => 'Колони (таблет) – при мрежа', 'type' => 'select', 'default' => '2', 'options' => $cols ],
		'cols_m' => [ 'g' => $G2, 'label' => 'Колони (телефон) – при мрежа', 'type' => 'select', 'default' => '1', 'options' => [ '1' => '1', '2' => '2' ] ],
		'gap'    => [ 'g' => $G2, 'label' => 'Разстояние между картите или редовете (px)', 'type' => 'number', 'default' => 24, 'min' => 0, 'max' => 60 ],

		'head_size'   => [ 'g' => $G3, 'label' => 'Размер на заглавието (px)', 'type' => 'number', 'default' => 34, 'min' => 18, 'max' => 64 ],
		'head_weight' => [ 'g' => $G3, 'label' => 'Дебелина на шрифта', 'type' => 'select', 'default' => '800', 'options' => $weights ],
		'head_color'  => [ 'g' => $G3, 'label' => 'Цвят', 'type' => 'color', 'default' => '' ],

		'show_image'    => [ 'g' => $G4, 'label' => 'Показвай снимка', 'type' => 'checkbox', 'default' => 1 ],
		'image_size'    => [ 'g' => $G4, 'label' => 'Размер на снимката', 'type' => 'select', 'default' => 'medium_large', 'options' => $sizes ],
		'ratio'         => [ 'g' => $G4, 'label' => 'Пропорция на снимката', 'type' => 'select', 'default' => '16 / 10', 'options' => [ '16 / 9' => '16:9', '16 / 10' => '16:10', '3 / 2' => '3:2', '4 / 3' => '4:3', '1 / 1' => '1:1' ] ],
		'zoom'          => [ 'g' => $G4, 'label' => 'Увеличаване на снимката при посочване', 'type' => 'checkbox', 'default' => 1 ],
		'fmt_icon'      => [ 'g' => $G4, 'label' => 'Икона според формата (видео, галерия, аудио)', 'type' => 'checkbox', 'default' => 1 ],
		'show_category' => [ 'g' => $G4, 'label' => 'Етикет на категорията', 'type' => 'checkbox', 'default' => 1 ],
		'badge_color'   => [ 'g' => $G4, 'label' => 'Фон на етикета (празно = цвят на категорията)', 'type' => 'color', 'default' => '' ],
		'badge_text'    => [ 'g' => $G4, 'label' => 'Цвят на текста на етикета', 'type' => 'color', 'default' => '' ],
		'show_date'     => [ 'g' => $G4, 'label' => 'Дата', 'type' => 'checkbox', 'default' => 1 ],
		'date_format'   => [ 'g' => $G4, 'label' => 'Формат на датата', 'type' => 'text', 'default' => 'j M. Y' ],
		'show_views'    => [ 'g' => $G4, 'label' => 'Брой прегледи', 'type' => 'checkbox', 'default' => 1 ],
		'show_excerpt'  => [ 'g' => $G4, 'label' => 'Откъс', 'type' => 'checkbox', 'default' => 1 ],
		'excerpt_len'   => [ 'g' => $G4, 'label' => 'Думи в откъса', 'type' => 'number', 'default' => 18, 'min' => 5, 'max' => 60 ],
		'show_more'     => [ 'g' => $G4, 'label' => 'Линк „Прочети повече“', 'type' => 'checkbox', 'default' => 0 ],
		'more_text'     => [ 'g' => $G4, 'label' => 'Текст на линка', 'type' => 'text', 'default' => 'Прочети повече' ],

		'card_bg'           => [ 'g' => $G5, 'label' => 'Фон на картата', 'type' => 'color', 'default' => '' ],
		'card_radius'       => [ 'g' => $G5, 'label' => 'Радиус на ъглите (px)', 'type' => 'number', 'default' => 12, 'min' => 0, 'max' => 40 ],
		'card_shadow'       => [ 'g' => $G5, 'label' => 'Сянка', 'type' => 'select', 'default' => 'soft', 'options' => [ 'none' => 'Без сянка', 'soft' => 'Лека', 'strong' => 'Силна' ] ],
		'card_border_w'     => [ 'g' => $G5, 'label' => 'Дебелина на контура (px)', 'type' => 'number', 'default' => 0, 'min' => 0, 'max' => 6 ],
		'card_border_color' => [ 'g' => $G5, 'label' => 'Цвят на контура', 'type' => 'color', 'default' => '' ],
		'body_pad'          => [ 'g' => $G5, 'label' => 'Вътрешен отстъп на текста (px)', 'type' => 'number', 'default' => 16, 'min' => 0, 'max' => 40 ],

		'title_tag'    => [ 'g' => $G6, 'label' => 'HTML таг', 'type' => 'select', 'default' => 'h2', 'options' => $tags ],
		'title_color'  => [ 'g' => $G6, 'label' => 'Цвят', 'type' => 'color', 'default' => '' ],
		'title_hover'  => [ 'g' => $G6, 'label' => 'Цвят при посочване', 'type' => 'color', 'default' => '' ],
		'title_size'   => [ 'g' => $G6, 'label' => 'Размер на шрифта (px)', 'type' => 'number', 'default' => 18, 'min' => 10, 'max' => 32 ],
		'title_weight' => [ 'g' => $G6, 'label' => 'Дебелина на шрифта', 'type' => 'select', 'default' => '700', 'options' => $weights ],
		'title_lines'  => [ 'g' => $G6, 'label' => 'Максимум редове', 'type' => 'number', 'default' => 3, 'min' => 1, 'max' => 6 ],

		'meta_color' => [ 'g' => $G7, 'label' => 'Цвят на текста', 'type' => 'color', 'default' => '' ],
		'meta_size'  => [ 'g' => $G7, 'label' => 'Размер на шрифта (px)', 'type' => 'number', 'default' => 13, 'min' => 10, 'max' => 20 ],
	];
}

function enc_arc_opts() {
	$out = [];
	foreach ( enc_arc_schema() as $k => $f ) {
		$out[ $k ] = $f['default'];
	}
	$saved = get_option( 'enc_archive', [] );
	return array_merge( $out, is_array( $saved ) ? $saved : [] );
}

function enc_arc_sanitize( $in ) {
	$in  = is_array( $in ) ? $in : [];
	$out = [];
	foreach ( enc_arc_schema() as $k => $f ) {
		$v = isset( $in[ $k ] ) ? $in[ $k ] : null;
		switch ( $f['type'] ) {
			case 'checkbox':
				$out[ $k ] = empty( $v ) ? 0 : 1;
				break;
			case 'number':
				$out[ $k ] = min( (int) $f['max'], max( (int) $f['min'], (int) $v ) );
				break;
			case 'select':
				$out[ $k ] = ( null !== $v && isset( $f['options'][ $v ] ) ) ? (string) $v : (string) $f['default'];
				break;
			case 'color':
				$c         = sanitize_hex_color( (string) $v );
				$out[ $k ] = $c ? $c : '';
				break;
			default:
				$out[ $k ] = null === $v ? $f['default'] : sanitize_text_field( $v );
		}
	}
	return $out;
}

add_action( 'admin_init', function () {
	register_setting( 'enc_settings_archive', 'enc_archive', [ 'type' => 'array', 'sanitize_callback' => 'enc_arc_sanitize' ] );
} );

/* ---------- Таб „Архиви“ ---------- */
function enc_settings_archive_tab() {
	$o      = enc_arc_opts();
	$groups = [];
	foreach ( enc_arc_schema() as $k => $f ) {
		$groups[ $f['g'] ][ $k ] = $f;
	}
	?>
	<form method="post" action="options.php">
		<?php settings_fields( 'enc_settings_archive' ); ?>
		<p class="description">Страниците на категориите, таговете, авторите, датите и търсенето се показват със същите карти като в „Свързани новини“. Празните цветове ползват стандартните цветове на шаблона.</p>
		<?php foreach ( $groups as $title => $fields ) : ?>
			<h2 class="title"><?php echo esc_html( $title ); ?></h2>
			<table class="form-table" role="presentation">
				<?php foreach ( $fields as $key => $f ) :
					$id   = 'enc_arc_' . $key;
					$name = 'enc_archive[' . $key . ']';
					$val  = $o[ $key ];
					?>
					<tr>
						<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $f['label'] ); ?></label></th>
						<td>
							<?php
							switch ( $f['type'] ) {
								case 'checkbox':
									printf( '<input type="checkbox" id="%s" name="%s" value="1" %s>', esc_attr( $id ), esc_attr( $name ), checked( ! empty( $val ), true, false ) );
									break;
								case 'number':
									printf( '<input type="number" class="small-text" id="%s" name="%s" min="%d" max="%d" value="%d">', esc_attr( $id ), esc_attr( $name ), (int) $f['min'], (int) $f['max'], (int) $val );
									break;
								case 'select':
									echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
									foreach ( $f['options'] as $ov => $ol ) {
										echo '<option value="' . esc_attr( $ov ) . '"' . selected( (string) $val, (string) $ov, false ) . '>' . esc_html( $ol ) . '</option>';
									}
									echo '</select>';
									break;
								case 'color':
									printf( '<input type="text" class="enc-color-field" id="%s" name="%s" value="%s">', esc_attr( $id ), esc_attr( $name ), esc_attr( $val ) );
									break;
								default:
									printf( '<input type="text" class="regular-text" id="%s" name="%s" value="%s">', esc_attr( $id ), esc_attr( $name ), esc_attr( $val ) );
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
		<?php endforeach; ?>
		<?php submit_button(); ?>
	</form>
	<?php
}

/* ---------- Кога се ползва шаблонът ---------- */
function enc_arc_active() {
	if ( is_admin() ) {
		return false;
	}
	$o = enc_arc_opts();
	return ! empty( $o['enabled'] ) && ( is_category() || is_tag() || is_author() || is_date() || is_search() );
}

add_filter( 'template_include', function ( $template ) {
	return enc_arc_active() ? ENC_DIR . 'templates/archive.php' : $template;
}, 11 );

add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	if ( ! ( $q->is_category() || $q->is_tag() || $q->is_author() || $q->is_date() || $q->is_search() ) ) {
		return;
	}
	$pt = $q->get( 'post_type' );
	if ( $pt && 'post' !== $pt && ! $q->is_search() ) {
		return; // не пипаме архиви на други типове съдържание (магазин и др.)
	}
	$o = enc_arc_opts();
	if ( ! empty( $o['enabled'] ) ) {
		$q->set( 'posts_per_page', (int) $o['per_page'] );
	}
} );

/* ---------- Заглавие на архива ---------- */
function enc_arc_heading() {
	$kicker = '';
	$title  = '';
	$color  = '';
	if ( is_category() ) {
		$kicker = 'Категория';
		$title  = single_cat_title( '', false );
		$color  = enc_cat_color( get_queried_object_id() );
	} elseif ( is_tag() ) {
		$kicker = 'Таг';
		$title  = single_tag_title( '', false );
	} elseif ( is_author() ) {
		$kicker = 'Автор';
		$title  = get_the_author_meta( 'display_name', get_queried_object_id() );
	} elseif ( is_search() ) {
		$kicker = 'Резултати от търсене';
		$title  = get_search_query();
	} elseif ( is_day() ) {
		$kicker = 'Архив';
		$title  = date_i18n( 'j F Y', mktime( 0, 0, 0, (int) get_query_var( 'monthnum' ), (int) get_query_var( 'day' ), (int) get_query_var( 'year' ) ) );
	} elseif ( is_month() ) {
		$kicker = 'Архив';
		$title  = trim( single_month_title( ' ', false ) );
	} elseif ( is_year() ) {
		$kicker = 'Архив';
		$title  = get_query_var( 'year' );
	}
	if ( '' === (string) $title ) {
		$title = wp_strip_all_tags( get_the_archive_title() );
	}
	return [ $kicker, (string) $title, $color ];
}

function enc_arc_description() {
	if ( is_category() || is_tag() ) {
		return wp_kses_post( term_description() );
	}
	if ( is_author() ) {
		$bio = get_the_author_meta( 'description', get_queried_object_id() );
		return $bio ? wpautop( esc_html( $bio ) ) : '';
	}
	return '';
}

/* ---------- CSS променливи ---------- */
function enc_arc_vars( $o ) {
	$shadows = [ 'none' => 'none', 'soft' => '0 1px 4px rgba(16,40,90,.12)', 'strong' => '0 8px 24px rgba(16,40,90,.18)' ];
	$vars    = [
		'--arc-cols'         => (int) $o['cols'],
		'--arc-cols-t'       => (int) $o['cols_t'],
		'--arc-cols-m'       => (int) $o['cols_m'],
		'--arc-gap'          => (int) $o['gap'] . 'px',
		'--arc-img-w'        => (int) $o['list_img_w'] . 'px',
		'--arc-radius'       => (int) $o['card_radius'] . 'px',
		'--arc-pad'          => (int) $o['body_pad'] . 'px',
		'--arc-ratio'        => $o['ratio'],
		'--arc-shadow'       => $shadows[ $o['card_shadow'] ],
		'--arc-title-size'   => (int) $o['title_size'] . 'px',
		'--arc-title-weight' => (int) $o['title_weight'],
		'--arc-title-lines'  => (int) $o['title_lines'],
		'--arc-meta-size'    => (int) $o['meta_size'] . 'px',
		'--arc-head-size'    => (int) $o['head_size'] . 'px',
		'--arc-head-weight'  => (int) $o['head_weight'],
	];
	$colors = [
		'--arc-bg' => 'card_bg', '--arc-title-color' => 'title_color', '--arc-title-hover' => 'title_hover',
		'--arc-meta-color' => 'meta_color', '--arc-head-color' => 'head_color', '--arc-badge-color' => 'badge_text', '--arc-accent' => 'accent',
	];
	foreach ( $colors as $var => $key ) {
		if ( '' !== $o[ $key ] ) {
			$vars[ $var ] = $o[ $key ];
		}
	}
	if ( (int) $o['card_border_w'] > 0 ) {
		$vars['--arc-border'] = (int) $o['card_border_w'] . 'px solid ' . ( '' !== $o['card_border_color'] ? $o['card_border_color'] : '#e3e7ee' );
	}
	$style = '';
	foreach ( $vars as $k => $v ) {
		$style .= $k . ':' . $v . ';';
	}
	return $style;
}

/* ---------- Съдържанието на архива (заглавие + карти + страници) ---------- */
function enc_render_archive_main() {
	global $wp_query;
	$o     = enc_arc_opts();
	$style = enc_arc_vars( $o );
	$eye   = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
	$tag   = in_array( $o['title_tag'], [ 'h2', 'h3', 'h4', 'div' ], true ) ? $o['title_tag'] : 'h2';

	echo '<div class="enc-arc__main' . ( $o['zoom'] ? ' enc-arc--zoom' : '' ) . '" style="' . esc_attr( $style ) . '">';

	if ( $o['show_head'] ) {
		list( $kicker, $title, $color ) = enc_arc_heading();
		echo '<header class="enc-arc__head">';
		if ( $kicker ) {
			echo '<span class="enc-arc__kicker"' . ( $color ? ' style="--enc-cat:' . esc_attr( $color ) . '"' : '' ) . '>' . esc_html( $kicker ) . '</span>';
		}
		echo '<h1 class="enc-arc__h1">' . esc_html( $title ) . '</h1>';
		if ( $o['show_desc'] ) {
			$desc = enc_arc_description();
			if ( $desc ) {
				echo '<div class="enc-arc__desc">' . $desc . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
		}
		if ( $o['show_count'] && $wp_query->found_posts ) {
			$n = (int) $wp_query->found_posts;
			echo '<div class="enc-arc__count">' . esc_html( $n . ( 1 === $n ? ' новина' : ' новини' ) ) . '</div>';
		}
		echo '</header>';
	}

	if ( ! have_posts() ) {
		echo '<p class="enc-arc__empty">Няма намерени новини.</p>';
		if ( is_search() ) {
			get_search_form();
		}
		echo '</div>';
		return;
	}

	$gcls = 'enc-arc__grid';
	if ( 'list' === $o['layout'] ) {
		$gcls .= ' enc-arc__grid--list' . ( 'right' === $o['list_img_pos'] ? ' enc-arc__grid--img-right' : '' );
	}
	echo '<div class="' . esc_attr( $gcls ) . '">';
	while ( have_posts() ) {
		the_post();
		$id      = get_the_ID();
		$link    = get_permalink();
		$has_img = $o['show_image'] && has_post_thumbnail();
		$fmt     = enc_format_icons( $id, [ 'show_fmt_icon' => $o['fmt_icon'] ? 'yes' : '', 'fmt_icons' => [ 'gallery', 'video', 'audio' ], 'fmt_icon_pos' => 'tr' ], $has_img );

		$meta = $fmt['inline'];
		if ( $o['show_category'] && 'post' === get_post_type() ) {
			$cats = get_the_category( $id );
			if ( $cats ) {
				$c     = $cats[0];
				$bg    = '' !== $o['badge_color'] ? $o['badge_color'] : enc_cat_color( $c->term_id );
				$meta .= '<a class="enc-arc__badge" style="background-color:' . esc_attr( $bg ) . '" href="' . esc_url( get_category_link( $c ) ) . '">' . esc_html( $c->name ) . '</a>';
			}
		}
		if ( $o['show_date'] ) {
			$meta .= '<time datetime="' . esc_attr( get_the_date( 'c' ) ) . '">' . esc_html( get_the_date( $o['date_format'] ? $o['date_format'] : 'j M. Y' ) ) . '</time>';
		}
		if ( $o['show_views'] ) {
			$meta .= '<span class="enc-arc__views">' . $eye . '<span>' . (int) get_post_meta( $id, 'enc_views', true ) . '</span></span>';
		}

		echo '<article class="enc-arc__card">';
		if ( $o['show_image'] ) {
			echo '<a class="enc-arc__media" href="' . esc_url( $link ) . '" tabindex="-1" aria-hidden="true">';
			if ( has_post_thumbnail() ) {
				echo get_the_post_thumbnail( $id, $o['image_size'], [ 'loading' => 'lazy', 'alt' => '' ] ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</a>';
		}
		echo '<div class="enc-arc__body">';
		echo '<' . $tag . ' class="enc-arc__title"><a href="' . esc_url( $link ) . '">' . esc_html( get_the_title() ) . '</a></' . $tag . '>';
		if ( $o['show_excerpt'] ) {
			echo '<p class="enc-arc__excerpt">' . esc_html( wp_trim_words( get_the_excerpt(), (int) $o['excerpt_len'] ) ) . '</p>';
		}
		if ( $meta ) {
			echo '<div class="enc-arc__meta">' . $meta . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( $o['show_more'] ) {
			echo '<a class="enc-arc__more" href="' . esc_url( $link ) . '">' . esc_html( $o['more_text'] ) . ' →</a>';
		}
		echo '</div></article>';
	}
	echo '</div>';

	$links = paginate_links( [ 'type' => 'array', 'prev_text' => '‹', 'next_text' => '›', 'mid_size' => 1, 'end_size' => 1 ] );
	if ( $links ) {
		echo '<nav class="enc-arc__pager" aria-label="Страници"><ul>';
		foreach ( $links as $l ) {
			echo '<li>' . $l . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</ul></nav>';
	}
	echo '</div>';
}
