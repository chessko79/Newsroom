<?php
/**
 * Plugin Name: Newsroom – новинарска система
 * Description: Новинарска система за WordPress: Elementor уиджети (карти, списъци, водеща новина), шаблон за статия с формати, брояч на прегледи и бутон за споделяне.
 * Version: 1.18.0
 * Text Domain: enc
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ENC_VERSION', '1.18.0' );
define( 'ENC_NAME', 'Newsroom' );
define( 'ENC_DIR', plugin_dir_path( __FILE__ ) );
define( 'ENC_URL', plugin_dir_url( __FILE__ ) );

require_once ENC_DIR . 'includes/helpers.php';
require_once ENC_DIR . 'includes/related-news.php';
require_once ENC_DIR . 'includes/archive.php';
require_once ENC_DIR . 'includes/views.php';
require_once ENC_DIR . 'includes/editorial.php';
require_once ENC_DIR . 'includes/related.php';
require_once ENC_DIR . 'includes/render.php';
require_once ENC_DIR . 'includes/wp-widgets.php';

/* Собствена категория в панела на Elementor */
add_action( 'elementor/elements/categories_registered', function ( $elements_manager ) {
	$elements_manager->add_category( 'enc-newsroom', [ 'title' => ENC_NAME, 'icon' => 'eicon-posts-grid' ] );
} );

/* Уиджети (куката се изпълнява само ако Elementor е зареден) */
add_action( 'elementor/widgets/register', function ( $widgets_manager ) {
	require_once ENC_DIR . 'widgets/news-cards.php';
	require_once ENC_DIR . 'widgets/post-header.php';
	require_once ENC_DIR . 'widgets/news-hero.php';
	require_once ENC_DIR . 'widgets/news-list.php';
	require_once ENC_DIR . 'widgets/news-lead.php';
	require_once ENC_DIR . 'widgets/news-top.php';
	require_once ENC_DIR . 'widgets/news-latest.php';
	require_once ENC_DIR . 'widgets/news-small-list.php';
	$widgets_manager->register( new \ENC_News_Cards_Widget() );
	$widgets_manager->register( new \ENC_Post_Header_Widget() );
	$widgets_manager->register( new \ENC_News_Hero_Widget() );
	$widgets_manager->register( new \ENC_News_List_Widget() );
	$widgets_manager->register( new \ENC_News_Lead_Widget() );
	$widgets_manager->register( new \ENC_Most_Read_Widget() );
	$widgets_manager->register( new \ENC_Latest_Widget() );
	$widgets_manager->register( new \ENC_Small_List_Widget() );
} );

/* Вграден шаблон за единична статия (работи и без Elementor Pro) */
add_filter( 'template_include', function ( $template ) {
	if ( '1' === get_option( 'enc_single_enabled', '1' ) && is_singular( 'post' ) ) {
		return ENC_DIR . 'templates/single.php';
	}
	return $template;
}, 11 );
