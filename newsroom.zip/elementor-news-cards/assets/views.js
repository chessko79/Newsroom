(function () {
	var d = window.encViews;
	if (!d || !d.id || !d.url || d.skip) { return; }

	// Режим „веднъж за сесия“; иначе се брои всяко отваряне
	if (d.mode === 'session') {
		try {
			var k = 'enc_v_' + d.id;
			if (sessionStorage.getItem(k)) { return; }
			sessionStorage.setItem(k, '1');
		} catch (e) {}
	}

	fetch(d.url, { method: 'POST', body: new URLSearchParams({ id: d.id }), keepalive: true, credentials: 'omit' })
		.then(function (r) { return r.json(); })
		.then(function (res) {
			if (res && typeof res.views === 'number') {
				var els = document.querySelectorAll('[data-enc-views="' + d.id + '"]');
				for (var i = 0; i < els.length; i++) { els[i].textContent = res.views; }
			}
		})
		.catch(function () {});
})();
