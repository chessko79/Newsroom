(function () {
	/* „преди X минути“ – опреснява се и в кеширани страници */
	function ago(ts, maxDays, dateText) {
		var d = Math.max(0, Math.floor(Date.now() / 1000) - ts);
		if (d < 60) { return 'току-що'; }
		var m = Math.floor(d / 60);
		if (m < 60) { return 'преди ' + m + ' ' + (m === 1 ? 'минута' : 'минути'); }
		var h = Math.floor(m / 60);
		if (h < 24) { return 'преди ' + h + ' ' + (h === 1 ? 'час' : 'часа'); }
		var days = Math.floor(h / 24);
		if (days < Math.max(1, maxDays)) { return 'преди ' + days + ' ' + (days === 1 ? 'ден' : 'дни'); }
		return dateText;
	}

	function refreshTimes() {
		var els = document.querySelectorAll('[data-enc-ago]');
		for (var i = 0; i < els.length; i++) {
			var el = els[i];
			var ts = parseInt(el.getAttribute('data-enc-ago'), 10);
			if (!ts) { continue; }
			var txt = ago(ts, parseInt(el.getAttribute('data-max'), 10) || 7, el.getAttribute('data-date') || el.textContent);
			if (el.textContent !== txt) { el.textContent = txt; }
		}
	}

	/* Слайдър: scroll-snap + стрелки (+ по желание автоматично превъртане) */
	function initSlider(root) {
		if (root._encInit) { return; }
		root._encInit = true;

		var track = root.querySelector('.enc-lt-track');
		var nav = root.querySelector('.enc-lt-nav');
		if (!track || !nav) { return; }

		function step() {
			var item = track.querySelector('.enc-lt-item');
			if (!item) { return track.clientWidth; }
			var gap = parseFloat(getComputedStyle(track).columnGap) || 0;
			var w = item.getBoundingClientRect().width + gap;
			if (root.getAttribute('data-by') === 'page') {
				return Math.max(w, Math.floor(track.clientWidth / w) * w);
			}
			return w;
		}

		function go(dir) {
			var max = track.scrollWidth - track.clientWidth;
			var x = track.scrollLeft + dir * step();
			if (dir > 0 && track.scrollLeft >= max - 2) { x = 0; }
			else if (dir < 0 && track.scrollLeft <= 2) { x = max; }
			track.scrollTo({ left: x, behavior: 'smooth' });
		}

		function check() { nav.hidden = track.scrollWidth <= track.clientWidth + 2; }

		nav.addEventListener('click', function (e) {
			var b = e.target.closest ? e.target.closest('.enc-lt-btn') : null;
			if (b) { go(b.classList.contains('enc-lt-btn--next') ? 1 : -1); }
		});

		check();
		window.addEventListener('resize', check);

		var delay = parseInt(root.getAttribute('data-delay'), 10) || 0;
		var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		if (root.getAttribute('data-autoplay') === '1' && delay > 0 && !reduce) {
			var timer;
			var start = function () {
				stop();
				timer = setInterval(function () { if (!document.hidden && !nav.hidden) { go(1); } }, delay * 1000);
			};
			var stop = function () { clearInterval(timer); };
			root.addEventListener('mouseenter', stop);
			root.addEventListener('mouseleave', start);
			root.addEventListener('focusin', stop);
			root.addEventListener('focusout', start);
			start();
		}
	}

	function boot(scope) {
		var roots = (scope || document).querySelectorAll('.enc-lt--slider');
		for (var i = 0; i < roots.length; i++) { initSlider(roots[i]); }
		refreshTimes();
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () { boot(); });
	} else {
		boot();
	}
	setInterval(refreshTimes, 60000);

	/* Редактор на Elementor: инициализация при всяко прерисуване на уиджета */
	if (window.jQuery) {
		window.jQuery(window).on('elementor/frontend/init', function () {
			if (window.elementorFrontend && window.elementorFrontend.hooks) {
				window.elementorFrontend.hooks.addAction('frontend/element_ready/enc_latest.default', function ($el) { boot($el[0]); });
			}
		});
	}
})();
