(function (wp) {
	var el = wp.element.createElement;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var be = wp.blockEditor || wp.editor;
	var C = wp.components;
	var apiFetch = wp.apiFetch;
	var decode = wp.htmlEntities.decodeEntities;
	var SSR = wp.serverSideRender;

	function textSearch(term) {
		return apiFetch({ path: '/wp/v2/search?type=post&subtype=post&per_page=8&search=' + encodeURIComponent(term) })
			.then(function (rows) { return rows.map(function (r) { return { id: r.id, title: r.title }; }); });
	}

	function lookup(term) {
		var direct = null;
		if (/^\d+$/.test(term)) {
			direct = apiFetch({ path: '/enc/v1/resolve?id=' + term });
		} else if (/^https?:\/\//i.test(term)) {
			direct = apiFetch({ path: '/enc/v1/resolve?url=' + encodeURIComponent(term) });
		}
		if (!direct) { return textSearch(term); }
		return direct.then(function (r) {
			return r && r.id ? [r] : textSearch(term);
		});
	}

	function Picker(props) {
		var q = useState('');
		var res = useState([]);
		var busy = useState(false);

		useEffect(function () {
			var term = q[0].trim();
			if (term.length < 2) { res[1]([]); busy[1](false); return undefined; }
			var cancelled = false;
			busy[1](true);
			var t = setTimeout(function () {
				lookup(term).then(function (list) {
					if (!cancelled) { res[1](list); busy[1](false); }
				}).catch(function () {
					if (!cancelled) { res[1]([]); busy[1](false); }
				});
			}, 300);
			return function () { cancelled = true; clearTimeout(t); };
		}, [q[0]]);

		return el(C.Placeholder, {
			icon: 'admin-links',
			label: 'Свързана новина',
			instructions: 'Потърсете новина по заглавие или поставете линк към нея.'
		},
			el('div', { style: { width: '100%' } },
				el(C.TextControl, {
					value: q[0],
					placeholder: 'Заглавие, линк или номер…',
					onChange: q[1]
				}),
				busy[0] ? el(C.Spinner) : null,
				el('div', null, res[0].map(function (r) {
					return el(C.Button, {
						key: r.id,
						variant: 'tertiary',
						style: { display: 'block', width: '100%', textAlign: 'left', height: 'auto', padding: '8px', whiteSpace: 'normal' },
						onClick: function () { props.onPick(r); }
					}, decode(r.title));
				})),
				(!busy[0] && q[0].trim().length >= 2 && res[0].length === 0) ? el('p', null, 'Няма намерени новини.') : null
			)
		);
	}

	function Edit(props) {
		var a = props.attributes;
		var set = props.setAttributes;
		var blockProps = be.useBlockProps();

		var inspector = el(be.InspectorControls, null,
			el(C.PanelBody, { title: 'Настройки на картата', initialOpen: true },
				el(C.TextControl, {
					label: 'Надпис над заглавието',
					help: 'Оставете празно, за да го скриете.',
					value: a.label,
					onChange: function (v) { set({ label: v }); }
				}),
				el(C.ToggleControl, {
					label: 'Показвай снимка',
					checked: a.showImage,
					onChange: function (v) { set({ showImage: v }); }
				}),
				el(C.ToggleControl, {
					label: 'Показвай категория и дата',
					checked: a.showMeta,
					onChange: function (v) { set({ showMeta: v }); }
				}),
				a.postId ? el(C.Button, {
					variant: 'secondary',
					onClick: function () { set({ postId: 0 }); }
				}, 'Избери друга новина') : null
			)
		);

		if (!a.postId) {
			return el('div', blockProps, inspector, el(Picker, { onPick: function (r) { set({ postId: r.id }); } }));
		}
		return el('div', blockProps, inspector,
			el(C.Disabled, null, el(SSR, { block: 'newsroom/related', attributes: a }))
		);
	}

	wp.blocks.registerBlockType('newsroom/related', {
		apiVersion: 2,
		title: 'Свързана новина',
		description: 'Карта със снимка вляво, която води към друга новина от сайта.',
		icon: 'admin-links',
		category: 'text',
		keywords: ['свързана', 'новина', 'прочетете още', 'related'],
		attributes: {
			postId: { type: 'number', default: 0 },
			label: { type: 'string', default: 'Прочетете още' },
			showImage: { type: 'boolean', default: true },
			showMeta: { type: 'boolean', default: true }
		},
		edit: Edit,
		save: function () { return null; }
	});
})(window.wp);
