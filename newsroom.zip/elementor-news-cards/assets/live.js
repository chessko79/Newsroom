(function () {
	var box = document.querySelector('.enc-live[data-live="1"]');
	if (!box || !window.fetch) { return; }

	var base = box.getAttribute('data-url');
	var id = box.getAttribute('data-id');
	var last = parseInt(box.getAttribute('data-last'), 10) || 0;
	var list = box.querySelector('.enc-live__list');
	var upd = box.querySelector('.enc-live__upd');
	var timer;

	function endLive() {
		clearInterval(timer);
		box.setAttribute('data-live', '0');
		box.classList.remove('is-live');
		var badges = document.querySelectorAll('.enc-live-badge');
		for (var i = 0; i < badges.length; i++) { badges[i].parentNode.removeChild(badges[i]); }
	}

	function poll() {
		if (document.hidden) { return; }
		var url = base + (base.indexOf('?') > -1 ? '&' : '?') + 'id=' + encodeURIComponent(id) + '&after=' + last;
		fetch(url, { credentials: 'omit', cache: 'no-store' })
			.then(function (r) { return r.ok ? r.json() : null; })
			.then(function (res) {
				if (!res) { return; }
				if (res.items && res.items.length) {
					var tmp = document.createElement('div');
					tmp.innerHTML = res.items.join('');
					var first = list.firstChild;
					while (tmp.firstChild) { list.insertBefore(tmp.firstChild, first); }
					var empty = box.querySelector('.enc-live__empty');
					if (empty) { empty.parentNode.removeChild(empty); }
				}
				if (res.ts) { last = Math.max(last, res.ts); }
				if (upd && res.upd) { upd.textContent = res.upd; }
				if (res.live === false) { endLive(); }
			})
			.catch(function () {});
	}

	timer = setInterval(poll, 30000);
	document.addEventListener('visibilitychange', function () { if (!document.hidden) { poll(); } });
})();
