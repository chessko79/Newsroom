(function () {
	function flash(btn, text) {
		btn.setAttribute('data-tip', text);
		clearTimeout(btn._encTimer);
		btn._encTimer = setTimeout(function () { btn.removeAttribute('data-tip'); }, 1800);
	}

	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.enc-share') : null;
		if (!btn) { return; }

		var url = btn.getAttribute('data-url') || window.location.href;
		var title = btn.getAttribute('data-title') || document.title;

		if (navigator.share) {
			navigator.share({ title: title, url: url }).catch(function () {});
			return;
		}
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(url).then(function () {
				flash(btn, btn.getAttribute('data-copied') || 'Копирано');
			});
			return;
		}
		window.prompt('Копирайте линка:', url);
	});
})();

/* Галерия: бутони и брояч (scroll-snap, без външни библиотеки) */
(function () {
	function update(gal) {
		var t = gal.querySelector('.enc-gal__track');
		var c = gal.querySelector('.enc-gal__count');
		if (!t || !c || !t.clientWidth) { return; }
		c.textContent = (Math.round(t.scrollLeft / t.clientWidth) + 1) + ' / ' + t.children.length;
	}

	document.addEventListener('click', function (e) {
		var b = e.target.closest ? e.target.closest('.enc-gal__btn') : null;
		if (!b) { return; }
		var gal = b.closest('.enc-gal');
		var t = gal.querySelector('.enc-gal__track');
		t.scrollBy({ left: (b.classList.contains('enc-gal__next') ? 1 : -1) * t.clientWidth, behavior: 'smooth' });
	});

	document.addEventListener('scroll', function (e) {
		var t = e.target;
		if (t && t.classList && t.classList.contains('enc-gal__track')) { update(t.closest('.enc-gal')); }
	}, true);
})();

/* Меню „Сподели“: отваряне/затваряне и копиране на линка */
(function () {
	function closeAll(except) {
		var open = document.querySelectorAll('.enc-share-wrap.is-open');
		for (var i = 0; i < open.length; i++) {
			if (open[i] === except) { continue; }
			open[i].classList.remove('is-open');
			var b = open[i].querySelector('.enc-sharebtn');
			var p = open[i].querySelector('.enc-sharepop');
			if (b) { b.setAttribute('aria-expanded', 'false'); }
			if (p) { p.hidden = true; }
		}
	}

	function copyText(text, done) {
		function fallback() {
			var t = document.createElement('textarea');
			t.value = text;
			t.setAttribute('readonly', '');
			t.style.position = 'fixed';
			t.style.opacity = '0';
			document.body.appendChild(t);
			t.select();
			try { document.execCommand('copy'); done(); } catch (e) { window.prompt('Копирайте линка:', text); }
			document.body.removeChild(t);
		}
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(done, fallback);
		} else {
			fallback();
		}
	}

	document.addEventListener('click', function (e) {
		var t = e.target;
		if (!t.closest) { return; }

		var btn = t.closest('.enc-sharebtn');
		if (btn) {
			var wrap = btn.closest('.enc-share-wrap');
			var opening = !wrap.classList.contains('is-open');
			closeAll();
			if (opening) {
				wrap.classList.add('is-open');
				btn.setAttribute('aria-expanded', 'true');
				wrap.querySelector('.enc-sharepop').hidden = false;
			}
			return;
		}

		var copy = t.closest('.enc-sharepop__item[data-act="copy"]');
		if (copy) {
			copyText(copy.getAttribute('data-url') || window.location.href, function () {
				copy.setAttribute('data-tip', copy.getAttribute('data-copied') || 'Копирано');
				clearTimeout(copy._encTimer);
				copy._encTimer = setTimeout(function () { copy.removeAttribute('data-tip'); }, 1800);
			});
			return;
		}

		if (t.closest('a.enc-sharepop__item')) { closeAll(); return; }
		if (!t.closest('.enc-sharepop')) { closeAll(); }
	});

	document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeAll(); } });
})();
