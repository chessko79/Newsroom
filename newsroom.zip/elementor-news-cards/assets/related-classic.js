(function () {
	var modal, input, list, timer, seq = 0;

	function decode(s) {
		var t = document.createElement('textarea');
		t.innerHTML = s;
		return t.value;
	}

	function textSearch(term) {
		return wp.apiFetch({ path: '/wp/v2/search?type=post&subtype=post&per_page=10&search=' + encodeURIComponent(term) })
			.then(function (rows) { return rows.map(function (r) { return { id: r.id, title: r.title }; }); });
	}

	function lookup(term) {
		var direct = null;
		if (/^\d+$/.test(term)) {
			direct = wp.apiFetch({ path: '/enc/v1/resolve?id=' + term });
		} else if (/^https?:\/\//i.test(term)) {
			direct = wp.apiFetch({ path: '/enc/v1/resolve?url=' + encodeURIComponent(term) });
		}
		if (!direct) { return textSearch(term); }
		return direct.then(function (r) { return r && r.id ? [r] : textSearch(term); });
	}

	function close() { if (modal) { modal.hidden = true; } }

	function insert(id) {
		var sc = '\n[enc_related id="' + id + '"]\n';
		if (window.wp && wp.media && wp.media.editor && wp.media.editor.insert) {
			wp.media.editor.insert(sc);
		} else if (window.send_to_editor) {
			window.send_to_editor(sc);
		}
		close();
	}

	function render(items) {
		list.innerHTML = '';
		if (!items.length) {
			var li = document.createElement('li');
			li.textContent = 'Няма намерени новини.';
			li.style.padding = '10px 8px';
			list.appendChild(li);
			return;
		}
		items.forEach(function (r) {
			var li = document.createElement('li');
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'enc-rel-modal__item';
			b.textContent = decode(r.title || ('Новина #' + r.id));
			var small = document.createElement('small');
			small.textContent = 'Номер: ' + r.id;
			b.appendChild(small);
			b.addEventListener('click', function () { insert(r.id); });
			li.appendChild(b);
			list.appendChild(li);
		});
	}

	function build() {
		modal = document.createElement('div');
		modal.className = 'enc-rel-modal';
		modal.hidden = true;
		modal.innerHTML =
			'<div class="enc-rel-modal__box" role="dialog" aria-modal="true" aria-label="Свързана новина">' +
			'<div class="enc-rel-modal__head"><strong>Свързана новина</strong><button type="button" class="enc-rel-modal__x" aria-label="Затвори">&times;</button></div>' +
			'<input type="search" class="enc-rel-modal__q" placeholder="Заглавие, линк към новината или номер…">' +
			'<ul class="enc-rel-modal__list"></ul>' +
			'<p class="enc-rel-modal__hint">Започнете да пишете, за да потърсите. В текста се вмъква кратък код [enc_related id="…"], а картата се вижда на сайта.</p>' +
			'</div>';
		document.body.appendChild(modal);

		input = modal.querySelector('.enc-rel-modal__q');
		list = modal.querySelector('.enc-rel-modal__list');

		modal.addEventListener('click', function (e) {
			if (e.target === modal || (e.target.classList && e.target.classList.contains('enc-rel-modal__x'))) { close(); }
		});
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { close(); } });

		input.addEventListener('input', function () {
			clearTimeout(timer);
			var term = input.value.trim();
			if (term.length < 2) { list.innerHTML = ''; return; }
			var my = ++seq;
			timer = setTimeout(function () {
				lookup(term).then(function (items) { if (my === seq) { render(items); } })
					.catch(function () { if (my === seq) { render([]); } });
			}, 300);
		});
	}

	function open() {
		if (!modal) { build(); }
		modal.hidden = false;
		input.value = '';
		list.innerHTML = '';
		input.focus();
	}

	document.addEventListener('click', function (e) {
		var b = e.target.closest ? e.target.closest('.enc-rel-btn') : null;
		if (b) { e.preventDefault(); open(); }
	});
})();
