<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Repeater;

class ENC_News_Cards_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'enc_news_cards'; }
	public function get_title() { return 'Новини – карти'; }
	public function get_icon() { return 'eicon-posts-grid'; }
	public function get_categories() { return [ 'enc-newsroom' ]; }
	public function get_keywords() { return [ 'news', 'новини', 'posts', 'cards', 'карти' ]; }
	public function get_style_depends() { return [ 'enc-news-cards' ]; }

	private function get_term_options() {
		$out   = [];
		$terms = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	private function get_post_type_options() {
		$out = [];
		foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) {
			if ( 'attachment' !== $pt->name ) {
				$out[ $pt->name ] = $pt->labels->singular_name;
			}
		}
		return $out;
	}

	protected function register_controls() {
		$terms = $this->get_term_options();

		/* ---------- Съдържание ---------- */
		$this->start_controls_section( 'section_query', [ 'label' => 'Заявка' ] );

		$this->add_control( 'post_type', [
			'label' => 'Тип съдържание', 'type' => Controls_Manager::SELECT,
			'options' => $this->get_post_type_options(), 'default' => 'post',
		] );
		$this->add_control( 'categories', [
			'label' => 'Категории', 'type' => Controls_Manager::SELECT2, 'multiple' => true,
			'options' => $terms, 'label_block' => true, 'condition' => [ 'post_type' => 'post' ],
		] );
		$this->add_control( 'posts_per_page', [
			'label' => 'Брой новини', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 24,
		] );
		$this->add_control( 'offset', [
			'label' => 'Пропусни първите', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0,
		] );
		$this->add_control( 'orderby', [
			'label' => 'Подредба по', 'type' => Controls_Manager::SELECT, 'default' => 'date',
			'options' => [ 'date' => 'Дата', 'title' => 'Заглавие', 'modified' => 'Последна промяна', 'rand' => 'Случайно', 'comment_count' => 'Коментари' ],
		] );
		$this->add_control( 'order', [
			'label' => 'Посока', 'type' => Controls_Manager::SELECT, 'default' => 'DESC',
			'options' => [ 'DESC' => 'Най-новите първо', 'ASC' => 'Най-старите първо' ],
		] );
		$this->add_control( 'exclude_current', [
			'label' => 'Без текущата статия', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes',
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'section_content', [ 'label' => 'Елементи на картата' ] );
		$this->add_control( 'show_image', [ 'label' => 'Снимка', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'image_size', [
			'label' => 'Размер на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'medium_large',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
			'condition' => [ 'show_image' => 'yes' ],
		] );
		$this->add_control( 'show_category', [ 'label' => 'Етикет на категорията', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'show_date', [ 'label' => 'Дата', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'date_format', [
			'label' => 'Формат на датата', 'type' => Controls_Manager::TEXT, 'default' => 'j F Y',
			'condition' => [ 'show_date' => 'yes' ],
		] );
		$this->add_control( 'show_fmt_icon', [ 'label' => 'Икона според формата на публикацията', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'fmt_icons', [
			'label' => 'За кои формати', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => enc_format_labels(), 'default' => [ 'gallery', 'video', 'audio' ], 'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->add_control( 'fmt_icon_pos', [
			'label' => 'Позиция на иконата', 'type' => Controls_Manager::SELECT, 'default' => 'tr',
			'options' => [
				'tr' => 'Горе вдясно (върху снимката)', 'tl' => 'Горе вляво', 'br' => 'Долу вдясно', 'bl' => 'Долу вляво',
				'center' => 'В центъра (голяма)', 'meta' => 'В реда с датата',
			],
			'description' => 'Ако новината няма снимка, иконата се показва в реда с датата.',
			'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->add_control( 'show_views', [ 'label' => 'Брой прегледи', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'views_key', [
			'label' => 'Мета ключ за прегледите', 'type' => Controls_Manager::TEXT, 'default' => 'enc_views',
			'description' => 'Вграденият брояч ползва enc_views.', 'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->add_control( 'meta_position', [
			'label' => 'Позиция на категорията, датата и прегледите', 'type' => Controls_Manager::SELECT, 'default' => 'below',
			'options' => [ 'below' => 'Под заглавието', 'above' => 'Над заглавието' ],
		] );
		$this->add_control( 'show_excerpt', [ 'label' => 'Откъс', 'type' => Controls_Manager::SWITCHER, 'default' => '' ] );
		$this->add_control( 'excerpt_length', [
			'label' => 'Брой думи в откъса', 'type' => Controls_Manager::NUMBER, 'default' => 18,
			'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_control( 'show_more', [ 'label' => 'Линк „Прочети повече“', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes' ] );
		$this->add_control( 'more_text', [
			'label' => 'Текст на линка', 'type' => Controls_Manager::TEXT, 'default' => 'Прочети повече',
			'condition' => [ 'show_more' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Цветове на категориите ---------- */
		$this->start_controls_section( 'section_badge_colors', [ 'label' => 'Цветове на категориите' ] );
		$rep = new Repeater();
		$rep->add_control( 'term', [ 'label' => 'Категория', 'type' => Controls_Manager::SELECT2, 'options' => $terms, 'label_block' => true ] );
		$rep->add_control( 'color', [ 'label' => 'Цвят', 'type' => Controls_Manager::COLOR, 'default' => '#1e6fd9' ] );
		$this->add_control( 'badge_colors', [
			'label' => 'Цвят по категория', 'type' => Controls_Manager::REPEATER, 'fields' => $rep->get_controls(),
			'title_field' => '{{{ color }}}',
			'description' => 'Категории без зададен цвят получават автоматичен от палитра.',
		] );
		$this->end_controls_section();

		/* ---------- Стил: решетка и карта ---------- */
		$this->start_controls_section( 'style_layout', [ 'label' => 'Решетка и карта', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'columns', [
			'label' => 'Колони', 'type' => Controls_Manager::SELECT,
			'default' => '3', 'tablet_default' => '2', 'mobile_default' => '1',
			'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ],
			'selectors' => [ '{{WRAPPER}} .enc-grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ],
		] );
		$this->add_responsive_control( 'gap', [
			'label' => 'Разстояние', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 80 ] ], 'default' => [ 'size' => 24, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-grid' => 'gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'image_height', [
			'label' => 'Височина на снимката', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 100, 'max' => 500 ] ], 'default' => [ 'size' => 200, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-card__media' => 'height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'card_radius', [
			'label' => 'Радиус на картата', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 14, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-card' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'card_bg', [
			'label' => 'Фон на картата', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-card' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'card_padding', [
			'label' => 'Вътрешен отстъп', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-card__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_control( 'no_shadow', [
			'label' => 'Без сянка', 'type' => Controls_Manager::SWITCHER, 'default' => '',
			'description' => 'Изключва сянката около картата (и при посочване).',
			'selectors' => [ '{{WRAPPER}} .enc-grid .enc-card' => 'box-shadow: none;' ],
		] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name' => 'card_shadow', 'selector' => '{{WRAPPER}} .enc-card',
		] );
		$this->end_controls_section();

		/* ---------- Стил: етикет ---------- */
		$this->start_controls_section( 'style_fmt', [ 'label' => 'Икона на формата', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_fmt_icon' => 'yes' ] ] );
		$this->add_control( 'fmt_color', [
			'label' => 'Цвят на иконата', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_bg', [
			'label' => 'Фон на кръга (върху снимката)', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_size', [
			'label' => 'Размер на кръга', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 20, 'max' => 80 ] ], 'default' => [ 'size' => 30, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov:not(.enc-fmt--center)' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'fmt_icon_size', [
			'label' => 'Размер на иконата', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 40 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt:not(.enc-fmt--center) svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'style_badge', [ 'label' => 'Етикет', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'badge_color', [
			'label' => 'Цвят на текста', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-badge' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'badge_typo', 'selector' => '{{WRAPPER}} .enc-badge',
		] );
		$this->add_control( 'badge_radius', [
			'label' => 'Радиус', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
			'selectors' => [ '{{WRAPPER}} .enc-badge' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: дата, заглавие, откъс, линк ---------- */
		$this->start_controls_section( 'style_text', [ 'label' => 'Текстове', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'meta_gap', [
			'label' => 'Разстояние между категорията, датата и прегледите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 12, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-meta' => 'column-gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'views_color', [
			'label' => 'Цвят на прегледите', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-views' => 'color: {{VALUE}};' ], 'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'views_typo', 'selector' => '{{WRAPPER}} .enc-views', 'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->add_control( 'views_icon_size', [
			'label' => 'Размер на иконата за прегледи', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 32 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-views svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
			'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->add_control( 'date_color', [
			'label' => 'Цвят на датата', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-date' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'date_typo', 'selector' => '{{WRAPPER}} .enc-date',
		] );
		$this->add_control( 'title_color', [
			'label' => 'Цвят на заглавието', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-title' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'title_hover_color', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-title a:hover' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'title_typo', 'selector' => '{{WRAPPER}} .enc-title',
		] );
		$this->add_control( 'title_lines', [
			'label' => 'Максимум редове в заглавието', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 8,
			'selectors' => [ '{{WRAPPER}} .enc-title' => '-webkit-line-clamp: {{VALUE}};' ],
		] );
		$this->add_control( 'excerpt_color', [
			'label' => 'Цвят на откъса', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-excerpt' => 'color: {{VALUE}};' ],
			'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_control( 'more_color', [
			'label' => 'Цвят на „Прочети повече“', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-more' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'more_hover_color', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-more:hover' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'more_typo', 'selector' => '{{WRAPPER}} .enc-more',
		] );
		$this->end_controls_section();
	}

	/** Първата категория (или първата йерархична таксономия за други типове). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	protected function render() {
		$s         = $this->get_settings_for_display();
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $s['posts_per_page'] ),
			'offset'              => (int) $s['offset'],
			'orderby'             => $s['orderby'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
		];
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$colors = enc_all_term_colors();
		if ( ! empty( $s['badge_colors'] ) ) {
			foreach ( $s['badge_colors'] as $row ) {
				if ( ! empty( $row['term'] ) ) {
					$colors[ (int) $row['term'] ] = $row['color'];
				}
			}
		}
		$palette = [ '#1e6fd9', '#12945a', '#f5a30a', '#d6455d', '#7a4fd1', '#0e8f9c' ];
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';
		$meta_pos  = ( 'above' === $s['meta_position'] ) ? 'above' : 'below';
		$icon_eye  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';

		$q = new WP_Query( $args );

		if ( ! $q->have_posts() ) {
			echo '<div class="enc-empty">Няма намерени новини.</div>';
			return;
		}

		echo '<div class="enc-grid">';
		while ( $q->have_posts() ) {
			$q->the_post();
			$id   = get_the_ID();
			$link = get_permalink();
			$term = ( 'yes' === $s['show_category'] ) ? $this->get_primary_term( $id, $post_type ) : null;
			$fmt  = enc_format_icons( $id, $s, 'yes' === $s['show_image'] );
			?>
			<article class="enc-card">
				<?php if ( 'yes' === $s['show_image'] ) : ?>
					<a class="enc-card__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
						<?php
						if ( has_post_thumbnail() ) {
							echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ] );
						}
						echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput
						?>
					</a>
				<?php endif; ?>

				<div class="enc-card__body">
					<?php
					$meta = $fmt['inline'];
					if ( $term ) {
						$bg    = isset( $colors[ $term->term_id ] ) ? $colors[ $term->term_id ] : $palette[ $term->term_id % count( $palette ) ];
						$meta .= sprintf(
							'<a class="enc-badge" href="%s" style="background-color:%s">%s</a>',
							esc_url( get_term_link( $term ) ),
							esc_attr( $bg ),
							esc_html( $term->name )
						);
					}
					if ( 'yes' === $s['show_date'] ) {
						$meta .= sprintf(
							'<time class="enc-date" datetime="%s">%s</time>',
							esc_attr( get_the_date( 'c' ) ),
							esc_html( get_the_date( $s['date_format'] ?: 'j F Y' ) )
						);
					}
					if ( 'yes' === $s['show_views'] ) {
						$meta .= '<span class="enc-views">' . $icon_eye . '<span>' . (int) get_post_meta( $id, $views_key, true ) . '</span></span>';
					}
					if ( $meta ) {
						$meta = '<div class="enc-meta enc-meta--' . $meta_pos . '">' . $meta . '</div>';
					}
					if ( 'above' === $meta_pos ) {
						echo $meta; // phpcs:ignore WordPress.Security.EscapeOutput
					}
					?>
					<h3 class="enc-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( get_the_title() ); ?></a></h3>
					<?php
					if ( 'above' !== $meta_pos ) {
						echo $meta; // phpcs:ignore WordPress.Security.EscapeOutput
					}
					?>

					<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
						<p class="enc-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
					<?php endif; ?>

					<?php if ( 'yes' === $s['show_more'] ) : ?>
						<a class="enc-more" href="<?php echo esc_url( $link ); ?>">
							<?php echo esc_html( $s['more_text'] ); ?>
							<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
						</a>
					<?php endif; ?>
				</div>
			</article>
			<?php
		}
		echo '</div>';
		wp_reset_postdata();
	}
}
