<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

class ENC_Small_List_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'enc_small_list'; }
	public function get_title() { return 'Новини – малък списък'; }
	public function get_icon() { return 'eicon-post-list'; }
	public function get_categories() { return [ 'enc-newsroom' ]; }
	public function get_keywords() { return [ 'news', 'новини', 'list', 'малък', 'списък', 'колони', 'компактен' ]; }
	public function get_style_depends() { return [ 'enc-small-list' ]; }
	public function get_script_depends() { return [ 'enc-single' ]; }

	private function get_term_options() {
		$out   = [];
		$terms = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	private function get_post_type_options() {
		$out = [];
		foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) {
			if ( 'attachment' !== $pt->name ) {
				$out[ $pt->name ] = $pt->labels->singular_name;
			}
		}
		return $out;
	}

	protected function register_controls() {
		$terms = $this->get_term_options();
		$sw    = function ( $name, $label, $default = 'yes', $extra = [] ) {
			$this->add_control( $name, array_merge( [ 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'default' => $default ], $extra ) );
		};
		$col = function ( $name, $label, $sel, $prop = 'color', $extra = [] ) {
			$this->add_control( $name, array_merge( [
				'label' => $label, 'type' => Controls_Manager::COLOR,
				'selectors' => [ '{{WRAPPER}} ' . $sel => $prop . ': {{VALUE}};' ],
			], $extra ) );
		};
		$typo = function ( $name, $sel, $extra = [] ) {
			$this->add_group_control( Group_Control_Typography::get_type(), array_merge( [ 'name' => $name, 'selector' => $sel ], $extra ) );
		};
		$px = function ( $name, $label, $sel, $prop, $min, $max, $def, $extra = [] ) {
			$this->add_control( $name, array_merge( [
				'label' => $label, 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
				'range' => [ 'px' => [ 'min' => $min, 'max' => $max ] ], 'default' => [ 'size' => $def, 'unit' => 'px' ],
				'selectors' => [ '{{WRAPPER}} ' . $sel => $prop . ': {{SIZE}}{{UNIT}};' ],
			], $extra ) );
		};

		/* ---------- Заявка ---------- */
		$this->start_controls_section( 'section_query', [ 'label' => 'Заявка' ] );
		$this->add_control( 'post_type', [
			'label' => 'Тип съдържание', 'type' => Controls_Manager::SELECT,
			'options' => $this->get_post_type_options(), 'default' => 'post',
		] );
		$this->add_control( 'categories', [
			'label' => 'Категории', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => $terms, 'condition' => [ 'post_type' => 'post' ],
		] );
		$this->add_control( 'posts_per_page', [ 'label' => 'Брой новини', 'type' => Controls_Manager::NUMBER, 'default' => 6, 'min' => 1, 'max' => 40 ] );
		$this->add_control( 'offset', [ 'label' => 'Пропусни първите', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0 ] );
		$this->add_control( 'orderby', [
			'label' => 'Подредба по', 'type' => Controls_Manager::SELECT, 'default' => 'date',
			'options' => [
				'date' => 'Дата (най-новите)', 'views' => 'Прегледи (най-четени)', 'comment_count' => 'Коментари',
				'modified' => 'Последна промяна', 'title' => 'Заглавие', 'rand' => 'Случайно',
			],
		] );
		$this->add_control( 'order', [
			'label' => 'Посока', 'type' => Controls_Manager::SELECT, 'default' => 'DESC',
			'options' => [ 'DESC' => 'Низходящо', 'ASC' => 'Възходящо' ],
		] );
		$this->add_control( 'days', [
			'label' => 'Само от последните N дни', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0,
			'description' => '0 = без ограничение.',
		] );
		$sw( 'exclude_current', 'Без текущата статия' );
		$this->end_controls_section();

		/* ---------- Колони и снимка ---------- */
		$this->start_controls_section( 'section_layout', [ 'label' => 'Колони и снимка' ] );
		$this->add_responsive_control( 'columns', [
			'label' => 'Колони', 'type' => Controls_Manager::SELECT,
			'default' => '1', 'tablet_default' => '1', 'mobile_default' => '1',
			'options' => [ '1' => '1 колона', '2' => '2 колони', '3' => '3 колони' ],
			'selectors' => [ '{{WRAPPER}} .enc-sl' => '--sl-cols: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'col_gap', [
			'label' => 'Разстояние между колоните', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 80 ] ], 'default' => [ 'size' => 24, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-sl' => '--sl-colgap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'row_gap', [
			'label' => 'Разстояние между редовете (картите)', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 80 ] ], 'default' => [ 'size' => 0, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-sl' => '--sl-rowgap: {{SIZE}}{{UNIT}};' ],
		] );
		$sw( 'show_image', 'Снимка', 'yes', [ 'separator' => 'before' ] );
		$this->add_control( 'image_pos', [
			'label' => 'Позиция на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'left',
			'options' => [ 'left' => 'Отляво', 'right' => 'Отдясно' ], 'condition' => [ 'show_image' => 'yes' ],
		] );
		$this->add_control( 'image_size', [
			'label' => 'Размер на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'medium_large',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
			'condition' => [ 'show_image' => 'yes' ],
		] );
		$sw( 'zoom', 'Увеличаване на снимката при посочване', 'yes', [ 'condition' => [ 'show_image' => 'yes' ] ] );
		$this->end_controls_section();

		/* ---------- Елементи ---------- */
		$this->start_controls_section( 'section_content', [ 'label' => 'Елементи' ] );
		$this->add_control( 'title_tag', [
			'label' => 'HTML таг на заглавието', 'type' => Controls_Manager::SELECT, 'default' => 'h3',
			'options' => [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'div' => 'div' ],
		] );
		$sw( 'show_excerpt', 'Откъс', '' );
		$this->add_control( 'excerpt_length', [
			'label' => 'Думи в откъса', 'type' => Controls_Manager::NUMBER, 'default' => 14, 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_control( 'meta_label', [
			'label' => 'Удебелен етикет в началото', 'type' => Controls_Manager::SELECT, 'default' => 'category', 'separator' => 'before',
			'options' => [ 'category' => 'Категория', 'day' => '„Днес“ / „Вчера“', 'none' => 'Без етикет' ],
		] );
		$sw( 'meta_label_link', 'Категорията е линк', 'yes', [ 'condition' => [ 'meta_label' => 'category' ] ] );
		$sw( 'show_time', 'Час' );
		$this->add_control( 'time_format', [
			'label' => 'Формат на часа', 'type' => Controls_Manager::TEXT, 'default' => 'H:i', 'condition' => [ 'show_time' => 'yes' ],
		] );
		$sw( 'show_date', 'Дата' );
		$this->add_control( 'date_format', [
			'label' => 'Формат на датата', 'type' => Controls_Manager::TEXT, 'default' => 'd.m.y', 'condition' => [ 'show_date' => 'yes' ],
		] );
		$this->add_control( 'meta_sep', [
			'label' => 'Разделител между час и дата', 'type' => Controls_Manager::TEXT, 'default' => '|',
			'condition' => [ 'show_time' => 'yes', 'show_date' => 'yes' ],
		] );
		$sw( 'show_views', 'Брой прегледи' );
		$this->add_control( 'views_key', [
			'label' => 'Мета ключ за прегледите', 'type' => Controls_Manager::TEXT, 'default' => 'enc_views', 'condition' => [ 'show_views' => 'yes' ],
		] );
		$sw( 'show_share', 'Бутон „Сподели“' );
		$this->add_control( 'show_fmt_icon', [ 'label' => 'Икона според формата на публикацията', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'fmt_icons', [
			'label' => 'За кои формати', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => enc_format_labels(), 'default' => [ 'gallery', 'video', 'audio' ], 'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->add_control( 'fmt_icon_pos', [
			'label' => 'Позиция на иконата', 'type' => Controls_Manager::SELECT, 'default' => 'br',
			'options' => [
				'tr' => 'Горе вдясно (върху снимката)', 'tl' => 'Горе вляво', 'br' => 'Долу вдясно', 'bl' => 'Долу вляво',
				'center' => 'В центъра (голяма)', 'meta' => 'В реда с датата',
			],
			'description' => 'Ако новината няма снимка, иконата се показва в реда с датата.',
			'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Цветове по категория ---------- */
		$this->start_controls_section( 'section_cat_colors', [ 'label' => 'Цветове на категориите' ] );
		$rep = new Repeater();
		$rep->add_control( 'term', [ 'label' => 'Категория', 'type' => Controls_Manager::SELECT2, 'options' => $terms, 'label_block' => true ] );
		$rep->add_control( 'color', [ 'label' => 'Цвят', 'type' => Controls_Manager::COLOR, 'default' => '#f07a10' ] );
		$this->add_control( 'cat_colors', [
			'label' => 'Цвят по категория', 'type' => Controls_Manager::REPEATER, 'fields' => $rep->get_controls(),
			'title_field' => '{{{ color }}}',
			'description' => 'Приоритет пред цвета, зададен при редакция на категорията. Без цвят се ползва общият цвят на етикета.',
		] );
		$this->end_controls_section();

		/* ---------- Стил: карти ---------- */
		$this->start_controls_section( 'style_card', [ 'label' => 'Карти', 'tab' => Controls_Manager::TAB_STYLE ] );
		$col( 'card_bg', 'Фон на картата', '.enc-sl-item', 'background-color' );
		$px( 'card_radius', 'Радиус на ъглите', '.enc-sl-item', 'border-radius', 0, 30, 0 );
		$this->add_control( 'sep_type', [
			'label' => 'Линии', 'type' => Controls_Manager::SELECT, 'default' => 'bottom',
			'options' => [ 'bottom' => 'Линия под всяка карта', 'all' => 'Контур около всяка карта', 'none' => 'Без линии' ],
		] );
		$col( 'sep_color', 'Цвят на линиите', '.enc-sl', '--sl-sep-color', [ 'condition' => [ 'sep_type!' => 'none' ] ] );
		$px( 'sep_width', 'Дебелина на линиите', '.enc-sl', '--sl-sep-w', 1, 6, 1, [ 'condition' => [ 'sep_type!' => 'none' ] ] );
		$this->add_control( 'no_shadow', [
			'label' => 'Без сянка', 'type' => Controls_Manager::SWITCHER, 'default' => '',
			'description' => 'Изключва сянката около картите (и при посочване).',
			'selectors' => [ '{{WRAPPER}} .enc-sl .enc-sl-item' => 'box-shadow: none;' ],
		] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name' => 'card_shadow', 'selector' => '{{WRAPPER}} .enc-sl-item',
		] );
		$this->add_responsive_control( 'body_padding', [
			'label' => 'Вътрешен отстъп на текста', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-sl-item__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: снимка ---------- */
		$this->start_controls_section( 'style_img', [ 'label' => 'Снимка', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_image' => 'yes' ] ] );
		$this->add_responsive_control( 'img_w', [
			'label' => 'Ширина', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px', '%' ],
			'range' => [ 'px' => [ 'min' => 60, 'max' => 400 ], '%' => [ 'min' => 10, 'max' => 60 ] ],
			'default' => [ 'size' => 165, 'unit' => 'px' ], 'mobile_default' => [ 'size' => 112, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-sl-item__media' => 'flex-basis: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'img_h', [
			'label' => 'Минимална височина', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 50, 'max' => 300 ] ],
			'default' => [ 'size' => 100, 'unit' => 'px' ], 'mobile_default' => [ 'size' => 84, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-sl-item__media' => 'min-height: {{SIZE}}{{UNIT}};' ],
			'description' => 'Снимката се разтяга по височината на реда.',
		] );
		$px( 'img_radius', 'Радиус на снимката', '.enc-sl-item__media', 'border-radius', 0, 30, 0 );
		$this->end_controls_section();

		/* ---------- Стил: заглавие ---------- */
		$this->start_controls_section( 'style_title', [ 'label' => 'Заглавие', 'tab' => Controls_Manager::TAB_STYLE ] );
		$col( 'title_color', 'Цвят', '.enc-sl-title' );
		$col( 'title_hover', 'Цвят при посочване', '.enc-sl-title a:hover' );
		$typo( 'title_typo', '{{WRAPPER}} .enc-sl-title' );
		$this->add_control( 'title_lines', [
			'label' => 'Максимум редове', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 8,
			'selectors' => [ '{{WRAPPER}} .enc-sl-title' => '-webkit-line-clamp: {{VALUE}};' ],
		] );
		$col( 'excerpt_color', 'Цвят на откъса', '.enc-sl-excerpt', 'color', [ 'separator' => 'before', 'condition' => [ 'show_excerpt' => 'yes' ] ] );
		$typo( 'excerpt_typo', '{{WRAPPER}} .enc-sl-excerpt', [ 'condition' => [ 'show_excerpt' => 'yes' ] ] );
		$this->end_controls_section();

		/* ---------- Стил: категория, дата, прегледи ---------- */
		$this->start_controls_section( 'style_meta', [ 'label' => 'Категория, дата и прегледи', 'tab' => Controls_Manager::TAB_STYLE ] );
		$col( 'label_color', 'Общ цвят на етикета (категорията)', '.enc-sl-meta__label' );
		$typo( 'label_typo', '{{WRAPPER}} .enc-sl-meta__label' );
		$col( 'meta_color', 'Цвят на часа, датата и прегледите', '.enc-sl-meta', 'color', [ 'separator' => 'before' ] );
		$typo( 'meta_typo', '{{WRAPPER}} .enc-sl-meta__time, {{WRAPPER}} .enc-sl-meta__views' );
		$px( 'icon_size', 'Размер на иконата за прегледи', '.enc-sl-meta__views svg', 'width', 10, 32, 16 );
		$px( 'meta_gap', 'Разстояние между елементите', '.enc-sl-meta', 'column-gap', 0, 40, 14 );
		$this->end_controls_section();

		/* ---------- Стил: „Сподели“ ---------- */
		$this->start_controls_section( 'style_share', [ 'label' => 'Бутон „Сподели“', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_share' => 'yes' ] ] );
		$col( 'share_color', 'Цвят', '.enc-sl-share' );
		$col( 'share_hover', 'Цвят при посочване', '.enc-sl-share:hover' );
		$px( 'share_size', 'Размер', '.enc-sl-share svg', 'width', 10, 32, 16 );
		$this->end_controls_section();

		/* ---------- Стил: икона на формата ---------- */
		$this->start_controls_section( 'style_fmt', [ 'label' => 'Икона на формата', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_fmt_icon' => 'yes' ] ] );
		$col( 'fmt_color', 'Цвят на иконата', '.enc-fmt' );
		$col( 'fmt_bg', 'Фон на кръга (върху снимката)', '.enc-fmt--ov', 'background-color' );
		$px( 'fmt_size', 'Размер на кръга', '.enc-fmt--ov:not(.enc-fmt--center)', 'width', 20, 80, 30 );
		$px( 'fmt_icon_size', 'Размер на иконата', '.enc-fmt:not(.enc-fmt--center) svg', 'width', 10, 40, 16 );
		$this->end_controls_section();
	}

	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	private function item_html( $s, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();
		$tag   = $c['tag'];

		$has_image = 'yes' === $s['show_image'] && has_post_thumbnail();
		$fmt       = enc_format_icons( $id, $s, $has_image );

		$label = $label_url = $label_style = '';
		if ( 'category' === $s['meta_label'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$label = $t->name;
				if ( 'yes' === $s['meta_label_link'] ) {
					$u         = get_term_link( $t );
					$label_url = is_wp_error( $u ) ? '' : $u;
				}
				if ( isset( $c['colors'][ $t->term_id ] ) ) {
					$label_style = ' style="color:' . esc_attr( $c['colors'][ $t->term_id ] ) . '"';
				}
			}
		} elseif ( 'day' === $s['meta_label'] ) {
			$pd = get_the_date( 'Y-m-d', $id );
			if ( $pd === $c['today'] ) {
				$label = 'Днес';
			} elseif ( $pd === $c['yester'] ) {
				$label = 'Вчера';
			}
		}

		$parts = [];
		if ( 'yes' === $s['show_time'] ) {
			$parts[] = get_the_time( $s['time_format'] ?: 'H:i', $id );
		}
		if ( 'yes' === $s['show_date'] ) {
			$parts[] = get_the_date( $s['date_format'] ?: 'd.m.y', $id );
		}
		$sep       = trim( (string) $s['meta_sep'] );
		$time_str  = implode( $sep ? ' ' . $sep . ' ' : ' ', $parts );
		$views     = ( 'yes' === $s['show_views'] ) ? (int) get_post_meta( $id, $c['views_key'], true ) : null;
		$has_share = 'yes' === $s['show_share'];
		$has_meta  = $label || $time_str || null !== $views || $has_share || $fmt['inline'];

		$cls = 'enc-sl-item' . ( $has_image && 'right' === $s['image_pos'] ? ' enc-sl-item--img-right' : '' );

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( $has_image ) : ?>
				<a class="enc-sl-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>

			<div class="enc-sl-item__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-sl-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>

				<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
					<p class="enc-sl-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
				<?php endif; ?>

				<?php if ( $has_meta ) : ?>
					<div class="enc-sl-meta">
						<?php echo $fmt['inline']; // phpcs:ignore WordPress.Security.EscapeOutput ?>

						<?php if ( $label ) :
							if ( $label_url ) : ?><a class="enc-sl-meta__label" href="<?php echo esc_url( $label_url ); ?>"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></a><?php
							else : ?><strong class="enc-sl-meta__label"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></strong><?php
							endif;
						endif; ?>

						<?php if ( $time_str ) : ?><time class="enc-sl-meta__time" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $time_str ); ?></time><?php endif; ?>

						<?php if ( null !== $views ) : ?>
							<span class="enc-sl-meta__views"><?php echo $c['icon_eye']; // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $views ); ?></span></span>
						<?php endif; ?>

						<?php if ( $has_share ) : ?>
							<button type="button" class="enc-share enc-sl-share" aria-label="Сподели"
								data-url="<?php echo esc_url( $link ); ?>" data-title="<?php echo esc_attr( $title ); ?>" data-copied="Линкът е копиран">
								<?php echo $c['icon_share']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</button>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	protected function render() {
		$s         = $this->get_settings_for_display();
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $s['posts_per_page'] ),
			'offset'              => (int) $s['offset'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		];
		if ( 'views' === $s['orderby'] ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
				[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
			];
			$args['orderby'] = [ 'enc_v' => $s['order'], 'date' => 'DESC' ];
		} else {
			$args['orderby'] = $s['orderby'];
		}
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( (int) $s['days'] > 0 ) {
			$args['date_query'] = [ [ 'after' => (int) $s['days'] . ' days ago' ] ];
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$q = new WP_Query( $args );
		if ( ! $q->have_posts() ) {
			echo '<div class="enc-sl-empty">Няма намерени новини.</div>';
			return;
		}

		$colors = enc_all_term_colors();
		if ( ! empty( $s['cat_colors'] ) ) {
			foreach ( $s['cat_colors'] as $row ) {
				if ( ! empty( $row['term'] ) && ! empty( $row['color'] ) ) {
					$colors[ (int) $row['term'] ] = $row['color'];
				}
			}
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'colors'     => $colors,
			'tag'        => in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $s['title_tag'] : 'h3',
			'today'      => wp_date( 'Y-m-d' ),
			'yester'     => wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ),
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
			'icon_share' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="currentColor"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></g><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
		];

		$items = [];
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = $this->item_html( $s, $ctx );
		}
		wp_reset_postdata();

		$sep = in_array( $s['sep_type'], [ 'bottom', 'all', 'none' ], true ) ? $s['sep_type'] : 'bottom';
		$cls = 'enc-sl enc-sl--sep-' . $sep . ( 'yes' === $s['zoom'] ? ' enc-sl--zoom' : '' );

		echo '<div class="' . esc_attr( $cls ) . '"><div class="enc-sl-grid">' . implode( '', $items ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
