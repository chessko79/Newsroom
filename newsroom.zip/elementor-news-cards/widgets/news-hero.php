<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;

class ENC_News_Hero_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'enc_news_hero'; }
	public function get_title() { return 'Новини – заглавие върху снимка'; }
	public function get_icon() { return 'eicon-posts-masonry'; }
	public function get_categories() { return [ 'enc-newsroom' ]; }
	public function get_keywords() { return [ 'news', 'новини', 'posts', 'overlay', 'снимка', 'прегледи' ]; }
	public function get_style_depends() { return [ 'enc-news-hero' ]; }

	private function get_term_options() {
		$out   = [];
		$terms = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	private function get_post_type_options() {
		$out = [];
		foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) {
			if ( 'attachment' !== $pt->name ) {
				$out[ $pt->name ] = $pt->labels->singular_name;
			}
		}
		return $out;
	}

	protected function register_controls() {

		$sw = function ( $name, $label, $default = 'yes', $extra = [] ) {
			$this->add_control( $name, array_merge( [ 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'default' => $default ], $extra ) );
		};

		/* ---------- Заявка ---------- */
		$this->start_controls_section( 'section_query', [ 'label' => 'Заявка' ] );
		$this->add_control( 'post_type', [
			'label' => 'Тип съдържание', 'type' => Controls_Manager::SELECT,
			'options' => $this->get_post_type_options(), 'default' => 'post',
		] );
		$this->add_control( 'categories', [
			'label' => 'Категории', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => $this->get_term_options(), 'condition' => [ 'post_type' => 'post' ],
		] );
		$this->add_control( 'posts_per_page', [ 'label' => 'Брой новини', 'type' => Controls_Manager::NUMBER, 'default' => 6, 'min' => 1, 'max' => 24 ] );
		$this->add_control( 'offset', [ 'label' => 'Пропусни първите', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0 ] );
		$this->add_control( 'orderby', [
			'label' => 'Подредба по', 'type' => Controls_Manager::SELECT, 'default' => 'date',
			'options' => [
				'date' => 'Дата', 'views' => 'Прегледи (най-четени)', 'comment_count' => 'Коментари',
				'title' => 'Заглавие', 'modified' => 'Последна промяна', 'rand' => 'Случайно',
			],
		] );
		$this->add_control( 'order', [
			'label' => 'Посока', 'type' => Controls_Manager::SELECT, 'default' => 'DESC',
			'options' => [ 'DESC' => 'Низходящо (най-новите/най-четените първо)', 'ASC' => 'Възходящо' ],
		] );
		$this->add_control( 'days', [
			'label' => 'Само от последните N дни', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0,
			'description' => '0 = без ограничение. Полезно за „Най-четени тази седмица“ (7).',
		] );
		$sw( 'only_pinned', 'Само закачените (водещи) новини', '', [
			'description' => 'Показва само новините, отбелязани като „Закачена (водеща)“ в редактора на статията. Най-скоро закачената е първа. Ако няма закачени, уиджетът остава празен.',
		] );
		$sw( 'exclude_current', 'Без текущата статия' );
		$this->end_controls_section();

		/* ---------- Елементи ---------- */
		$this->start_controls_section( 'section_content', [ 'label' => 'Елементи' ] );
		$this->add_control( 'image_size', [
			'label' => 'Размер на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'large',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
		] );
		$this->add_control( 'title_tag', [
			'label' => 'HTML таг на заглавието', 'type' => Controls_Manager::SELECT, 'default' => 'h3',
			'options' => [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'div' => 'div' ],
		] );
		$sw( 'featured_first', 'Голяма водеща първа новина', '', [ 'description' => 'Най-добре при 3 или 4 колони. Работи на широки екрани.' ] );
		$sw( 'show_category', 'Етикет на категорията върху снимката', '' );
		$sw( 'show_excerpt', 'Откъс', '' );
		$this->add_control( 'excerpt_length', [
			'label' => 'Думи в откъса', 'type' => Controls_Manager::NUMBER, 'default' => 18, 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_control( 'show_fmt_icon', [ 'label' => 'Икона според формата на публикацията', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'fmt_icons', [
			'label' => 'За кои формати', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => enc_format_labels(), 'default' => [ 'gallery', 'video', 'audio' ], 'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->add_control( 'fmt_icon_pos', [
			'label' => 'Позиция на иконата', 'type' => Controls_Manager::SELECT, 'default' => 'tr',
			'options' => [
				'tr' => 'Горе вдясно (върху снимката)', 'tl' => 'Горе вляво', 'br' => 'Долу вдясно', 'bl' => 'Долу вляво',
				'center' => 'В центъра (голяма)', 'meta' => 'В реда с датата',
			],
			'description' => 'Ако новината няма снимка, иконата се показва в реда с датата.',
			'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$sw( 'zoom', 'Увеличаване на снимката при посочване' );
		$this->end_controls_section();

		/* ---------- Редът под заглавието ---------- */
		$this->start_controls_section( 'section_meta', [ 'label' => 'Дата и прегледи' ] );
		$sw( 'show_meta_icon', 'Икона в началото' );
		$this->add_control( 'meta_icon', [
			'label' => 'Собствена икона', 'type' => Controls_Manager::ICONS, 'skin' => 'inline', 'label_block' => false,
			'condition' => [ 'show_meta_icon' => 'yes' ],
		] );
		$this->add_control( 'meta_label', [
			'label' => 'Удебелен етикет в началото', 'type' => Controls_Manager::SELECT, 'default' => 'category',
			'options' => [ 'category' => 'Категория', 'day' => '„Днес“ / „Вчера“', 'none' => 'Без етикет' ],
		] );
		$sw( 'meta_label_link', 'Категорията е линк', 'yes', [ 'condition' => [ 'meta_label' => 'category' ] ] );
		$sw( 'show_time', 'Час' );
		$this->add_control( 'time_format', [
			'label' => 'Формат на часа', 'type' => Controls_Manager::TEXT, 'default' => 'H:i', 'condition' => [ 'show_time' => 'yes' ],
		] );
		$sw( 'show_date', 'Дата' );
		$this->add_control( 'date_format', [
			'label' => 'Формат на датата', 'type' => Controls_Manager::TEXT, 'default' => 'd.m.y', 'condition' => [ 'show_date' => 'yes' ],
		] );
		$this->add_control( 'meta_sep', [
			'label' => 'Разделител между час и дата', 'type' => Controls_Manager::TEXT, 'default' => '|',
			'condition' => [ 'show_time' => 'yes', 'show_date' => 'yes' ],
		] );
		$sw( 'show_views', 'Брой прегледи' );
		$this->add_control( 'views_key', [
			'label' => 'Мета ключ за прегледите', 'type' => Controls_Manager::TEXT, 'default' => 'enc_views',
			'description' => 'Вграденият брояч ползва enc_views. Ако имате друг плъгин за прегледи, въведете неговия ключ.',
			'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: решетка и карта ---------- */
		$this->start_controls_section( 'style_layout', [ 'label' => 'Решетка и карта', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'columns', [
			'label' => 'Колони', 'type' => Controls_Manager::SELECT,
			'default' => '3', 'tablet_default' => '2', 'mobile_default' => '1',
			'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-grid' => 'grid-template-columns: repeat({{VALUE}}, minmax(0, 1fr));' ],
		] );
		$this->add_responsive_control( 'gap', [
			'label' => 'Разстояние', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 80 ] ], 'default' => [ 'size' => 20, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-grid' => 'gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'ratio', [
			'label' => 'Пропорция на картата', 'type' => Controls_Manager::SELECT, 'default' => '16 / 9',
			'options' => [ '21 / 9' => '21:9', '16 / 9' => '16:9', '16 / 10' => '16:10', '3 / 2' => '3:2', '4 / 3' => '4:3', '1 / 1' => '1:1', '4 / 5' => '4:5' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-card' => 'aspect-ratio: {{VALUE}};' ],
		] );
		$this->add_control( 'radius', [
			'label' => 'Радиус на ъглите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 6, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-card' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'card_bg', [
			'label' => 'Фон (когато няма снимка)', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-hero-card' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'no_shadow', [
			'label' => 'Без сянка', 'type' => Controls_Manager::SWITCHER, 'default' => '',
			'description' => 'Изключва сянката около картата (и при посочване).',
			'selectors' => [ '{{WRAPPER}} .enc-hero-grid .enc-hero-card' => 'box-shadow: none;' ],
		] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name' => 'card_shadow', 'selector' => '{{WRAPPER}} .enc-hero-card',
		] );
		$this->add_responsive_control( 'featured_title_size', [
			'label' => 'Размер на заглавието на водещата', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 16, 'max' => 64 ] ],
			'selectors' => [ '{{WRAPPER}} .enc-hero--featured .enc-hero-card:first-child .enc-hero-title' => 'font-size: {{SIZE}}{{UNIT}};' ],
			'condition' => [ 'featured_first' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: затъмнение ---------- */
		$this->start_controls_section( 'style_overlay', [ 'label' => 'Затъмнение върху снимката', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name'     => 'overlay_bg',
			'types'    => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .enc-hero-card__overlay',
			'fields_options' => [
				'background'     => [ 'default' => 'gradient' ],
				'color'          => [ 'default' => 'rgba(0,0,0,0.88)' ],
				'color_stop'     => [ 'default' => [ 'unit' => '%', 'size' => 0 ] ],
				'color_b'        => [ 'default' => 'rgba(0,0,0,0)' ],
				'color_b_stop'   => [ 'default' => [ 'unit' => '%', 'size' => 75 ] ],
				'gradient_angle' => [ 'default' => [ 'unit' => 'deg', 'size' => 0 ] ],
			],
		] );
		$this->add_control( 'overlay_hover_opacity', [
			'label' => 'Прозрачност на затъмнението', 'type' => Controls_Manager::SLIDER,
			'range' => [ 'px' => [ 'min' => 0, 'max' => 1, 'step' => 0.05 ] ], 'default' => [ 'size' => 1 ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-card__overlay' => 'opacity: {{SIZE}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: заглавие ---------- */
		$this->start_controls_section( 'style_title', [ 'label' => 'Заглавие', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'title_color', [
			'label' => 'Цвят', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-hero-title' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'title_hover_color', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-hero-card:hover .enc-hero-title' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'title_typo', 'selector' => '{{WRAPPER}} .enc-hero-title',
		] );
		$this->add_group_control( Group_Control_Text_Shadow::get_type(), [
			'name' => 'title_shadow', 'selector' => '{{WRAPPER}} .enc-hero-title',
		] );
		$this->add_control( 'title_lines', [
			'label' => 'Максимум редове', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 8,
			'selectors' => [ '{{WRAPPER}} .enc-hero-title' => '-webkit-line-clamp: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'body_padding', [
			'label' => 'Вътрешен отстъп на текста', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-card__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_control( 'excerpt_color', [
			'label' => 'Цвят на откъса', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-hero-excerpt' => 'color: {{VALUE}};' ], 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'excerpt_typo', 'selector' => '{{WRAPPER}} .enc-hero-excerpt', 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: дата и прегледи ---------- */
		$this->start_controls_section( 'style_meta', [ 'label' => 'Дата и прегледи', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'meta_color', [
			'label' => 'Цвят на текста', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-hero-meta' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'meta_typo', 'selector' => '{{WRAPPER}} .enc-hero-meta',
		] );
		$this->add_control( 'day_color', [
			'label' => 'Цвят на етикета (категорията)', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-hero-meta__label' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'day_typo', 'selector' => '{{WRAPPER}} .enc-hero-meta__label',
		] );
		$this->add_control( 'icon_color', [
			'label' => 'Цвят на иконите', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-hero-meta svg, {{WRAPPER}} .enc-hero-meta i' => 'color: {{VALUE}}; fill: none;' ],
		] );
		$this->add_control( 'icon_size', [
			'label' => 'Размер на иконите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 32 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-meta svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};', '{{WRAPPER}} .enc-hero-meta i' => 'font-size: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'meta_gap', [
			'label' => 'Разстояние между елементите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 12, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-meta' => 'column-gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'meta_top', [
			'label' => 'Отстояние от заглавието', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 12, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-meta' => 'margin-top: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: етикет ---------- */
		$this->start_controls_section( 'style_fmt', [ 'label' => 'Икона на формата', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_fmt_icon' => 'yes' ] ] );
		$this->add_control( 'fmt_color', [
			'label' => 'Цвят на иконата', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_bg', [
			'label' => 'Фон на кръга (върху снимката)', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_size', [
			'label' => 'Размер на кръга', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 20, 'max' => 80 ] ], 'default' => [ 'size' => 30, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov:not(.enc-fmt--center)' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'fmt_icon_size', [
			'label' => 'Размер на иконата', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 40 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt:not(.enc-fmt--center) svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'style_badge', [ 'label' => 'Етикет на категорията', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_category' => 'yes' ] ] );
		$this->add_control( 'badge_bg', [
			'label' => 'Фон', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-hero-badge' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'badge_color', [
			'label' => 'Цвят на текста', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-hero-badge' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'badge_typo', 'selector' => '{{WRAPPER}} .enc-hero-badge',
		] );
		$this->add_control( 'badge_radius', [
			'label' => 'Радиус', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ],
			'selectors' => [ '{{WRAPPER}} .enc-hero-badge' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	protected function render() {
		$s         = $this->get_settings_for_display();
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $s['posts_per_page'] ),
			'offset'              => (int) $s['offset'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
		];

		if ( 'views' === $s['orderby'] ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
				[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
			];
			$args['orderby'] = [ 'enc_v' => $s['order'], 'date' => 'DESC' ];
		} else {
			$args['orderby'] = $s['orderby'];
		}

		if ( 'yes' === $s['only_pinned'] ) {
			$args['meta_query'] = [ [ 'key' => 'enc_pinned', 'value' => 0, 'type' => 'NUMERIC', 'compare' => '>' ] ];
			$args['meta_key']   = 'enc_pinned';
			$args['orderby']    = 'meta_value_num';
			$args['order']      = 'DESC';
		}
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( (int) $s['days'] > 0 ) {
			$args['date_query'] = [ [ 'after' => (int) $s['days'] . ' days ago' ] ];
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$q = new WP_Query( $args );
		if ( ! $q->have_posts() ) {
			echo '<div class="enc-hero-empty">Няма намерени новини.</div>';
			return;
		}

		$tag     = in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $s['title_tag'] : 'h3';
		$today   = wp_date( 'Y-m-d' );
		$yester  = wp_date( 'Y-m-d', time() - DAY_IN_SECONDS );
		$classes = 'enc-hero-grid';
		if ( 'yes' === $s['zoom'] ) {
			$classes .= ' enc-hero--zoom';
		}
		if ( 'yes' === $s['featured_first'] ) {
			$classes .= ' enc-hero--featured';
		}

		$icon_news = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h13a1 1 0 0 1 1 1v12a2 2 0 0 0 2 2H6a2 2 0 0 1-2-2V5Z"/><path d="M18 9h2a1 1 0 0 1 1 1v8a2 2 0 0 1-2 2"/><path d="M8 9h6M8 13h6M8 17h4"/></svg>';
		$icon_eye  = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>';

		echo '<div class="' . esc_attr( $classes ) . '">';

		while ( $q->have_posts() ) {
			$q->the_post();
			$id    = get_the_ID();
			$link  = get_permalink();
			$title = get_the_title();

			// Дата / час
			$label     = '';
			$label_url = '';
			if ( 'category' === $s['meta_label'] ) {
				$t = $this->get_primary_term( $id, $post_type );
				if ( $t ) {
					$label = $t->name;
					if ( 'yes' === $s['meta_label_link'] ) {
						$u = get_term_link( $t );
						$label_url = is_wp_error( $u ) ? '' : $u;
					}
				}
			} elseif ( 'day' === $s['meta_label'] ) {
				$pd = get_the_date( 'Y-m-d', $id );
				if ( $pd === $today ) {
					$label = 'Днес';
				} elseif ( $pd === $yester ) {
					$label = 'Вчера';
				}
			}
			$parts = [];
			if ( 'yes' === $s['show_time'] ) {
				$parts[] = get_the_time( $s['time_format'] ?: 'H:i', $id );
			}
			if ( 'yes' === $s['show_date'] ) {
				$parts[] = get_the_date( $s['date_format'] ?: 'd.m.y', $id );
			}
			$sep      = trim( (string) $s['meta_sep'] );
			$time_str = implode( $sep ? ' ' . $sep . ' ' : ' ', $parts );
			$views    = ( 'yes' === $s['show_views'] ) ? (int) get_post_meta( $id, $views_key, true ) : null;

			$has_icon = 'yes' === $s['show_meta_icon'];
			$has_meta = $has_icon || $label || $time_str || null !== $views || $fmt['inline'];

			$cat = null;
			if ( 'yes' === $s['show_category'] && 'post' === get_post_type( $id ) ) {
				$cats = get_the_category( $id );
				$cat  = $cats ? $cats[0] : null;
			}
			$fmt = enc_format_icons( $id, $s, true );
			?>
			<article class="enc-hero-card">
				<div class="enc-hero-card__media">
					<?php if ( has_post_thumbnail() ) {
						echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] );
					} ?>
				</div>
				<span class="enc-hero-card__overlay"></span>
				<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<a class="enc-hero-card__cover" href="<?php echo esc_url( $link ); ?>" aria-hidden="true" tabindex="-1"></a>

				<?php if ( $cat ) : ?>
					<span class="enc-hero-badge"><?php echo esc_html( $cat->name ); ?></span>
				<?php endif; ?>

				<div class="enc-hero-card__body">
					<<?php echo esc_attr( $tag ); ?> class="enc-hero-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>

					<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
						<p class="enc-hero-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
					<?php endif; ?>

					<?php if ( $has_meta ) : ?>
						<div class="enc-hero-meta">
							<?php echo $fmt['inline']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<?php if ( $has_icon ) : ?>
								<span class="enc-hero-meta__icon"><?php
									if ( ! empty( $s['meta_icon']['value'] ) ) {
										\Elementor\Icons_Manager::render_icon( $s['meta_icon'], [ 'aria-hidden' => 'true' ] );
									} else {
										echo $icon_news; // phpcs:ignore WordPress.Security.EscapeOutput
									}
								?></span>
							<?php endif; ?>
							<?php if ( $label ) :
								if ( $label_url ) : ?><a class="enc-hero-meta__label" href="<?php echo esc_url( $label_url ); ?>"><?php echo esc_html( $label ); ?></a><?php
								else : ?><strong class="enc-hero-meta__label"><?php echo esc_html( $label ); ?></strong><?php
								endif;
							endif; ?>
							<?php if ( $time_str ) : ?><time class="enc-hero-meta__time" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $time_str ); ?></time><?php endif; ?>
							<?php if ( null !== $views ) : ?>
								<span class="enc-hero-meta__views"><?php echo $icon_eye; // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $views ); ?></span></span>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</article>
			<?php
		}
		echo '</div>';
		wp_reset_postdata();
	}
}
