<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

class ENC_Most_Read_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'enc_most_read'; }
	public function get_title() { return 'Най-четени'; }
	public function get_icon() { return 'eicon-counter'; }
	public function get_categories() { return [ 'enc-newsroom' ]; }
	public function get_keywords() { return [ 'most read', 'най-четени', 'popular', 'топ', 'прегледи', 'класация' ]; }
	public function get_style_depends() { return [ 'enc-news-top' ]; }
	public function get_script_depends() { return [ 'enc-single' ]; }

	private function get_term_options() {
		$out   = [];
		$terms = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	private function get_post_type_options() {
		$out = [];
		foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) {
			if ( 'attachment' !== $pt->name ) {
				$out[ $pt->name ] = $pt->labels->singular_name;
			}
		}
		return $out;
	}

	protected function register_controls() {
		$terms = $this->get_term_options();
		$sw    = function ( $name, $label, $default = 'yes', $extra = [] ) {
			$this->add_control( $name, array_merge( [ 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'default' => $default ], $extra ) );
		};

		/* ---------- Заявка и период ---------- */
		$this->start_controls_section( 'section_query', [ 'label' => 'Период и заявка' ] );
		$this->add_control( 'period', [
			'label' => 'Най-четени за', 'type' => Controls_Manager::SELECT, 'default' => 'week',
			'options' => [
				'day'    => 'Последния ден (24 часа)',
				'week'   => 'Последните 7 дни',
				'month'  => 'Последните 30 дни',
				'custom' => 'Друг брой дни',
				'all'    => 'За всички времена',
			],
			'description' => 'Класира по прегледите, натрупани в избрания период (от брояча на плъгина).',
		] );
		$this->add_control( 'custom_days', [
			'label' => 'Брой дни', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 30,
			'condition' => [ 'period' => 'custom' ],
		] );
		$sw( 'fallback', 'Допълни, ако няма достатъчно данни за периода', 'yes', [
			'description' => 'Свободните места се попълват първо със статии, публикувани в периода, а после по-стари, подредени по общ брой прегледи.',
			'condition'   => [ 'period!' => 'all' ],
		] );
		$this->add_control( 'post_type', [
			'label' => 'Тип съдържание', 'type' => Controls_Manager::SELECT,
			'options' => $this->get_post_type_options(), 'default' => 'post', 'separator' => 'before',
		] );
		$this->add_control( 'categories', [
			'label' => 'Категории', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => $terms, 'condition' => [ 'post_type' => 'post' ],
		] );
		$this->add_control( 'posts_per_page', [ 'label' => 'Брой новини', 'type' => Controls_Manager::NUMBER, 'default' => 5, 'min' => 1, 'max' => 30 ] );
		$this->add_control( 'offset', [
			'label' => 'Пропусни първите', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0,
			'description' => 'Номерацията продължава оттам (при 5 започва от 06), удобно за две колони един до друг.',
		] );
		$sw( 'exclude_current', 'Без текущата статия' );
		$this->end_controls_section();

		/* ---------- Елементи ---------- */
		$this->start_controls_section( 'section_content', [ 'label' => 'Елементи' ] );
		$sw( 'show_numbers', 'Номера (01, 02, 03…)' );
		$sw( 'pad_numbers', 'Водеща нула (01 вместо 1)', 'yes', [ 'condition' => [ 'show_numbers' => 'yes' ] ] );
		$this->add_control( 'image_mode', [
			'label' => 'Снимки', 'type' => Controls_Manager::SELECT, 'default' => 'none', 'separator' => 'before',
			'options' => [ 'none' => 'Без снимки', 'all' => 'При всички новини', 'first' => 'Само при първите N' ],
		] );
		$this->add_control( 'image_count', [
			'label' => 'При колко от първите новини', 'type' => Controls_Manager::NUMBER, 'default' => 1, 'min' => 1,
			'condition' => [ 'image_mode' => 'first' ],
		] );
		$this->add_control( 'image_pos', [
			'label' => 'Позиция на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'left',
			'options' => [ 'left' => 'Отляво (след номера)', 'right' => 'Отдясно' ], 'condition' => [ 'image_mode!' => 'none' ],
		] );
		$this->add_control( 'image_size', [
			'label' => 'Размер на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'medium',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
			'condition' => [ 'image_mode!' => 'none' ],
		] );
		$this->add_control( 'title_tag', [
			'label' => 'HTML таг на заглавието', 'type' => Controls_Manager::SELECT, 'default' => 'h3',
			'options' => [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'div' => 'div' ], 'separator' => 'before',
		] );
		$sw( 'show_excerpt', 'Откъс', '' );
		$this->add_control( 'excerpt_length', [
			'label' => 'Думи в откъса', 'type' => Controls_Manager::NUMBER, 'default' => 18, 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$sw( 'show_share', 'Бутон „Сподели“', '' );
		$this->add_control( 'show_fmt_icon', [ 'label' => 'Икона според формата на публикацията', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'fmt_icons', [
			'label' => 'За кои формати', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => enc_format_labels(), 'default' => [ 'gallery', 'video', 'audio' ], 'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->add_control( 'fmt_icon_pos', [
			'label' => 'Позиция на иконата', 'type' => Controls_Manager::SELECT, 'default' => 'meta',
			'options' => [
				'tr' => 'Горе вдясно (върху снимката)', 'tl' => 'Горе вляво', 'br' => 'Долу вдясно', 'bl' => 'Долу вляво',
				'center' => 'В центъра (голяма)', 'meta' => 'В реда с датата',
			],
			'description' => 'Ако новината няма снимка, иконата се показва в реда с датата.',
			'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Ред с категория, дата и прегледи ---------- */
		$this->start_controls_section( 'section_meta', [ 'label' => 'Категория, дата и прегледи' ] );
		$sw( 'show_meta_icon', 'Икона в началото', '' );
		$this->add_control( 'meta_icon', [
			'label' => 'Собствена икона', 'type' => Controls_Manager::ICONS, 'skin' => 'inline', 'label_block' => false,
			'condition' => [ 'show_meta_icon' => 'yes' ],
		] );
		$this->add_control( 'meta_label', [
			'label' => 'Удебелен етикет в началото', 'type' => Controls_Manager::SELECT, 'default' => 'none',
			'options' => [ 'none' => 'Без етикет', 'category' => 'Категория', 'day' => '„Днес“ / „Вчера“' ],
		] );
		$sw( 'meta_label_link', 'Категорията е линк', 'yes', [ 'condition' => [ 'meta_label' => 'category' ] ] );
		$sw( 'show_time', 'Час', '' );
		$this->add_control( 'time_format', [
			'label' => 'Формат на часа', 'type' => Controls_Manager::TEXT, 'default' => 'H:i', 'condition' => [ 'show_time' => 'yes' ],
		] );
		$sw( 'show_date', 'Дата' );
		$this->add_control( 'date_format', [
			'label' => 'Формат на датата', 'type' => Controls_Manager::TEXT, 'default' => 'j M. Y', 'condition' => [ 'show_date' => 'yes' ],
		] );
		$this->add_control( 'meta_sep', [
			'label' => 'Разделител между час и дата', 'type' => Controls_Manager::TEXT, 'default' => '|',
			'condition' => [ 'show_time' => 'yes', 'show_date' => 'yes' ],
		] );
		$sw( 'show_views', 'Брой прегледи (общо)', '' );
		$this->add_control( 'views_key', [
			'label' => 'Мета ключ за прегледите', 'type' => Controls_Manager::TEXT, 'default' => 'enc_views',
			'description' => 'Вграденият брояч ползва enc_views.', 'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Цветове по категория ---------- */
		$this->start_controls_section( 'section_cat_colors', [ 'label' => 'Цветове на категориите' ] );
		$rep = new Repeater();
		$rep->add_control( 'term', [ 'label' => 'Категория', 'type' => Controls_Manager::SELECT2, 'options' => $terms, 'label_block' => true ] );
		$rep->add_control( 'color', [ 'label' => 'Цвят', 'type' => Controls_Manager::COLOR, 'default' => '#f07a10' ] );
		$this->add_control( 'cat_colors', [
			'label' => 'Цвят по категория', 'type' => Controls_Manager::REPEATER, 'fields' => $rep->get_controls(),
			'title_field' => '{{{ color }}}',
			'description' => 'Важи, когато етикетът е „Категория“. Без зададен цвят се ползва общият цвят на етикета.',
		] );
		$this->end_controls_section();

		/* ---------- Стил: карта ---------- */
		$this->start_controls_section( 'style_panel', [ 'label' => 'Карта и редове', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'panel_bg', [
			'label' => 'Фон', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-panel' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'panel_padding', [
			'label' => 'Вътрешен отстъп на картата', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-panel' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_control( 'panel_radius', [
			'label' => 'Радиус на ъглите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 30 ] ], 'default' => [ 'size' => 4, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-panel' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'no_shadow', [
			'label' => 'Без сянка', 'type' => Controls_Manager::SWITCHER, 'default' => '',
			'description' => 'Изключва сянката около картата (и при посочване).',
			'selectors' => [ '{{WRAPPER}} .enc-top .enc-top-panel' => 'box-shadow: none;' ],
		] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name' => 'panel_shadow', 'selector' => '{{WRAPPER}} .enc-top-panel',
		] );
		$this->add_responsive_control( 'item_padding', [
			'label' => 'Вътрешен отстъп на реда', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ], 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-top-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_control( 'sep_color', [
			'label' => 'Цвят на разделителните линии', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-item' => 'border-bottom-color: {{VALUE}};' ],
		] );
		$this->add_control( 'sep_width', [
			'label' => 'Дебелина на линиите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 6 ] ], 'default' => [ 'size' => 1, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-item:not(:last-child)' => 'border-bottom-width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: номера ---------- */
		$this->start_controls_section( 'style_num', [ 'label' => 'Номера', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_numbers' => 'yes' ] ] );
		$this->add_control( 'num_color', [
			'label' => 'Цвят', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-num' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'num_typo', 'selector' => '{{WRAPPER}} .enc-top-num',
		] );
		$this->add_responsive_control( 'num_width', [
			'label' => 'Минимална ширина на колоната', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 20, 'max' => 120 ] ], 'default' => [ 'size' => 44, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-num' => 'min-width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'num_gap', [
			'label' => 'Разстояние до заглавието', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 60 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-num' => 'margin-right: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'num_align', [
			'label' => 'Вертикално подравняване', 'type' => Controls_Manager::SELECT, 'default' => 'center',
			'options' => [ 'center' => 'По средата на заглавието', 'start' => 'Най-горе' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-num' => 'align-self: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: заглавие ---------- */
		$this->start_controls_section( 'style_title', [ 'label' => 'Заглавие', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'title_color', [
			'label' => 'Цвят', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-title' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'title_hover_color', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-title a:hover' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'title_typo', 'selector' => '{{WRAPPER}} .enc-top-title',
		] );
		$this->add_control( 'title_lines', [
			'label' => 'Максимум редове', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 8,
			'selectors' => [ '{{WRAPPER}} .enc-top-title' => '-webkit-line-clamp: {{VALUE}};' ],
		] );
		$this->add_control( 'excerpt_color', [
			'label' => 'Цвят на откъса', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-top-excerpt' => 'color: {{VALUE}};' ], 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'excerpt_typo', 'selector' => '{{WRAPPER}} .enc-top-excerpt', 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: дата, категория, прегледи ---------- */
		$this->start_controls_section( 'style_meta', [ 'label' => 'Дата, категория и прегледи', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'meta_color', [
			'label' => 'Цвят на датата и прегледите', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-meta' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'meta_typo', 'selector' => '{{WRAPPER}} .enc-top-meta__time, {{WRAPPER}} .enc-top-meta__views',
		] );
		$this->add_control( 'label_color', [
			'label' => 'Общ цвят на етикета (категорията)', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-top-meta__label' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'label_typo', 'selector' => '{{WRAPPER}} .enc-top-meta__label',
		] );
		$this->add_control( 'icon_size', [
			'label' => 'Размер на иконите (око и др.)', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 32 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-meta__icon svg, {{WRAPPER}} .enc-top-meta__views svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};', '{{WRAPPER}} .enc-top-meta i' => 'font-size: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'meta_gap', [
			'label' => 'Разстояние между елементите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 14, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-meta' => 'column-gap: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'meta_top', [
			'label' => 'Отстояние от заглавието', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 10, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-meta' => 'margin-top: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: снимка ---------- */
		$this->start_controls_section( 'style_thumb', [ 'label' => 'Снимка', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'image_mode!' => 'none' ] ] );
		$this->add_responsive_control( 'thumb_width', [
			'label' => 'Ширина', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 50, 'max' => 300 ] ], 'default' => [ 'size' => 96, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-item__media' => 'width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'thumb_ratio', [
			'label' => 'Пропорция', 'type' => Controls_Manager::SELECT, 'default' => '3 / 2',
			'options' => [ '16 / 9' => '16:9', '3 / 2' => '3:2', '4 / 3' => '4:3', '1 / 1' => '1:1' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-item__media' => 'aspect-ratio: {{VALUE}};' ],
		] );
		$this->add_control( 'thumb_radius', [
			'label' => 'Радиус', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 30 ] ],
			'selectors' => [ '{{WRAPPER}} .enc-top-item__media' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: икона на формата ---------- */
		$this->start_controls_section( 'style_fmt', [ 'label' => 'Икона на формата', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_fmt_icon' => 'yes' ] ] );
		$this->add_control( 'fmt_color', [
			'label' => 'Цвят на иконата', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_bg', [
			'label' => 'Фон на кръга (върху снимката)', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_size', [
			'label' => 'Размер на кръга', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 20, 'max' => 80 ] ], 'default' => [ 'size' => 30, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov:not(.enc-fmt--center)' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'fmt_icon_size', [
			'label' => 'Размер на иконата', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 40 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt:not(.enc-fmt--center) svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: „Сподели“ ---------- */
		$this->start_controls_section( 'style_share', [ 'label' => 'Бутон „Сподели“', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_share' => 'yes' ] ] );
		$this->add_control( 'share_color', [
			'label' => 'Цвят', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-share' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'share_hover', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-top-share:hover' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'share_size', [
			'label' => 'Размер', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 32 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-top-share svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	/** Подрежда ID-тата: първо по прегледи за периода, после (по избор) допълва по общ брой прегледи. */
	private function ranked_ids( $s, $post_type, $views_key ) {
		$count  = max( 1, (int) $s['posts_per_page'] );
		$offset = max( 0, (int) $s['offset'] );
		$need   = $count + $offset;

		switch ( $s['period'] ) {
			case 'day':
				$hours = 24;
				break;
			case 'week':
				$hours = 168;
				break;
			case 'month':
				$hours = 720;
				break;
			case 'custom':
				$hours = max( 1, (int) $s['custom_days'] ) * 24;
				break;
			default:
				$hours = 0;
		}

		$base = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'fields'              => 'ids',
		];
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$base['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		$exclude = ( 'yes' === $s['exclude_current'] && is_singular() ) ? [ get_the_ID() ] : [];

		$ids = [];

		// 1) Прегледи през избрания период (от почасовата таблица)
		if ( $hours > 0 ) {
			$cand = enc_period_top_ids( $hours );
			if ( $cand ) {
				$args = array_merge( $base, [ 'post__in' => $cand, 'orderby' => 'post__in', 'posts_per_page' => $need ] );
				if ( $exclude ) {
					$args['post__not_in'] = $exclude;
				}
				$q   = new WP_Query( $args );
				$ids = array_map( 'intval', $q->posts );
			}
		}

		// 2) Допълване по общ брой прегледи
		if ( count( $ids ) < $need && ( 0 === $hours || 'yes' === $s['fallback'] ) ) {
			$by_total = [
				'meta_query' => [
					'relation' => 'OR',
					'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
					[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
				],
				'orderby'    => [ 'enc_v' => 'DESC', 'date' => 'DESC' ],
			];

			if ( $hours > 0 ) {
				$q = new WP_Query( array_merge( $base, $by_total, [
					'post__not_in'   => array_merge( $exclude, $ids ),
					'posts_per_page' => $need - count( $ids ),
					'date_query'     => [ [ 'after' => $hours . ' hours ago' ] ],
				] ) );
				$ids = array_merge( $ids, array_map( 'intval', $q->posts ) );
			}
			if ( count( $ids ) < $need ) {
				$q = new WP_Query( array_merge( $base, $by_total, [
					'post__not_in'   => array_merge( $exclude, $ids ),
					'posts_per_page' => $need - count( $ids ),
				] ) );
				$ids = array_merge( $ids, array_map( 'intval', $q->posts ) );
			}
		}

		return array_slice( $ids, $offset, $count );
	}

	private function item_html( $s, $rank, $index, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();
		$tag   = $c['tag'];

		$has_image = 'none' !== $s['image_mode']
			&& ( 'all' === $s['image_mode'] || $index < max( 1, (int) $s['image_count'] ) )
			&& has_post_thumbnail();
		$fmt = enc_format_icons( $id, $s, $has_image );

		$label = $label_url = $label_style = '';
		if ( 'category' === $s['meta_label'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$label = $t->name;
				if ( 'yes' === $s['meta_label_link'] ) {
					$u         = get_term_link( $t );
					$label_url = is_wp_error( $u ) ? '' : $u;
				}
				if ( isset( $c['colors'][ $t->term_id ] ) ) {
					$label_style = ' style="color:' . esc_attr( $c['colors'][ $t->term_id ] ) . '"';
				}
			}
		} elseif ( 'day' === $s['meta_label'] ) {
			$pd = get_the_date( 'Y-m-d', $id );
			if ( $pd === $c['today'] ) {
				$label = 'Днес';
			} elseif ( $pd === $c['yester'] ) {
				$label = 'Вчера';
			}
		}

		$parts = [];
		if ( 'yes' === $s['show_time'] ) {
			$parts[] = get_the_time( $s['time_format'] ?: 'H:i', $id );
		}
		if ( 'yes' === $s['show_date'] ) {
			$parts[] = get_the_date( $s['date_format'] ?: 'j M. Y', $id );
		}
		$sep       = trim( (string) $s['meta_sep'] );
		$time_str  = implode( $sep ? ' ' . $sep . ' ' : ' ', $parts );
		$views     = ( 'yes' === $s['show_views'] ) ? (int) get_post_meta( $id, $c['views_key'], true ) : null;
		$has_icon  = 'yes' === $s['show_meta_icon'];
		$has_share = 'yes' === $s['show_share'];
		$has_meta  = $has_icon || $label || $time_str || null !== $views || $has_share || $fmt['inline'];

		$num = ( 'yes' === $s['pad_numbers'] ) ? str_pad( (string) $rank, 2, '0', STR_PAD_LEFT ) : (string) $rank;
		$cls = 'enc-top-item';
		if ( 'yes' !== $s['show_numbers'] ) {
			$cls .= ' enc-top-item--nonum';
		}
		if ( $has_image ) {
			$cls .= ( 'right' === $s['image_pos'] ) ? ' enc-top-item--img-r' : ' enc-top-item--img-l';
		}

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( 'yes' === $s['show_numbers'] ) : ?><span class="enc-top-num"><?php echo esc_html( $num ); ?></span><?php endif; ?>

			<?php if ( $has_image ) : ?>
				<a class="enc-top-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>

			<div class="enc-top-item__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-top-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>

				<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
					<p class="enc-top-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
				<?php endif; ?>

				<?php if ( $has_meta ) : ?>
					<div class="enc-top-meta">
						<?php echo $fmt['inline']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( $has_icon ) : ?>
							<span class="enc-top-meta__icon"><?php
								if ( ! empty( $s['meta_icon']['value'] ) ) {
									\Elementor\Icons_Manager::render_icon( $s['meta_icon'], [ 'aria-hidden' => 'true' ] );
								} else {
									echo $c['icon_news']; // phpcs:ignore WordPress.Security.EscapeOutput
								}
							?></span>
						<?php endif; ?>

						<?php if ( $label ) :
							if ( $label_url ) : ?><a class="enc-top-meta__label" href="<?php echo esc_url( $label_url ); ?>"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></a><?php
							else : ?><strong class="enc-top-meta__label"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></strong><?php
							endif;
						endif; ?>

						<?php if ( $time_str ) : ?><time class="enc-top-meta__time" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $time_str ); ?></time><?php endif; ?>

						<?php if ( null !== $views ) : ?>
							<span class="enc-top-meta__views"><?php echo $c['icon_eye']; // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $views ); ?></span></span>
						<?php endif; ?>

						<?php if ( $has_share ) : ?>
							<button type="button" class="enc-share enc-top-share" aria-label="Сподели"
								data-url="<?php echo esc_url( $link ); ?>" data-title="<?php echo esc_attr( $title ); ?>" data-copied="Линкът е копиран">
								<?php echo $c['icon_share']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
							</button>
						<?php endif; ?>
					</div>
				<?php endif; ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	protected function render() {
		$s         = $this->get_settings_for_display();
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';

		$ids = $this->ranked_ids( $s, $post_type, $views_key );
		if ( ! $ids ) {
			echo '<div class="enc-top-empty">Все още няма данни за най-четените новини.</div>';
			return;
		}

		$q = new WP_Query( [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'post__in'            => $ids,
			'orderby'             => 'post__in',
			'posts_per_page'      => count( $ids ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		] );

		$colors = enc_all_term_colors();
		if ( ! empty( $s['cat_colors'] ) ) {
			foreach ( $s['cat_colors'] as $row ) {
				if ( ! empty( $row['term'] ) && ! empty( $row['color'] ) ) {
					$colors[ (int) $row['term'] ] = $row['color'];
				}
			}
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'colors'     => $colors,
			'tag'        => in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $s['title_tag'] : 'h3',
			'today'      => wp_date( 'Y-m-d' ),
			'yester'     => wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ),
			'icon_news'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h13a1 1 0 0 1 1 1v12a2 2 0 0 0 2 2H6a2 2 0 0 1-2-2V5Z"/><path d="M18 9h2a1 1 0 0 1 1 1v8a2 2 0 0 1-2 2"/><path d="M8 9h6M8 13h6M8 17h4"/></svg>',
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
			'icon_share' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="currentColor"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></g><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
		];

		$start = max( 0, (int) $s['offset'] );
		$items = [];
		$i     = 0;
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = $this->item_html( $s, $start + $i + 1, $i, $ctx );
			$i++;
		}
		wp_reset_postdata();

		echo '<div class="enc-top"><div class="enc-top-panel"><div class="enc-top-items">' . implode( '', $items ) . '</div></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
