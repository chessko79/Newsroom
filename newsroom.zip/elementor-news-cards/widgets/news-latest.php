<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class ENC_Latest_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'enc_latest'; }
	public function get_title() { return 'Последни новини'; }
	public function get_icon() { return 'eicon-slider-push'; }
	public function get_categories() { return [ 'enc-newsroom' ]; }
	public function get_keywords() { return [ 'latest', 'последни', 'новини', 'слайдер', 'преди', 'минути', 'carousel' ]; }
	public function get_style_depends() { return [ 'enc-latest' ]; }
	public function get_script_depends() { return [ 'enc-latest' ]; }

	private function get_term_options() {
		$out   = [];
		$terms = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	private function get_post_type_options() {
		$out = [];
		foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) {
			if ( 'attachment' !== $pt->name ) {
				$out[ $pt->name ] = $pt->labels->singular_name;
			}
		}
		return $out;
	}

	protected function register_controls() {
		$sw = function ( $name, $label, $default = 'yes', $extra = [] ) {
			$this->add_control( $name, array_merge( [ 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'default' => $default ], $extra ) );
		};
		$col = function ( $name, $label, $sel, $prop = 'color', $extra = [] ) {
			$this->add_control( $name, array_merge( [
				'label' => $label, 'type' => Controls_Manager::COLOR,
				'selectors' => [ '{{WRAPPER}} ' . $sel => $prop . ': {{VALUE}};' ],
			], $extra ) );
		};
		$typo = function ( $name, $sel, $extra = [] ) {
			$this->add_group_control( Group_Control_Typography::get_type(), array_merge( [ 'name' => $name, 'selector' => '{{WRAPPER}} ' . $sel ], $extra ) );
		};
		$px = function ( $name, $label, $sel, $prop, $min, $max, $def, $extra = [] ) {
			$this->add_control( $name, array_merge( [
				'label' => $label, 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
				'range' => [ 'px' => [ 'min' => $min, 'max' => $max ] ], 'default' => [ 'size' => $def, 'unit' => 'px' ],
				'selectors' => [ '{{WRAPPER}} ' . $sel => $prop . ': {{SIZE}}{{UNIT}};' ],
			], $extra ) );
		};

		/* ---------- Заявка ---------- */
		$this->start_controls_section( 'section_query', [ 'label' => 'Заявка' ] );
		$this->add_control( 'post_type', [
			'label' => 'Тип съдържание', 'type' => Controls_Manager::SELECT,
			'options' => $this->get_post_type_options(), 'default' => 'post',
		] );
		$this->add_control( 'categories', [
			'label' => 'Категории', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => $this->get_term_options(), 'condition' => [ 'post_type' => 'post' ],
		] );
		$this->add_control( 'posts_per_page', [ 'label' => 'Брой новини', 'type' => Controls_Manager::NUMBER, 'default' => 10, 'min' => 1, 'max' => 40 ] );
		$this->add_control( 'offset', [ 'label' => 'Пропусни първите', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0 ] );
		$this->add_control( 'orderby', [
			'label' => 'Подредба по', 'type' => Controls_Manager::SELECT, 'default' => 'date',
			'options' => [
				'date' => 'Дата (най-новите)', 'views' => 'Прегледи (най-четени)', 'comment_count' => 'Коментари',
				'modified' => 'Последна промяна', 'title' => 'Заглавие', 'rand' => 'Случайно',
			],
		] );
		$this->add_control( 'order', [
			'label' => 'Посока', 'type' => Controls_Manager::SELECT, 'default' => 'DESC',
			'options' => [ 'DESC' => 'Низходящо', 'ASC' => 'Възходящо' ],
		] );
		$this->add_control( 'days', [
			'label' => 'Само от последните N дни', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0,
			'description' => '0 = без ограничение.',
		] );
		$sw( 'exclude_current', 'Без текущата статия' );
		$this->end_controls_section();

		/* ---------- Подредба и слайдър ---------- */
		$this->start_controls_section( 'section_layout', [ 'label' => 'Подредба и слайдър' ] );
		$this->add_control( 'layout', [
			'label' => 'Подредба', 'type' => Controls_Manager::SELECT, 'default' => 'horizontal',
			'options' => [ 'horizontal' => 'Хоризонтално (колони)', 'vertical' => 'Вертикално (списък)' ],
		] );
		$this->add_responsive_control( 'columns', [
			'label' => 'Колони', 'type' => Controls_Manager::SELECT,
			'default' => '5', 'tablet_default' => '3', 'mobile_default' => '2',
			'options' => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt' => '--cols: {{VALUE}};' ],
			'condition' => [ 'layout' => 'horizontal' ],
		] );
		$this->add_responsive_control( 'gap', [
			'label' => 'Разстояние между колоните', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 80 ] ], 'default' => [ 'size' => 24, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt' => '--gap: {{SIZE}}{{UNIT}};' ],
			'condition' => [ 'layout' => 'horizontal' ],
		] );
		$sw( 'slider', 'Слайдър със стрелки', 'yes', [ 'condition' => [ 'layout' => 'horizontal' ], 'separator' => 'before' ] );
		$this->add_control( 'slide_by', [
			'label' => 'Стрелките превъртат', 'type' => Controls_Manager::SELECT, 'default' => 'one',
			'options' => [ 'one' => 'По една новина', 'page' => 'По цяла страница (всички видими)' ],
			'condition' => [ 'layout' => 'horizontal', 'slider' => 'yes' ],
		] );
		$this->add_control( 'nav_pos', [
			'label' => 'Позиция на стрелките', 'type' => Controls_Manager::SELECT, 'default' => 'bl',
			'options' => [ 'bl' => 'Долу вляво', 'br' => 'Долу вдясно', 'tr' => 'Горе вдясно', 'sides' => 'От двете страни (върху новините)' ],
			'condition' => [ 'layout' => 'horizontal', 'slider' => 'yes' ],
		] );
		$sw( 'autoplay', 'Автоматично превъртане', '', [ 'condition' => [ 'layout' => 'horizontal', 'slider' => 'yes' ] ] );
		$this->add_control( 'autoplay_delay', [
			'label' => 'Секунди между превърташията', 'type' => Controls_Manager::NUMBER, 'default' => 4, 'min' => 1, 'max' => 30,
			'condition' => [ 'layout' => 'horizontal', 'slider' => 'yes', 'autoplay' => 'yes' ],
			'description' => 'Спира при посочване с мишката. Не се включва при потребители с изключени анимации.',
		] );
		$this->end_controls_section();

		/* ---------- Елементи ---------- */
		$this->start_controls_section( 'section_content', [ 'label' => 'Елементи' ] );
		$this->add_control( 'title_tag', [
			'label' => 'HTML таг на заглавието', 'type' => Controls_Manager::SELECT, 'default' => 'h3',
			'options' => [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'h5' => 'H5', 'div' => 'div' ],
		] );
		$this->add_control( 'image_mode', [
			'label' => 'Снимки', 'type' => Controls_Manager::SELECT, 'default' => 'none', 'separator' => 'before',
			'options' => [ 'none' => 'Без снимки', 'all' => 'Със снимки' ],
		] );
		$this->add_control( 'image_pos', [
			'label' => 'Позиция на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'top',
			'options' => [ 'top' => 'Отгоре', 'left' => 'Отляво', 'right' => 'Отдясно' ], 'condition' => [ 'image_mode' => 'all' ],
		] );
		$this->add_control( 'image_size', [
			'label' => 'Размер на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'medium',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
			'condition' => [ 'image_mode' => 'all' ],
		] );
		$this->add_control( 'time_style', [
			'label' => 'Време', 'type' => Controls_Manager::SELECT, 'default' => 'ago', 'separator' => 'before',
			'options' => [
				'ago' => '„преди 6 минути“', 'time' => 'Час (14:14)', 'datetime' => 'Час и дата (14:14 | 15.10.26)',
				'date' => 'Само дата', 'none' => 'Без време',
			],
		] );
		$this->add_control( 'max_days', [
			'label' => 'Показвай датата след (дни)', 'type' => Controls_Manager::NUMBER, 'default' => 7, 'min' => 1, 'max' => 60,
			'description' => 'По-старите новини показват датата вместо „преди N дни“.', 'condition' => [ 'time_style' => 'ago' ],
		] );
		$this->add_control( 'time_format', [
			'label' => 'Формат на часа', 'type' => Controls_Manager::TEXT, 'default' => 'H:i', 'condition' => [ 'time_style' => [ 'time', 'datetime' ] ],
		] );
		$this->add_control( 'date_format', [
			'label' => 'Формат на датата', 'type' => Controls_Manager::TEXT, 'default' => 'd.m.y', 'condition' => [ 'time_style!' => [ 'time', 'none' ] ],
		] );
		$sw( 'show_time_icon', 'Икона на часовник', 'yes', [ 'condition' => [ 'time_style!' => 'none' ] ] );
		$this->add_control( 'time_icon', [
			'label' => 'Собствена икона', 'type' => Controls_Manager::ICONS, 'skin' => 'inline', 'label_block' => false,
			'condition' => [ 'time_style!' => 'none', 'show_time_icon' => 'yes' ],
		] );
		$sw( 'uppercase', 'Времето с ГЛАВНИ БУКВИ', 'yes', [ 'condition' => [ 'time_style' => 'ago' ] ] );
		$sw( 'show_category', 'Категория', '', [ 'separator' => 'before' ] );
		$sw( 'category_link', 'Категорията е линк', 'yes', [ 'condition' => [ 'show_category' => 'yes' ] ] );
		$sw( 'show_views', 'Брой прегледи', '' );
		$this->add_control( 'views_key', [
			'label' => 'Мета ключ за прегледите', 'type' => Controls_Manager::TEXT, 'default' => 'enc_views', 'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->add_control( 'show_fmt_icon', [ 'label' => 'Икона според формата на публикацията', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'fmt_icons', [
			'label' => 'За кои формати', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => enc_format_labels(), 'default' => [ 'gallery', 'video', 'audio' ], 'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->add_control( 'fmt_icon_pos', [
			'label' => 'Позиция на иконата', 'type' => Controls_Manager::SELECT, 'default' => 'meta',
			'options' => [
				'tr' => 'Горе вдясно (върху снимката)', 'tl' => 'Горе вляво', 'br' => 'Долу вдясно', 'bl' => 'Долу вляво',
				'center' => 'В центъра (голяма)', 'meta' => 'В реда с времето',
			],
			'description' => 'Ако новината няма снимка, иконата се показва в реда с времето.',
			'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: общо ---------- */
		$this->start_controls_section( 'style_wrap', [ 'label' => 'Общо', 'tab' => Controls_Manager::TAB_STYLE ] );
		$col( 'wrap_bg', 'Фон', '.enc-lt', 'background-color' );
		$this->add_responsive_control( 'wrap_padding', [
			'label' => 'Вътрешен отстъп', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'item_padding', [
			'label' => 'Отстъп на всеки ред (вертикално)', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt--v .enc-lt-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
			'condition' => [ 'layout' => 'vertical' ],
		] );
		$col( 'sep_color', 'Цвят на разделителните линии (вертикално)', '.enc-lt--v .enc-lt-item', 'border-bottom-color', [ 'condition' => [ 'layout' => 'vertical' ] ] );
		$px( 'sep_width', 'Дебелина на линиите (вертикално)', '.enc-lt--v .enc-lt-item', 'border-bottom-width', 0, 6, 1, [ 'condition' => [ 'layout' => 'vertical' ] ] );
		$this->end_controls_section();

		/* ---------- Стил: заглавие ---------- */
		$this->start_controls_section( 'style_title', [ 'label' => 'Заглавие', 'tab' => Controls_Manager::TAB_STYLE ] );
		$col( 'title_color', 'Цвят', '.enc-lt-title' );
		$col( 'title_hover', 'Цвят при посочване', '.enc-lt-title a:hover' );
		$typo( 'title_typo', '.enc-lt-title' );
		$this->add_control( 'title_lines', [
			'label' => 'Максимум редове', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 8,
			'selectors' => [ '{{WRAPPER}} .enc-lt-title' => '-webkit-line-clamp: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: време и мета ---------- */
		$this->start_controls_section( 'style_time', [ 'label' => 'Време, категория и прегледи', 'tab' => Controls_Manager::TAB_STYLE ] );
		$col( 'time_color', 'Цвят на времето', '.enc-lt-time' );
		$typo( 'time_typo', '.enc-lt-time' );
		$col( 'time_icon_color', 'Цвят на иконата', '.enc-lt-when__icon' );
		$px( 'time_icon_size', 'Размер на иконата', '.enc-lt-when__icon svg', 'width', 8, 28, 13 );
		$col( 'label_color', 'Цвят на категорията', '.enc-lt-label', 'color', [ 'separator' => 'before', 'condition' => [ 'show_category' => 'yes' ] ] );
		$typo( 'label_typo', '.enc-lt-label', [ 'condition' => [ 'show_category' => 'yes' ] ] );
		$col( 'views_color', 'Цвят на прегледите', '.enc-lt-views', 'color', [ 'condition' => [ 'show_views' => 'yes' ] ] );
		$typo( 'views_typo', '.enc-lt-views', [ 'condition' => [ 'show_views' => 'yes' ] ] );
		$px( 'meta_top', 'Отстояние от заглавието', '.enc-lt-meta', 'margin-top', 0, 40, 10, [ 'separator' => 'before' ] );
		$px( 'meta_gap', 'Разстояние между елементите', '.enc-lt-meta', 'column-gap', 0, 40, 12 );
		$this->end_controls_section();

		/* ---------- Стил: стрелки ---------- */
		$this->start_controls_section( 'style_nav', [ 'label' => 'Стрелки', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'layout' => 'horizontal', 'slider' => 'yes' ] ] );
		$px( 'btn_size', 'Размер на бутона', '.enc-lt-btn', 'width', 20, 60, 28 );
		$this->add_control( 'btn_size_h', [
			'label' => 'Височина на бутона', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 20, 'max' => 60 ] ], 'default' => [ 'size' => 28, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt-btn' => 'height: {{SIZE}}{{UNIT}};' ],
		] );
		$px( 'btn_icon', 'Размер на стрелката', '.enc-lt-btn svg', 'width', 8, 30, 14 );
		$col( 'btn_color', 'Цвят на стрелката', '.enc-lt-btn' );
		$col( 'btn_hover_color', 'Цвят при посочване', '.enc-lt-btn:hover' );
		$col( 'btn_bg', 'Фон', '.enc-lt-btn', 'background-color' );
		$col( 'btn_hover_bg', 'Фон при посочване', '.enc-lt-btn:hover', 'background-color' );
		$col( 'btn_border', 'Цвят на контура', '.enc-lt-btn', 'border-color' );
		$px( 'btn_radius', 'Радиус', '.enc-lt-btn', 'border-radius', 0, 30, 2 );
		$px( 'nav_gap', 'Разстояние между бутоните', '.enc-lt-nav', 'gap', 0, 30, 8 );
		$this->add_responsive_control( 'nav_margin', [
			'label' => 'Отстояние от новините', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 60 ] ], 'default' => [ 'size' => 18, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt--nav-bl .enc-lt-nav, {{WRAPPER}} .enc-lt--nav-br .enc-lt-nav' => 'margin-top: {{SIZE}}{{UNIT}};' ],
			'condition' => [ 'nav_pos' => [ 'bl', 'br' ] ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: снимка ---------- */
		$this->start_controls_section( 'style_img', [ 'label' => 'Снимка', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'image_mode' => 'all' ] ] );
		$this->add_responsive_control( 'img_ratio', [
			'label' => 'Пропорция', 'type' => Controls_Manager::SELECT, 'default' => '3 / 2',
			'options' => [ '16 / 9' => '16:9', '3 / 2' => '3:2', '4 / 3' => '4:3', '1 / 1' => '1:1' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt-item__media' => 'aspect-ratio: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'img_width', [
			'label' => 'Ширина (при снимка отляво или отдясно)', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 50, 'max' => 300 ] ], 'default' => [ 'size' => 96, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lt-item--img-left .enc-lt-item__media, {{WRAPPER}} .enc-lt-item--img-right .enc-lt-item__media' => 'width: {{SIZE}}{{UNIT}};' ],
			'condition' => [ 'image_pos!' => 'top' ],
		] );
		$px( 'img_radius', 'Радиус', '.enc-lt-item__media', 'border-radius', 0, 30, 0 );
		$this->end_controls_section();

		/* ---------- Стил: икона на формата ---------- */
		$this->start_controls_section( 'style_fmt', [ 'label' => 'Икона на формата', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_fmt_icon' => 'yes' ] ] );
		$col( 'fmt_color', 'Цвят на иконата', '.enc-fmt' );
		$col( 'fmt_bg', 'Фон на кръга (върху снимката)', '.enc-fmt--ov', 'background-color' );
		$px( 'fmt_size', 'Размер на кръга', '.enc-fmt--ov:not(.enc-fmt--center)', 'width', 20, 80, 30 );
		$px( 'fmt_icon_size', 'Размер на иконата', '.enc-fmt:not(.enc-fmt--center) svg', 'width', 10, 40, 16 );
		$this->end_controls_section();
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	private function item_html( $s, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();
		$tag   = $c['tag'];

		$has_image = 'all' === $s['image_mode'] && has_post_thumbnail();
		$fmt       = enc_format_icons( $id, $s, $has_image );

		// Време
		$when = '';
		if ( 'none' !== $s['time_style'] ) {
			$ts       = (int) get_post_time( 'U', true, $id );
			$date_str = get_the_date( $s['date_format'] ?: 'd.m.y', $id );
			$attrs    = '';
			switch ( $s['time_style'] ) {
				case 'ago':
					$max  = max( 1, (int) $s['max_days'] );
					$txt  = enc_time_ago( $ts, $max );
					$attrs = ' data-enc-ago="' . $ts . '" data-max="' . $max . '" data-date="' . esc_attr( $date_str ) . '"';
					if ( '' === $txt ) {
						$txt = $date_str;
					}
					break;
				case 'time':
					$txt = get_the_time( $s['time_format'] ?: 'H:i', $id );
					break;
				case 'datetime':
					$txt = get_the_time( $s['time_format'] ?: 'H:i', $id ) . ' | ' . $date_str;
					break;
				default:
					$txt = $date_str;
			}
			$icon = '';
			if ( 'yes' === $s['show_time_icon'] ) {
				ob_start();
				if ( ! empty( $s['time_icon']['value'] ) ) {
					\Elementor\Icons_Manager::render_icon( $s['time_icon'], [ 'aria-hidden' => 'true' ] );
				} else {
					echo $c['icon_clock']; // phpcs:ignore WordPress.Security.EscapeOutput
				}
				$icon = '<span class="enc-lt-when__icon">' . ob_get_clean() . '</span>';
			}
			$when = '<span class="enc-lt-when">' . $icon . '<time class="enc-lt-time" datetime="' . esc_attr( get_the_date( 'c', $id ) ) . '"' . $attrs . '>' . esc_html( $txt ) . '</time></span>';
		}

		// Категория
		$label = '';
		if ( 'yes' === $s['show_category'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$u = ( 'yes' === $s['category_link'] ) ? get_term_link( $t ) : '';
				if ( $u && ! is_wp_error( $u ) ) {
					$label = '<a class="enc-lt-label" href="' . esc_url( $u ) . '">' . esc_html( $t->name ) . '</a>';
				} else {
					$label = '<span class="enc-lt-label">' . esc_html( $t->name ) . '</span>';
				}
			}
		}

		$views = '';
		if ( 'yes' === $s['show_views'] ) {
			$views = '<span class="enc-lt-views">' . $c['icon_eye'] . '<span>' . (int) get_post_meta( $id, $c['views_key'], true ) . '</span></span>';
		}

		$meta = $fmt['inline'] . $when . $label . $views;

		$cls = 'enc-lt-item';
		if ( $has_image && 'left' === $s['image_pos'] ) {
			$cls .= ' enc-lt-item--img-left';
		} elseif ( $has_image && 'right' === $s['image_pos'] ) {
			$cls .= ' enc-lt-item--img-right';
		}

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( $has_image ) : ?>
				<a class="enc-lt-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>
			<div class="enc-lt-item__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-lt-title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>
				<?php if ( $meta ) : ?>
					<div class="enc-lt-meta"><?php echo $meta; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
				<?php endif; ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	protected function render() {
		$s         = $this->get_settings_for_display();
		$post_type = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $s['posts_per_page'] ),
			'offset'              => (int) $s['offset'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		];
		if ( 'views' === $s['orderby'] ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
				[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
			];
			$args['orderby'] = [ 'enc_v' => $s['order'], 'date' => 'DESC' ];
		} else {
			$args['orderby'] = $s['orderby'];
		}
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( (int) $s['days'] > 0 ) {
			$args['date_query'] = [ [ 'after' => (int) $s['days'] . ' days ago' ] ];
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$q = new WP_Query( $args );
		if ( ! $q->have_posts() ) {
			echo '<div class="enc-lt-empty">Няма намерени новини.</div>';
			return;
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'tag'        => in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'h5', 'div' ], true ) ? $s['title_tag'] : 'h3',
			'icon_clock' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
		];

		$items = [];
		while ( $q->have_posts() ) {
			$q->the_post();
			$items[] = $this->item_html( $s, $ctx );
		}
		wp_reset_postdata();

		$vertical = 'vertical' === $s['layout'];
		$slider   = ! $vertical && 'yes' === $s['slider'];
		$nav_pos  = in_array( $s['nav_pos'], [ 'bl', 'br', 'tr', 'sides' ], true ) ? $s['nav_pos'] : 'bl';

		$classes = 'enc-lt ' . ( $vertical ? 'enc-lt--v' : 'enc-lt--h' );
		if ( 'yes' === $s['uppercase'] ) {
			$classes .= ' enc-lt--upper';
		}
		$attrs = '';
		if ( $slider ) {
			$classes .= ' enc-lt--slider enc-lt--nav-' . $nav_pos;
			$attrs    = ' data-by="' . esc_attr( 'page' === $s['slide_by'] ? 'page' : 'one' ) . '"'
				. ' data-autoplay="' . ( 'yes' === $s['autoplay'] ? '1' : '0' ) . '"'
				. ' data-delay="' . (int) $s['autoplay_delay'] . '"';
		}

		echo '<div class="' . esc_attr( $classes ) . '"' . $attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="enc-lt-viewport"><div class="enc-lt-track">' . implode( '', $items ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $slider ) {
			echo '<div class="enc-lt-nav">'
				. '<button type="button" class="enc-lt-btn enc-lt-btn--prev" aria-label="Предишни"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m15 5-7 7 7 7"/></svg></button>'
				. '<button type="button" class="enc-lt-btn enc-lt-btn--next" aria-label="Следващи"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 5 7 7-7 7"/></svg></button>'
				. '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
	}
}
