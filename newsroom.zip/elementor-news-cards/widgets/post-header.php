<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class ENC_Post_Header_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'enc_post_header'; }
	public function get_title() { return 'Статия – заглавна част'; }
	public function get_icon() { return 'eicon-post-info'; }
	public function get_categories() { return [ 'enc-newsroom' ]; }
	public function get_keywords() { return [ 'post', 'статия', 'заглавие', 'single', 'автор', 'header' ]; }
	public function get_style_depends() { return [ 'enc-single' ]; }
	public function get_script_depends() { return [ 'enc-single' ]; }

	protected function register_controls() {

		/* ---------- Съдържание ---------- */
		$this->start_controls_section( 'section_content', [ 'label' => 'Елементи' ] );
		$sw = function ( $name, $label, $default = 'yes', $extra = [] ) {
			$this->add_control( $name, array_merge( [ 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'default' => $default ], $extra ) );
		};
		$sw( 'show_category', 'Категория над заглавието' );
		$sw( 'show_updated', 'Ред „Обновена“ (ако е отбелязана)' );
		$sw( 'show_note', 'Бележка за корекция (ако има)' );
		$sw( 'show_author', 'Автор' );
		$sw( 'show_avatar', 'Снимка на автора', '', [ 'condition' => [ 'show_author' => 'yes' ] ] );
		$sw( 'show_date', 'Дата' );
		$this->add_control( 'date_format', [
			'label' => 'Формат на датата', 'type' => Controls_Manager::TEXT, 'default' => 'l, j F Y',
			'condition' => [ 'show_date' => 'yes' ],
		] );
		$sw( 'show_time', 'Час', 'yes', [ 'condition' => [ 'show_date' => 'yes' ] ] );
		$this->add_control( 'time_format', [
			'label' => 'Формат на часа', 'type' => Controls_Manager::TEXT, 'default' => 'H:i',
			'condition' => [ 'show_date' => 'yes', 'show_time' => 'yes' ],
		] );
		$sw( 'show_reading', 'Време за четене' );
		$this->add_control( 'read_suffix', [
			'label' => 'Текст след числото', 'type' => Controls_Manager::TEXT, 'default' => 'мин. четене',
			'condition' => [ 'show_reading' => 'yes' ],
		] );
		$sw( 'show_views', 'Брой прегледи' );
		$this->add_control( 'views_suffix', [
			'label' => 'Текст след числото', 'type' => Controls_Manager::TEXT, 'default' => '', 'placeholder' => 'напр. прегледа',
			'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->add_control( 'views_key', [
			'label' => 'Мета ключ за прегледите', 'type' => Controls_Manager::TEXT, 'default' => 'enc_views',
			'condition' => [ 'show_views' => 'yes' ],
		] );
		$sw( 'show_share', 'Бутон „Сподели“' );
		$sw( 'show_comments', 'Бутон „Коментари“' );
		$sw( 'show_image', 'Основна снимка' );
		$this->add_control( 'image_size', [
			'label' => 'Размер на снимката', 'type' => Controls_Manager::SELECT, 'default' => 'large',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
			'condition' => [ 'show_image' => 'yes' ],
		] );
		$sw( 'show_caption', 'Надпис под снимката', 'yes', [ 'condition' => [ 'show_image' => 'yes' ] ] );
		$this->end_controls_section();

		/* ---------- Стил: общо ---------- */
		$this->start_controls_section( 'style_general', [ 'label' => 'Общо', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'max_width', [
			'label' => 'Максимална ширина', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px', '%' ],
			'range' => [ 'px' => [ 'min' => 320, 'max' => 1200 ], '%' => [ 'min' => 30, 'max' => 100 ] ],
			'default' => [ 'size' => 752, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-article' => 'max-width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'accent', [
			'label' => 'Акцентен цвят', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-article' => '--enc-accent: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: заглавие ---------- */
		$this->start_controls_section( 'style_title', [ 'label' => 'Заглавие', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'title_color', [
			'label' => 'Цвят', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-post-title' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'title_typo', 'selector' => '{{WRAPPER}} .enc-post-title',
		] );
		$this->end_controls_section();

		/* ---------- Стил: мета ---------- */
		$this->start_controls_section( 'style_meta', [ 'label' => 'Автор, дата и време за четене', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'author_color', [
			'label' => 'Цвят на автора', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-post-author' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'author_typo', 'selector' => '{{WRAPPER}} .enc-post-author',
		] );
		$this->add_control( 'meta_color', [
			'label' => 'Цвят на датата и четенето', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-post-meta__info' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'meta_typo', 'selector' => '{{WRAPPER}} .enc-post-date, {{WRAPPER}} .enc-post-read, {{WRAPPER}} .enc-post-views',
		] );
		$this->end_controls_section();

		/* ---------- Стил: бутони ---------- */
		$this->start_controls_section( 'style_buttons', [ 'label' => 'Бутони', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'btn_size', [
			'label' => 'Размер', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 28, 'max' => 64 ] ], 'default' => [ 'size' => 40, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-iconbtn' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'btn_color', [
			'label' => 'Цвят на иконата', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-iconbtn' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'btn_border', [
			'label' => 'Цвят на контура', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-article' => '--enc-border: {{VALUE}};' ],
		] );
		$this->add_control( 'btn_bg', [
			'label' => 'Фон', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-iconbtn' => 'background-color: {{VALUE}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: снимка ---------- */
		$this->start_controls_section( 'style_image', [ 'label' => 'Снимка и надпис', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'img_radius', [
			'label' => 'Радиус на снимката', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 40 ] ], 'default' => [ 'size' => 12, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-post-img' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'caption_color', [
			'label' => 'Цвят на надписа', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-post-figure figcaption' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'caption_typo', 'selector' => '{{WRAPPER}} .enc-post-figure figcaption',
		] );
		$this->end_controls_section();
	}

	protected function render() {
		$s = $this->get_settings_for_display();

		echo '<div class="enc-article">';
		enc_render_post_header( [
			'show_author'   => 'yes' === $s['show_author'],
			'show_category' => 'yes' === $s['show_category'],
			'show_updated'  => 'yes' === $s['show_updated'],
			'show_note'     => 'yes' === $s['show_note'],
			'show_avatar'   => 'yes' === $s['show_avatar'],
			'show_date'     => 'yes' === $s['show_date'],
			'date_format'   => $s['date_format'],
			'show_time'     => 'yes' === $s['show_time'],
			'time_format'   => $s['time_format'],
			'show_reading'  => 'yes' === $s['show_reading'],
			'read_suffix'   => $s['read_suffix'],
			'show_views'    => 'yes' === $s['show_views'],
			'views_suffix'  => $s['views_suffix'],
			'views_key'     => $s['views_key'],
			'show_share'    => 'yes' === $s['show_share'],
			'show_comments' => 'yes' === $s['show_comments'],
			'show_image'    => 'yes' === $s['show_image'],
			'image_size'    => $s['image_size'],
			'show_caption'  => 'yes' === $s['show_caption'],
		] );
		echo '</div>';
	}
}
