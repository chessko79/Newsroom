<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;

class ENC_News_Lead_Widget extends \Elementor\Widget_Base {

	public function get_name() { return 'enc_news_lead'; }
	public function get_title() { return 'Новини – водеща и списък'; }
	public function get_icon() { return 'eicon-post-slider'; }
	public function get_categories() { return [ 'enc-newsroom' ]; }
	public function get_keywords() { return [ 'news', 'новини', 'lead', 'водеща', 'списък', 'прегледи' ]; }
	public function get_style_depends() { return [ 'enc-news-lead' ]; }
	public function get_script_depends() { return [ 'enc-single' ]; }

	private function get_term_options() {
		$out   = [];
		$terms = get_terms( [ 'taxonomy' => 'category', 'hide_empty' => false ] );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$out[ $t->term_id ] = $t->name;
			}
		}
		return $out;
	}

	private function get_post_type_options() {
		$out = [];
		foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) {
			if ( 'attachment' !== $pt->name ) {
				$out[ $pt->name ] = $pt->labels->singular_name;
			}
		}
		return $out;
	}

	protected function register_controls() {
		$terms = $this->get_term_options();
		$sw    = function ( $name, $label, $default = 'yes', $extra = [] ) {
			$this->add_control( $name, array_merge( [ 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'default' => $default ], $extra ) );
		};

		/* ---------- Заявка ---------- */
		$this->start_controls_section( 'section_query', [ 'label' => 'Заявка' ] );
		$this->add_control( 'post_type', [
			'label' => 'Тип съдържание', 'type' => Controls_Manager::SELECT,
			'options' => $this->get_post_type_options(), 'default' => 'post',
		] );
		$this->add_control( 'categories', [
			'label' => 'Категории', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => $terms, 'condition' => [ 'post_type' => 'post' ],
		] );
		$this->add_control( 'list_count', [
			'label' => 'Колко новини под водещата', 'type' => Controls_Manager::NUMBER, 'default' => 2, 'min' => 0, 'max' => 20,
			'description' => 'Водеща е първата новина според избраната подредба.',
		] );
		$this->add_control( 'offset', [ 'label' => 'Пропусни първите', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0 ] );
		$this->add_control( 'orderby', [
			'label' => 'Подредба по', 'type' => Controls_Manager::SELECT, 'default' => 'date',
			'options' => [
				'date' => 'Дата', 'views' => 'Прегледи (най-четени)', 'comment_count' => 'Коментари',
				'title' => 'Заглавие', 'modified' => 'Последна промяна', 'rand' => 'Случайно',
			],
		] );
		$this->add_control( 'order', [
			'label' => 'Посока', 'type' => Controls_Manager::SELECT, 'default' => 'DESC',
			'options' => [ 'DESC' => 'Низходящо (най-новите/най-четените първо)', 'ASC' => 'Възходящо' ],
		] );
		$this->add_control( 'days', [
			'label' => 'Само от последните N дни', 'type' => Controls_Manager::NUMBER, 'default' => 0, 'min' => 0,
			'description' => '0 = без ограничение. Полезно за „Най-четени тази седмица“ (7).',
		] );
		$sw( 'exclude_current', 'Без текущата статия' );
		$this->end_controls_section();

		/* ---------- Елементи ---------- */
		$this->start_controls_section( 'section_content', [ 'label' => 'Елементи' ] );
		$this->add_control( 'image_size', [
			'label' => 'Размер на снимката на водещата', 'type' => Controls_Manager::SELECT, 'default' => 'large',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
		] );
		$this->add_control( 'title_tag', [
			'label' => 'HTML таг на водещото заглавие', 'type' => Controls_Manager::SELECT, 'default' => 'h2',
			'options' => [ 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'div' => 'div' ],
		] );
		$sw( 'show_category', 'Етикет на категорията върху водещата снимка', '' );
		$sw( 'show_excerpt', 'Откъс при водещата', '' );
		$this->add_control( 'excerpt_length', [
			'label' => 'Думи в откъса', 'type' => Controls_Manager::NUMBER, 'default' => 18, 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$sw( 'show_share', 'Бутон „Сподели“' );
		$this->add_control( 'show_fmt_icon', [ 'label' => 'Икона според формата на публикацията', 'type' => Controls_Manager::SWITCHER, 'default' => 'yes', 'separator' => 'before' ] );
		$this->add_control( 'fmt_icons', [
			'label' => 'За кои формати', 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'label_block' => true,
			'options' => enc_format_labels(), 'default' => [ 'gallery', 'video', 'audio' ], 'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$this->add_control( 'fmt_icon_pos', [
			'label' => 'Позиция на иконата', 'type' => Controls_Manager::SELECT, 'default' => 'tr',
			'options' => [
				'tr' => 'Горе вдясно (върху снимката)', 'tl' => 'Горе вляво', 'br' => 'Долу вдясно', 'bl' => 'Долу вляво',
				'center' => 'В центъра (голяма)', 'meta' => 'В реда с датата',
			],
			'description' => 'Ако новината няма снимка, иконата се показва в реда с датата.',
			'condition' => [ 'show_fmt_icon' => 'yes' ],
		] );
		$sw( 'zoom', 'Увеличаване на водещата снимка при посочване' );
		$this->add_control( 'list_images', [
			'label' => 'Снимки в списъка под водещата', 'type' => Controls_Manager::SELECT, 'default' => 'none',
			'options' => [ 'none' => 'Без снимки', 'all' => 'Със снимки' ], 'separator' => 'before',
		] );
		$this->add_control( 'list_image_pos', [
			'label' => 'Позиция на снимките', 'type' => Controls_Manager::SELECT, 'default' => 'left',
			'options' => [ 'left' => 'Отляво', 'right' => 'Отдясно' ], 'condition' => [ 'list_images' => 'all' ],
		] );
		$this->add_control( 'list_image_size', [
			'label' => 'Размер на малките снимки', 'type' => Controls_Manager::SELECT, 'default' => 'medium',
			'options' => array_combine( get_intermediate_image_sizes(), get_intermediate_image_sizes() ) + [ 'full' => 'full' ],
			'condition' => [ 'list_images' => 'all' ],
		] );
		$this->end_controls_section();

		/* ---------- Редът с мета информация ---------- */
		$this->start_controls_section( 'section_meta', [ 'label' => 'Категория, дата и прегледи' ] );
		$sw( 'show_meta_icon', 'Икона в началото', '' );
		$this->add_control( 'meta_icon', [
			'label' => 'Собствена икона', 'type' => Controls_Manager::ICONS, 'skin' => 'inline', 'label_block' => false,
			'condition' => [ 'show_meta_icon' => 'yes' ],
		] );
		$this->add_control( 'meta_label', [
			'label' => 'Удебелен етикет в началото', 'type' => Controls_Manager::SELECT, 'default' => 'none',
			'options' => [ 'none' => 'Без етикет', 'category' => 'Категория', 'day' => '„Днес“ / „Вчера“' ],
		] );
		$sw( 'meta_label_link', 'Категорията е линк', 'yes', [ 'condition' => [ 'meta_label' => 'category' ] ] );
		$sw( 'show_time', 'Час' );
		$this->add_control( 'time_format', [
			'label' => 'Формат на часа', 'type' => Controls_Manager::TEXT, 'default' => 'H:i', 'condition' => [ 'show_time' => 'yes' ],
		] );
		$sw( 'show_date', 'Дата' );
		$this->add_control( 'date_format', [
			'label' => 'Формат на датата', 'type' => Controls_Manager::TEXT, 'default' => 'd.m.y', 'condition' => [ 'show_date' => 'yes' ],
		] );
		$this->add_control( 'meta_sep', [
			'label' => 'Разделител между час и дата', 'type' => Controls_Manager::TEXT, 'default' => '|',
			'condition' => [ 'show_time' => 'yes', 'show_date' => 'yes' ],
		] );
		$sw( 'show_views', 'Брой прегледи' );
		$this->add_control( 'views_key', [
			'label' => 'Мета ключ за прегледите', 'type' => Controls_Manager::TEXT, 'default' => 'enc_views',
			'description' => 'Вграденият брояч ползва enc_views.', 'condition' => [ 'show_views' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Цветове по категория ---------- */
		$this->start_controls_section( 'section_cat_colors', [ 'label' => 'Цветове на категориите (списък)' ] );
		$rep = new Repeater();
		$rep->add_control( 'term', [ 'label' => 'Категория', 'type' => Controls_Manager::SELECT2, 'options' => $terms, 'label_block' => true ] );
		$rep->add_control( 'color', [ 'label' => 'Цвят', 'type' => Controls_Manager::COLOR, 'default' => '#f07a10' ] );
		$this->add_control( 'cat_colors', [
			'label' => 'Цвят по категория', 'type' => Controls_Manager::REPEATER, 'fields' => $rep->get_controls(),
			'title_field' => '{{{ color }}}',
			'description' => 'Важи за етикетите в списъка. Категориите без цвят ползват общия цвят на етикета.',
		] );
		$this->end_controls_section();

		/* ---------- Стил: карта ---------- */
		$this->start_controls_section( 'style_panel', [ 'label' => 'Карта', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'panel_bg', [
			'label' => 'Фон', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-panel' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'panel_radius', [
			'label' => 'Радиус на ъглите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 30 ] ], 'default' => [ 'size' => 4, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-panel' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'no_shadow', [
			'label' => 'Без сянка', 'type' => Controls_Manager::SWITCHER, 'default' => '',
			'description' => 'Изключва сянката около картата (и при посочване).',
			'selectors' => [ '{{WRAPPER}} .enc-lead .enc-lead-panel' => 'box-shadow: none;' ],
		] );
		$this->add_group_control( Group_Control_Box_Shadow::get_type(), [
			'name' => 'panel_shadow', 'selector' => '{{WRAPPER}} .enc-lead-panel',
		] );
		$this->add_control( 'sep_color', [
			'label' => 'Цвят на разделителните линии', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-lead-item' => 'border-top-color: {{VALUE}};' ],
		] );
		$this->add_control( 'sep_width', [
			'label' => 'Дебелина на линиите', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 6 ] ], 'default' => [ 'size' => 1, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-item' => 'border-top-width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: водеща ---------- */
		$this->start_controls_section( 'style_hero', [ 'label' => 'Водеща новина', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_responsive_control( 'hero_ratio', [
			'label' => 'Пропорция на снимката', 'type' => Controls_Manager::SELECT, 'default' => '1 / 1',
			'options' => [ '1 / 1' => '1:1', '4 / 5' => '4:5', '4 / 3' => '4:3', '3 / 2' => '3:2', '16 / 10' => '16:10', '16 / 9' => '16:9', '21 / 9' => '21:9' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero' => 'aspect-ratio: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Background::get_type(), [
			'name'     => 'overlay_bg',
			'types'    => [ 'classic', 'gradient' ],
			'selector' => '{{WRAPPER}} .enc-lead-hero__overlay',
			'fields_options' => [
				'background'     => [ 'default' => 'gradient' ],
				'color'          => [ 'default' => 'rgba(0,0,0,0.9)' ],
				'color_stop'     => [ 'default' => [ 'unit' => '%', 'size' => 0 ] ],
				'color_b'        => [ 'default' => 'rgba(0,0,0,0)' ],
				'color_b_stop'   => [ 'default' => [ 'unit' => '%', 'size' => 65 ] ],
				'gradient_angle' => [ 'default' => [ 'unit' => 'deg', 'size' => 0 ] ],
			],
		] );
		$this->add_control( 'hero_title_color', [
			'label' => 'Цвят на заглавието', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero__title' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'hero_title_hover', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero:hover .enc-lead-hero__title' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'hero_title_typo', 'selector' => '{{WRAPPER}} .enc-lead-hero__title',
		] );
		$this->add_group_control( Group_Control_Text_Shadow::get_type(), [
			'name' => 'hero_title_shadow', 'selector' => '{{WRAPPER}} .enc-lead-hero__title',
		] );
		$this->add_control( 'hero_title_lines', [
			'label' => 'Максимум редове', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 8,
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero__title' => '-webkit-line-clamp: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'hero_padding', [
			'label' => 'Вътрешен отстъп на текста', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_control( 'hero_meta_color', [
			'label' => 'Цвят на реда с дата и прегледи', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero .enc-lead-meta' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'hero_meta_typo', 'selector' => '{{WRAPPER}} .enc-lead-hero .enc-lead-meta',
		] );
		$this->add_control( 'hero_share_color', [
			'label' => 'Цвят на бутона „Сподели“', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero .enc-lead-share' => 'color: {{VALUE}};' ], 'condition' => [ 'show_share' => 'yes' ],
		] );
		$this->add_control( 'hero_share_size', [
			'label' => 'Размер на бутона „Сподели“', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 40 ] ], 'default' => [ 'size' => 22, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-hero .enc-lead-share svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
			'condition' => [ 'show_share' => 'yes' ],
		] );
		$this->add_control( 'excerpt_color', [
			'label' => 'Цвят на откъса', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-excerpt' => 'color: {{VALUE}};' ], 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'excerpt_typo', 'selector' => '{{WRAPPER}} .enc-lead-excerpt', 'condition' => [ 'show_excerpt' => 'yes' ],
		] );
		$this->add_control( 'badge_bg', [
			'label' => 'Фон на етикета на категорията', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-badge' => 'background-color: {{VALUE}};' ], 'condition' => [ 'show_category' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: списък ---------- */
		$this->start_controls_section( 'style_list', [ 'label' => 'Списък под водещата', 'tab' => Controls_Manager::TAB_STYLE ] );
		$this->add_control( 'title_color', [
			'label' => 'Цвят на заглавието', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-item__title' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'title_hover_color', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-item__title a:hover' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'title_typo', 'selector' => '{{WRAPPER}} .enc-lead-item__title',
		] );
		$this->add_control( 'title_lines', [
			'label' => 'Максимум редове', 'type' => Controls_Manager::NUMBER, 'default' => 3, 'min' => 1, 'max' => 8,
			'selectors' => [ '{{WRAPPER}} .enc-lead-item__title' => '-webkit-line-clamp: {{VALUE}};' ],
		] );
		$this->add_responsive_control( 'body_padding', [
			'label' => 'Вътрешен отстъп', 'type' => Controls_Manager::DIMENSIONS, 'size_units' => [ 'px', 'em' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-item__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ],
		] );
		$this->add_control( 'label_color', [
			'label' => 'Общ цвят на етикета (категорията)', 'type' => Controls_Manager::COLOR, 'separator' => 'before',
			'selectors' => [ '{{WRAPPER}} .enc-lead-item .enc-lead-meta__label' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'label_typo', 'selector' => '{{WRAPPER}} .enc-lead-meta__label',
		] );
		$this->add_control( 'meta_color', [
			'label' => 'Цвят на часа, датата и прегледите', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-item .enc-lead-meta' => 'color: {{VALUE}};' ],
		] );
		$this->add_group_control( Group_Control_Typography::get_type(), [
			'name' => 'meta_typo', 'selector' => '{{WRAPPER}} .enc-lead-item .enc-lead-meta__time, {{WRAPPER}} .enc-lead-item .enc-lead-meta__views',
		] );
		$this->add_control( 'icon_size', [
			'label' => 'Размер на иконите (око и др.)', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 32 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-meta__icon svg, {{WRAPPER}} .enc-lead-meta__views svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};', '{{WRAPPER}} .enc-lead-meta i' => 'font-size: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'share_color', [
			'label' => 'Цвят на бутона „Сподели“', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-item .enc-lead-share' => 'color: {{VALUE}};' ], 'condition' => [ 'show_share' => 'yes' ],
		] );
		$this->add_control( 'share_hover', [
			'label' => 'Цвят при посочване', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-lead-item .enc-lead-share:hover' => 'color: {{VALUE}};' ], 'condition' => [ 'show_share' => 'yes' ],
		] );
		$this->add_control( 'share_size', [
			'label' => 'Размер на бутона „Сподели“', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 32 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-item .enc-lead-share svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
			'condition' => [ 'show_share' => 'yes' ],
		] );
		$this->end_controls_section();

		/* ---------- Стил: малки снимки ---------- */
		$this->start_controls_section( 'style_fmt', [ 'label' => 'Икона на формата', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'show_fmt_icon' => 'yes' ] ] );
		$this->add_control( 'fmt_color', [
			'label' => 'Цвят на иконата', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt' => 'color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_bg', [
			'label' => 'Фон на кръга (върху снимката)', 'type' => Controls_Manager::COLOR,
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov' => 'background-color: {{VALUE}};' ],
		] );
		$this->add_control( 'fmt_size', [
			'label' => 'Размер на кръга', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 20, 'max' => 80 ] ], 'default' => [ 'size' => 30, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt--ov:not(.enc-fmt--center)' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_control( 'fmt_icon_size', [
			'label' => 'Размер на иконата', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 10, 'max' => 40 ] ], 'default' => [ 'size' => 16, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-fmt:not(.enc-fmt--center) svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();

		$this->start_controls_section( 'style_thumb', [ 'label' => 'Малки снимки в списъка', 'tab' => Controls_Manager::TAB_STYLE, 'condition' => [ 'list_images' => 'all' ] ] );
		$this->add_responsive_control( 'thumb_width', [
			'label' => 'Ширина', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px', '%' ],
			'range' => [ 'px' => [ 'min' => 50, 'max' => 300 ], '%' => [ 'min' => 10, 'max' => 50 ] ],
			'default' => [ 'size' => 120, 'unit' => 'px' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-item__media' => 'width: {{SIZE}}{{UNIT}};' ],
		] );
		$this->add_responsive_control( 'thumb_ratio', [
			'label' => 'Пропорция', 'type' => Controls_Manager::SELECT, 'default' => '3 / 2',
			'options' => [ '16 / 9' => '16:9', '3 / 2' => '3:2', '4 / 3' => '4:3', '1 / 1' => '1:1' ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-item__media' => 'aspect-ratio: {{VALUE}};' ],
		] );
		$this->add_control( 'thumb_radius', [
			'label' => 'Радиус', 'type' => Controls_Manager::SLIDER, 'size_units' => [ 'px' ],
			'range' => [ 'px' => [ 'min' => 0, 'max' => 30 ] ],
			'selectors' => [ '{{WRAPPER}} .enc-lead-item__media' => 'border-radius: {{SIZE}}{{UNIT}};' ],
		] );
		$this->end_controls_section();
	}

	/** Първата категория (или първата таксономия за други типове съдържание). */
	private function get_primary_term( $post_id, $post_type ) {
		$taxes = ( 'post' === $post_type ) ? [ 'category' ] : get_object_taxonomies( $post_type );
		foreach ( $taxes as $tax ) {
			$terms = get_the_terms( $post_id, $tax );
			if ( $terms && ! is_wp_error( $terms ) ) {
				return reset( $terms );
			}
		}
		return null;
	}

	/** Редът с категория, час/дата, прегледи и бутон „Сподели“. */
	private function meta_html( $s, $c, $hero, $fmt_in = '' ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();

		$label = $label_url = $label_style = '';
		if ( 'category' === $s['meta_label'] ) {
			$t = $this->get_primary_term( $id, $c['post_type'] );
			if ( $t ) {
				$label = $t->name;
				if ( 'yes' === $s['meta_label_link'] ) {
					$u         = get_term_link( $t );
					$label_url = is_wp_error( $u ) ? '' : $u;
				}
				if ( ! $hero && isset( $c['colors'][ $t->term_id ] ) ) {
					$label_style = ' style="color:' . esc_attr( $c['colors'][ $t->term_id ] ) . '"';
				}
			}
		} elseif ( 'day' === $s['meta_label'] ) {
			$pd = get_the_date( 'Y-m-d', $id );
			if ( $pd === $c['today'] ) {
				$label = 'Днес';
			} elseif ( $pd === $c['yester'] ) {
				$label = 'Вчера';
			}
		}

		$parts = [];
		if ( 'yes' === $s['show_time'] ) {
			$parts[] = get_the_time( $s['time_format'] ?: 'H:i', $id );
		}
		if ( 'yes' === $s['show_date'] ) {
			$parts[] = get_the_date( $s['date_format'] ?: 'd.m.y', $id );
		}
		$sep       = trim( (string) $s['meta_sep'] );
		$time_str  = implode( $sep ? ' ' . $sep . ' ' : ' ', $parts );
		$views     = ( 'yes' === $s['show_views'] ) ? (int) get_post_meta( $id, $c['views_key'], true ) : null;
		$has_icon  = 'yes' === $s['show_meta_icon'];
		$has_share = 'yes' === $s['show_share'];

		if ( ! ( $has_icon || $label || $time_str || null !== $views || $has_share || $fmt_in ) ) {
			return '';
		}

		ob_start();
		?>
		<div class="enc-lead-meta">
			<?php echo $fmt_in; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php if ( $has_icon ) : ?>
				<span class="enc-lead-meta__icon"><?php
					if ( ! empty( $s['meta_icon']['value'] ) ) {
						\Elementor\Icons_Manager::render_icon( $s['meta_icon'], [ 'aria-hidden' => 'true' ] );
					} else {
						echo $c['icon_news']; // phpcs:ignore WordPress.Security.EscapeOutput
					}
				?></span>
			<?php endif; ?>

			<?php if ( $label ) :
				if ( $label_url ) : ?><a class="enc-lead-meta__label" href="<?php echo esc_url( $label_url ); ?>"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></a><?php
				else : ?><strong class="enc-lead-meta__label"<?php echo $label_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $label ); ?></strong><?php
				endif;
			endif; ?>

			<?php if ( $time_str ) : ?><time class="enc-lead-meta__time" datetime="<?php echo esc_attr( get_the_date( 'c', $id ) ); ?>"><?php echo esc_html( $time_str ); ?></time><?php endif; ?>

			<?php if ( null !== $views ) : ?>
				<span class="enc-lead-meta__views"><?php echo $c['icon_eye']; // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $views ); ?></span></span>
			<?php endif; ?>

			<?php if ( $has_share ) : ?>
				<button type="button" class="enc-share enc-lead-share" aria-label="Сподели"
					data-url="<?php echo esc_url( $link ); ?>" data-title="<?php echo esc_attr( $title ); ?>" data-copied="Линкът е копиран">
					<?php echo $c['icon_share']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</button>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	private function hero_html( $s, $c ) {
		$id    = get_the_ID();
		$link  = get_permalink();
		$title = get_the_title();
		$tag   = in_array( $s['title_tag'], [ 'h2', 'h3', 'h4', 'div' ], true ) ? $s['title_tag'] : 'h2';

		$cat = null;
		if ( 'yes' === $s['show_category'] ) {
			$cat = $this->get_primary_term( $id, $c['post_type'] );
		}

		$fmt = enc_format_icons( $id, $s, true );

		ob_start();
		?>
		<article class="enc-lead-hero">
			<div class="enc-lead-hero__media">
				<?php if ( has_post_thumbnail() ) {
					echo get_the_post_thumbnail( $id, $s['image_size'], [ 'loading' => 'eager', 'fetchpriority' => 'high', 'alt' => esc_attr( $title ) ] );
				} ?>
			</div>
			<span class="enc-lead-hero__overlay"></span>
			<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<a class="enc-lead-hero__cover" href="<?php echo esc_url( $link ); ?>" aria-hidden="true" tabindex="-1"></a>
			<?php if ( $cat ) : ?><span class="enc-lead-badge"><?php echo esc_html( $cat->name ); ?></span><?php endif; ?>

			<div class="enc-lead-hero__body">
				<<?php echo esc_attr( $tag ); ?> class="enc-lead-hero__title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></<?php echo esc_attr( $tag ); ?>>
				<?php if ( 'yes' === $s['show_excerpt'] ) : ?>
					<p class="enc-lead-excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), (int) $s['excerpt_length'] ) ); ?></p>
				<?php endif; ?>
				<?php echo $this->meta_html( $s, $c, true, $fmt['inline'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	private function row_html( $s, $c ) {
		$id        = get_the_ID();
		$link      = get_permalink();
		$title     = get_the_title();
		$has_image = 'all' === $s['list_images'] && has_post_thumbnail();
		$fmt       = enc_format_icons( $id, $s, $has_image );
		$cls       = 'enc-lead-item' . ( $has_image && 'right' === $s['list_image_pos'] ? ' enc-lead-item--img-right' : '' );

		ob_start();
		?>
		<article class="<?php echo esc_attr( $cls ); ?>">
			<?php if ( $has_image ) : ?>
				<a class="enc-lead-item__media" href="<?php echo esc_url( $link ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo get_the_post_thumbnail( $id, $s['list_image_size'], [ 'loading' => 'lazy', 'alt' => esc_attr( $title ) ] ); ?>
					<?php echo $fmt['overlay']; // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</a>
			<?php endif; ?>
			<div class="enc-lead-item__body">
				<h3 class="enc-lead-item__title"><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $title ); ?></a></h3>
				<?php echo $this->meta_html( $s, $c, false, $fmt['inline'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		</article>
		<?php
		return ob_get_clean();
	}

	protected function render() {
		$s          = $this->get_settings_for_display();
		$post_type  = ! empty( $s['post_type'] ) ? $s['post_type'] : 'post';
		$views_key  = ! empty( $s['views_key'] ) ? sanitize_key( $s['views_key'] ) : 'enc_views';
		$list_count = max( 0, (int) $s['list_count'] );

		$args = [
			'post_type'           => $post_type,
			'post_status'         => 'publish',
			'posts_per_page'      => 1 + $list_count,
			'offset'              => (int) $s['offset'],
			'order'               => $s['order'],
			'ignore_sticky_posts' => true,
		];
		if ( 'views' === $s['orderby'] ) {
			$args['meta_query'] = [
				'relation' => 'OR',
				'enc_v'    => [ 'key' => $views_key, 'type' => 'NUMERIC', 'compare' => 'EXISTS' ],
				[ 'key' => $views_key, 'compare' => 'NOT EXISTS' ],
			];
			$args['orderby'] = [ 'enc_v' => $s['order'], 'date' => 'DESC' ];
		} else {
			$args['orderby'] = $s['orderby'];
		}
		if ( 'post' === $post_type && ! empty( $s['categories'] ) ) {
			$args['category__in'] = array_map( 'intval', (array) $s['categories'] );
		}
		if ( (int) $s['days'] > 0 ) {
			$args['date_query'] = [ [ 'after' => (int) $s['days'] . ' days ago' ] ];
		}
		if ( 'yes' === $s['exclude_current'] && is_singular() ) {
			$args['post__not_in'] = [ get_the_ID() ];
		}

		$q = new WP_Query( $args );
		if ( ! $q->have_posts() ) {
			echo '<div class="enc-lead-empty">Няма намерени новини.</div>';
			return;
		}

		$colors = enc_all_term_colors();
		if ( ! empty( $s['cat_colors'] ) ) {
			foreach ( $s['cat_colors'] as $row ) {
				if ( ! empty( $row['term'] ) && ! empty( $row['color'] ) ) {
					$colors[ (int) $row['term'] ] = $row['color'];
				}
			}
		}

		$ctx = [
			'post_type'  => $post_type,
			'views_key'  => $views_key,
			'colors'     => $colors,
			'today'      => wp_date( 'Y-m-d' ),
			'yester'     => wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ),
			'icon_news'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 5h13a1 1 0 0 1 1 1v12a2 2 0 0 0 2 2H6a2 2 0 0 1-2-2V5Z"/><path d="M18 9h2a1 1 0 0 1 1 1v8a2 2 0 0 1-2 2"/><path d="M8 9h6M8 13h6M8 17h4"/></svg>',
			'icon_eye'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>',
			'icon_share' => '<svg viewBox="0 0 24 24" aria-hidden="true"><g fill="currentColor"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></g><path d="M8.6 10.5l6.8-4M8.6 13.5l6.8 4" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
		];

		$hero = '';
		$rows = [];
		$i    = 0;
		while ( $q->have_posts() ) {
			$q->the_post();
			if ( 0 === $i ) {
				$hero = $this->hero_html( $s, $ctx );
			} else {
				$rows[] = $this->row_html( $s, $ctx );
			}
			$i++;
		}
		wp_reset_postdata();

		echo '<div class="enc-lead' . ( 'yes' === $s['zoom'] ? ' enc-lead--zoom' : '' ) . '"><div class="enc-lead-panel">';
		echo $hero; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $rows ) {
			echo '<div class="enc-lead-items">' . implode( '', $rows ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></div>';
	}
}
