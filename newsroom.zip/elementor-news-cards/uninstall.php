<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
global $wpdb;
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}enc_views" );
$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_enc\\_top\\_%' OR option_name LIKE '\\_transient\\_timeout\\_enc\\_top\\_%'" );
foreach ( [ 'enc_single_enabled', 'enc_sidebar', 'enc_sidebar_pos', 'enc_count_views', 'enc_count_mode', 'enc_count_skip_editors', 'enc_single_show_views', 'enc_post_formats', 'enc_db_version', 'enc_related', 'enc_related_news', 'enc_share', 'enc_archive' ] as $opt ) {
	delete_option( $opt );
}
// Мета ключът enc_views в статиите се запазва нарочно.
