<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wp_enqueue_style( 'enc-single' );
wp_enqueue_script( 'enc-single' );

get_header();

/* ---------- Режим The7: ползваме нейната структура (#content + нейния sidebar) ---------- */
if ( enc_is_the7() ) {
	if ( ! function_exists( 'presscore_is_content_visible' ) || presscore_is_content_visible() ) {
		do_action( 'presscore_before_loop' );

		while ( have_posts() ) {
			the_post();
			echo '<div id="content" class="content enc-the7" role="main">';
			enc_render_article();
			echo '</div>';
		}

		ob_start();
		do_action( 'presscore_after_content' );
		$after = ob_get_clean();

		// Ако куката не е изрисувала sidebar, а The7 е настроена за такъв – викаме sidebar.php на темата.
		if ( false === stripos( $after, 'sidebar' ) && function_exists( 'presscore_config' )
			&& in_array( presscore_config()->get( 'sidebar_position' ), [ 'left', 'right' ], true ) ) {
			ob_start();
			get_sidebar();
			$after .= ob_get_clean();
		}
		echo $after; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	get_footer();
	return;
}

/* ---------- Режим Astra: ползваме нейния #primary и нейния sidebar ---------- */
if ( enc_is_astra() ) {
	$layout = function_exists( 'astra_page_layout' ) ? astra_page_layout() : 'no-sidebar';

	if ( 'left-sidebar' === $layout ) {
		get_sidebar();
	}
	?>
	<div id="primary" <?php
		if ( function_exists( 'astra_primary_class' ) ) {
			astra_primary_class();
		} else {
			echo 'class="content-area primary"';
		}
	?>>
		<main id="main" class="site-main enc-astra">
			<?php
			while ( have_posts() ) {
				the_post();
				enc_render_article();
			}
			?>
		</main>
	</div>
	<?php
	if ( 'right-sidebar' === $layout ) {
		get_sidebar();
	}
	get_footer();
	return;
}

/* ---------- Общ режим за останалите теми ---------- */
$sidebar_id = enc_get_sidebar_id();
$classes    = 'enc-single';
if ( $sidebar_id ) {
	$classes .= ' enc-single--sidebar enc-single--' . ( 'left' === get_option( 'enc_sidebar_pos', 'right' ) ? 'left' : 'right' );
}

while ( have_posts() ) :
	the_post();
	?>
	<main class="<?php echo esc_attr( $classes ); ?>">
		<div class="enc-layout">
			<div class="enc-main">
				<?php enc_render_article(); ?>
			</div>
			<?php enc_render_sidebar( $sidebar_id ); ?>
		</div>
	</main>
	<?php
endwhile;

get_footer();
