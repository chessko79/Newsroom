<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

wp_enqueue_style( 'enc-archive' );

get_header();

/* ---------- Режим The7 ---------- */
if ( enc_is_the7() ) {
	if ( ! function_exists( 'presscore_is_content_visible' ) || presscore_is_content_visible() ) {
		do_action( 'presscore_before_loop' );

		echo '<div id="content" class="content enc-arc enc-arc--embedded" role="main">';
		enc_render_archive_main();
		echo '</div>';

		ob_start();
		do_action( 'presscore_after_content' );
		$after = ob_get_clean();
		if ( false === stripos( $after, 'sidebar' ) && function_exists( 'presscore_config' )
			&& in_array( presscore_config()->get( 'sidebar_position' ), [ 'left', 'right' ], true ) ) {
			ob_start();
			get_sidebar();
			$after .= ob_get_clean();
		}
		echo $after; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	get_footer();
	return;
}

/* ---------- Режим Astra ---------- */
if ( enc_is_astra() ) {
	$layout = function_exists( 'astra_page_layout' ) ? astra_page_layout() : 'no-sidebar';
	if ( 'left-sidebar' === $layout ) {
		get_sidebar();
	}
	?>
	<div id="primary" <?php
		if ( function_exists( 'astra_primary_class' ) ) {
			astra_primary_class();
		} else {
			echo 'class="content-area primary"';
		}
	?>>
		<main id="main" class="site-main enc-arc enc-arc--embedded">
			<?php enc_render_archive_main(); ?>
		</main>
	</div>
	<?php
	if ( 'right-sidebar' === $layout ) {
		get_sidebar();
	}
	get_footer();
	return;
}

/* ---------- Общ режим ---------- */
$sidebar_id = enc_get_sidebar_id();
$classes    = 'enc-arc';
if ( $sidebar_id ) {
	$classes .= ' enc-arc--sidebar enc-arc--' . ( 'left' === get_option( 'enc_sidebar_pos', 'right' ) ? 'left' : 'right' );
}
?>
<main class="<?php echo esc_attr( $classes ); ?>">
	<div class="enc-arc__layout">
		<?php enc_render_archive_main(); ?>
		<?php enc_render_sidebar( $sidebar_id ); ?>
	</div>
</main>
<?php
get_footer();
